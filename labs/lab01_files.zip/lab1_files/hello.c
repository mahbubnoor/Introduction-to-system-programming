#include <stdio.h>

int main(void)
{
    printf("Hello, System Programming!\n");
    return 0;
}
