#include <stdio.h>

int main(void)
{
    unsigned int x = 0x12345678;
    unsigned char *p = (unsigned char *)&x;

    printf("Value of x      : 0x%08X\n", x);
    printf("Size of x       : %zu bytes\n", sizeof x);
    for (int i = 0; i < 4; i++)
        printf("Address %p : %02X\n", (void *)(p + i), p[i]);
    return 0;
}
