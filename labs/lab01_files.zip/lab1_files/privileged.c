#include <stdio.h>

int main(void)
{
    printf("User mode: about to run a privileged instruction...\n");
    fflush(stdout);
    __asm__ volatile ("hlt");          /* only kernel mode may halt the CPU */
    printf("This line is never printed.\n");
    return 0;
}
