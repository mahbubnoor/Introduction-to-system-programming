#include <stdio.h>

int main(void)
{
    printf("char   : %zu byte\n",  sizeof(char));
    printf("short  : %zu bytes\n", sizeof(short));
    printf("int    : %zu bytes\n", sizeof(int));
    printf("long   : %zu bytes\n", sizeof(long));
    printf("pointer: %zu bytes\n", sizeof(void *));
    return 0;
}
