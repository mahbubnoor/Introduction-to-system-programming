CSE 4105 System Programming - Lab 1 files
Md Mahbub E Noor, University of Barishal

hello.c       the program we follow through the whole course (slides 10-13, 25)
sizes.c       prints the size of each C type (slide 20)
endian.c      shows the byte order of a 4-byte integer (slide 21)
privileged.c  a user program that tries the kernel-only instruction hlt (slide 24)
mistake.c     contains two deliberate mistakes; fix them (slide 30)

Build and run any of them like this:
    gcc endian.c -o endian
    ./endian
