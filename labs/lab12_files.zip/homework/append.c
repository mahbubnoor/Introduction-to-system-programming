/* append.c - two writers, one file: ./append open2 | append | fork
 *   open2:  parent and child each open() the file           (two open-file entries)
 *   append: the same, but with O_APPEND                      (every write goes to the end)
 *   fork:   one open() before fork(), shared by both         (one open-file entry)       */
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>
static void writer(int fd, char c)
{
    char line[17];
    memset(line, c, 15); line[15] = '\n'; line[16] = 0;
    for (int i = 0; i < 1000; i++)
        if (write(fd, line, 16) != 16) { perror("write"); return; }
}
int main(int argc, char *argv[])
{
    const char *mode = argc > 1 ? argv[1] : "open2";
    int flags = O_WRONLY | O_CREAT | (strcmp(mode, "append") == 0 ? O_APPEND : 0);
    close(open("out.txt", O_WRONLY | O_CREAT | O_TRUNC, 0644));          /* start empty */
    int shared = open("out.txt", flags, 0644);
    pid_t pid = fork();
    int fd = strcmp(mode, "fork") == 0 ? shared : open("out.txt", flags, 0644);
    writer(fd, pid == 0 ? 'B' : 'A');
    if (pid == 0) return 0;
    wait(NULL);
    return 0;
}
