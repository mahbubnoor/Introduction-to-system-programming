/* safesave.c - replace a file so that after a crash you have the old version or the new one, never half */
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
static int save(const char *dir, const char *name, const char *text)
{
    char tmp[256], dst[256];
    snprintf(tmp, sizeof tmp, "%s/.%s.tmp", dir, name);
    snprintf(dst, sizeof dst, "%s/%s", dir, name);
    int fd = open(tmp, O_WRONLY | O_CREAT | O_TRUNC, 0644);      /* 1. write a new file */
    if (fd < 0) return -1;
    if (write(fd, text, strlen(text)) != (ssize_t)strlen(text)) return -1;
    if (fsync(fd) < 0) return -1;                                /* 2. its data is on the disk */
    close(fd);
    if (rename(tmp, dst) < 0) return -1;                          /* 3. switch the name: atomic */
    int d = open(dir, O_RDONLY | O_DIRECTORY);                    /* 4. make the rename durable */
    if (d < 0 || fsync(d) < 0) return -1;
    close(d);
    return 0;
}
int main(void)
{
    if (save(".", "settings.txt", "volume=7\n") < 0) { perror("save"); return 1; }
    printf("saved\n");
    return 0;
}
