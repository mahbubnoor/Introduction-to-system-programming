/*
 * ext2cat.c - read a file out of an ext2 disk image WITHOUT the kernel's file system code
 * CSE 4105 System Programming, Lab 12.2   (STARTER: fill in the parts marked TODO)
 *
 * Make an image (no root needed):
 *     mkdir -p files/docs && echo "hello from ext2" > files/hello.txt && ...
 *     mkfs.ext2 -q -b 1024 -d files disk.img 4M
 * Build:  gcc -Wall -O2 -o ext2cat ext2cat.c
 * Run:    ./ext2cat disk.img /hello.txt        ./ext2cat disk.img /docs     (a directory: list it)
 * Check:  debugfs -R "stat /hello.txt" disk.img
 *
 * The structs copy the on-disk layout from Linux fs/ext2/ext2.h (only the fields we need;
 * the rest become padding). Everything on disk is little-endian, like x86: no conversion needed.
 */
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

struct ext2_super_block {               /* at byte 1024 of the disk, always */
    uint32_t s_inodes_count, s_blocks_count, s_r_blocks_count, s_free_blocks_count, s_free_inodes_count;
    uint32_t s_first_data_block;        /* 1 when blocks are 1 KiB, 0 when they are bigger */
    uint32_t s_log_block_size;          /* block size = 1024 << s_log_block_size */
    uint32_t s_log_frag_size, s_blocks_per_group, s_frags_per_group;
    uint32_t s_inodes_per_group;
    uint32_t s_mtime, s_wtime;
    uint16_t s_mnt_count, s_max_mnt_count;
    uint16_t s_magic;                   /* 0xEF53 */
    uint16_t s_state, s_errors, s_minor_rev_level;
    uint32_t s_lastcheck, s_checkinterval, s_creator_os, s_rev_level;
    uint16_t s_def_resuid, s_def_resgid;
    uint32_t s_first_ino;
    uint16_t s_inode_size;              /* 128 or 256 bytes per inode */
};
struct ext2_group_desc {                /* 32 bytes each, in the block after the superblock */
    uint32_t bg_block_bitmap, bg_inode_bitmap;
    uint32_t bg_inode_table;            /* first block of this group's inode table */
    uint16_t bg_free_blocks_count, bg_free_inodes_count, bg_used_dirs_count, bg_pad;
    uint32_t bg_reserved[3];
};
struct ext2_inode {                     /* the first 128 bytes of every inode */
    uint16_t i_mode, i_uid;
    uint32_t i_size, i_atime, i_ctime, i_mtime, i_dtime;
    uint16_t i_gid, i_links_count;
    uint32_t i_blocks, i_flags, osd1;
    uint32_t i_block[15];               /* 12 direct, 1 single, 1 double, 1 triple indirect */
    uint32_t i_generation, i_file_acl, i_dir_acl, i_faddr;
    uint8_t  osd2[12];
};
struct ext2_dir_entry_2 {               /* a directory block is a chain of these */
    uint32_t inode;
    uint16_t rec_len;                   /* bytes to the next entry */
    uint8_t  name_len, file_type;
    char     name[];                    /* NOT '\0'-terminated */
};

static int disk;
static struct ext2_super_block sb;
static unsigned bs;                     /* block size in bytes */

static void read_at(void *buf, size_t n, off_t where)          /* pread, or stop with a message */
{
    ssize_t got = pread(disk, buf, n, where);
    if (got < 0) { perror("pread"); exit(1); }
    if (got != (ssize_t)n) { fprintf(stderr, "short read at byte %lld: past the end of the image?\n", (long long)where); exit(1); }
}
static void read_block(uint32_t b, void *buf) { read_at(buf, bs, (off_t)b * bs); }

static void read_inode(uint32_t ino, struct ext2_inode *in)
{
    /* TODO 2: find inode number ino on the disk.
     *   Inodes are numbered from 1. Each block group has sb.s_inodes_per_group of them:
     *       group = (ino - 1) / s_inodes_per_group      index = (ino - 1) % s_inodes_per_group
     *   The group descriptors start in the block after the superblock: block (s_first_data_block + 1).
     *   Read descriptor number "group" (32 bytes each) with read_at(), then the inode is at byte
     *       bg_inode_table * bs  +  index * sb.s_inode_size                                      */
    memset(in, 0, sizeof *in);
    (void)ino;
}

/* the n-th data block of a file: direct, single or double indirect */
static uint32_t file_block(const struct ext2_inode *in, uint32_t n)
{
    /* Lab: direct blocks only (files up to 12 blocks = 12 KiB).
     * Homework 12.2: add the single indirect block i_block[12] and the double indirect i_block[13]. */
    if (n < 12) return in->i_block[n];
    fprintf(stderr, "block %u needs an indirect block: Homework 12.2\n", n);
    exit(1);
}

/* look for name in directory inode dir; return its inode number or 0 */
static uint32_t lookup(uint32_t dir, const char *name, int list)
{
    struct ext2_inode in;
    read_inode(dir, &in);
    char *buf = malloc(bs);
    for (uint32_t n = 0; n * bs < in.i_size; n++) {
        read_block(file_block(&in, n), buf);
        /* TODO 3: walk the entries in buf. Each starts with struct ext2_dir_entry_2:
         *   inode (0 = unused entry), rec_len (bytes to the NEXT entry), name_len, name (no '\0').
         *   If list is 1: print every used entry, like:
         *       printf("inode %5u  rec_len %4u  %.*s\n", e->inode, e->rec_len, e->name_len, e->name);
         *   Otherwise: if name matches (same length AND memcmp == 0), free(buf) and return e->inode.
         *   Move on with off += e->rec_len; stop if rec_len is 0 (a broken image).            */
        (void)name; (void)list;
    }
    free(buf);
    return 0;
}

int main(int argc, char *argv[])
{
    if (argc < 3) { fprintf(stderr, "usage: %s IMAGE /path\n", argv[0]); return 1; }
    disk = open(argv[1], O_RDONLY);
    if (disk < 0) { perror(argv[1]); return 1; }

    /* TODO 1: the superblock is always at byte 1024. Read it into sb with read_at().
     *   Check s_magic == 0xEF53 (otherwise print "not ext2" and stop).
     *   Block size: bs = 1024 << s_log_block_size.  If s_rev_level == 0, inodes are 128 bytes.  */
    bs = 1024;
    fprintf(stderr, "block size %u, %u inodes per group, inode size %u\n", bs, sb.s_inodes_per_group, sb.s_inode_size);
    if (sb.s_magic != 0xEF53) { fprintf(stderr, "superblock not read yet (magic 0x%x): start with TODO 1\n", sb.s_magic); return 1; }

    uint32_t ino = 2;                                               /* the root directory */
    char path[4096];
    snprintf(path, sizeof path, "%s", argv[2]);
    for (char *part = strtok(path, "/"); part; part = strtok(NULL, "/")) {
        uint32_t next = lookup(ino, part, 0);
        fprintf(stderr, "  %-12s in inode %u -> inode %u\n", part, ino, next);
        if (next == 0) { fprintf(stderr, "%s: not found\n", part); return 1; }
        ino = next;
    }

    struct ext2_inode in;
    read_inode(ino, &in);
    if ((in.i_mode & 0xF000) == 0x4000) { lookup(ino, NULL, 1); return 0; }   /* a directory */

    /* TODO 4: print the file: for n = 0, 1, 2, ... read_block(file_block(&in, n), buf)
     *   and fwrite the bytes to stdout. The last block is only partly used: stop after in.i_size bytes. */

    return 0;
}
