/* sparse.c - seek 1 GiB past the start and write one byte: how big is the file? */
#include <fcntl.h>
#include <stdio.h>
#include <sys/stat.h>
#include <unistd.h>
int main(void)
{
    int fd = open("sparse.bin", O_WRONLY | O_CREAT | O_TRUNC, 0644);
    lseek(fd, 1L << 30, SEEK_SET);          /* move the offset; nothing is written yet */
    if (write(fd, "x", 1) != 1) perror("write");
    struct stat st;
    fstat(fd, &st);
    printf("st_size   = %ld bytes\n", (long)st.st_size);
    printf("st_blocks = %ld  (x 512 = %ld bytes really on disk)\n", (long)st.st_blocks, (long)st.st_blocks * 512);
    close(fd);
    return 0;
}
