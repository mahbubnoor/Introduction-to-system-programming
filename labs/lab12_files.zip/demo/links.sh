#!/bin/sh
# links.sh - names and inodes: hard links, symbolic links, rm
rm -rf lk && mkdir lk && cd lk
echo hello > a
ln a b            # a second NAME for the same inode
ln -s a c         # a new small file whose content is the path "a"
ls -li
rm a
echo "--- after rm a"
ls -li
cat b
cat c
