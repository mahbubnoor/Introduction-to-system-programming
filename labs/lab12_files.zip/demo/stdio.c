/* stdio.c - 1000 lines with printf, then with write(): count the system calls */
#include <stdio.h>
#include <string.h>
#include <unistd.h>
int main(int argc, char *argv[])
{
    const char *line = "a line of text, 32 bytes long..\n";
    if (argc > 1 && strcmp(argv[1], "write") == 0) {
        for (int i = 0; i < 1000; i++)
            if (write(1, line, 32) != 32) return 1;
    } else {
        for (int i = 0; i < 1000; i++) printf("%s", line);
    }
    return 0;
}
