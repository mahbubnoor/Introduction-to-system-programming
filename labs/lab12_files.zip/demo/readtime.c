/* readtime.c - read a file twice: from the disk, then from the page cache */
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
static double now(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return t.tv_sec + t.tv_nsec / 1e9; }
static double readall(const char *path, long *bytes)
{
    static char buf[1 << 16];
    int fd = open(path, O_RDONLY);
    if (fd < 0) { perror(path); exit(1); }
    double t = now();
    ssize_t n;
    *bytes = 0;
    while ((n = read(fd, buf, sizeof buf)) > 0) *bytes += n;
    t = now() - t;
    close(fd);
    return t;
}
int main(int argc, char *argv[])
{
    if (argc < 2) { fprintf(stderr, "usage: %s FILE [drop]\n", argv[0]); return 1; }
    if (argc > 2 && strcmp(argv[2], "drop") == 0) {          /* ask the kernel to forget this file's pages */
        int fd = open(argv[1], O_RDONLY);
        fdatasync(fd);
        posix_fadvise(fd, 0, 0, POSIX_FADV_DONTNEED);
        close(fd);
    }
    long b;
    for (int i = 1; i <= 2; i++) {
        double t = readall(argv[1], &b);
        printf("read %d: %ld MiB in %7.1f ms = %6.0f MiB/s\n", i, b >> 20, t * 1e3, (b >> 20) / t);
    }
    return 0;
}
