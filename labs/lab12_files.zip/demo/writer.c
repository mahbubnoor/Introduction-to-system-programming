/* writer.c - write N MiB; with "fsync", wait until it is really on the disk */
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
static double now(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return t.tv_sec + t.tv_nsec / 1e9; }
int main(int argc, char *argv[])
{
    if (argc < 3) { fprintf(stderr, "usage: %s FILE MiB [fsync]\n", argv[0]); return 1; }
    static char buf[1 << 20];
    memset(buf, 'x', sizeof buf);
    int fd = open(argv[1], O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd < 0) { perror(argv[1]); return 1; }
    double t = now();
    for (int i = 0; i < atoi(argv[2]); i++)
        if (write(fd, buf, sizeof buf) != sizeof buf) { perror("write"); return 1; }
    printf("write(): %s MiB in %6.1f ms\n", argv[2], (now() - t) * 1e3);
    if (argc > 3 && strcmp(argv[3], "fsync") == 0) {
        t = now();
        fsync(fd);
        printf("fsync(): %6.1f ms\n", (now() - t) * 1e3);
    }
    close(fd);
    return 0;
}
