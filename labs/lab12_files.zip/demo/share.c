/* share.c - who shares the file offset? two open()s, dup(), and fork() */
#include <fcntl.h>
#include <stdio.h>
#include <sys/wait.h>
#include <unistd.h>
static void rd(const char *who, int fd)
{
    char b[4] = {0};
    if (read(fd, b, 3) < 0) perror("read");
    printf("%-22s fd %d read \"%s\"  offset now %ld\n", who, fd, b, (long)lseek(fd, 0, SEEK_CUR));
}
int main(void)
{
    int f = open("abc.txt", O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (write(f, "abcdefghijkl", 12) != 12) perror("write");
    close(f);

    printf("1) open() twice: two open-file entries\n");
    int a = open("abc.txt", O_RDONLY), b = open("abc.txt", O_RDONLY);
    rd("   a = open()", a);
    rd("   b = open()", b);
    close(a); close(b);

    printf("2) dup(): one open-file entry, two fds\n");
    a = open("abc.txt", O_RDONLY);
    b = dup(a);
    rd("   a = open()", a);
    rd("   b = dup(a)", b);
    close(a); close(b);

    printf("3) fork(): the child inherits the SAME entry\n");
    a = open("abc.txt", O_RDONLY);
    fflush(stdout);
    if (fork() == 0) { rd("   child", a); return 0; }
    wait(NULL);
    rd("   parent, after child", a);
    return 0;
}
