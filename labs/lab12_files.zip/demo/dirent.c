/* dirent.c - a directory is a list of (name, inode number) pairs: read it like ls -ai */
#include <dirent.h>
#include <stdio.h>
int main(int argc, char *argv[])
{
    DIR *d = opendir(argc > 1 ? argv[1] : ".");
    if (!d) { perror("opendir"); return 1; }
    struct dirent *e;
    while ((e = readdir(d)) != NULL)
        printf("inode %8lu  type %-4s  %s\n", (unsigned long)e->d_ino,
               e->d_type == DT_DIR ? "dir" : e->d_type == DT_REG ? "file" : e->d_type == DT_LNK ? "link" : "?", e->d_name);
    closedir(d);
    return 0;
}
