/* unlinked.c - delete a file while it is open: is it gone? */
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>
int main(void)
{
    int fd = open("secret.txt", O_RDWR | O_CREAT | O_TRUNC, 0600);
    if (write(fd, "still here\n", 11) != 11) perror("write");
    unlink("secret.txt");                        /* remove the NAME */
    struct stat st;
    fstat(fd, &st);
    printf("after unlink: inode %lu, links %lu, size %ld\n", (unsigned long)st.st_ino, (unsigned long)st.st_nlink, (long)st.st_size);
    fflush(stdout);
    char cmd[80];
    snprintf(cmd, sizeof cmd, "ls -l /proc/%d/fd/3 | cut -c40-", getpid());
    if (system(cmd) != 0) printf("ls failed\n");
    char buf[32] = {0};
    if (pread(fd, buf, sizeof buf - 1, 0) < 0) perror("pread");
    printf("read through fd 3: %s", buf);
    close(fd);                                   /* last reference: NOW the inode is freed */
    return 0;
}
