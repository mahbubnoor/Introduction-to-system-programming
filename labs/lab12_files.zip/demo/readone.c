/* readone.c - one open() and one read() of a file (or stdin): for tracing */
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
int main(int argc, char *argv[])
{
    int fd = argc > 1 ? open(argv[1], O_RDONLY) : 0;
    char buf[256];
    ssize_t n = read(fd, buf, sizeof buf);
    printf("read %zd bytes\n", n);
    return 0;
}
