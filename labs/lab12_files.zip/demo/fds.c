/* fds.c - "everything is a file": what is behind each file descriptor? */
#include <fcntl.h>
#include <stdio.h>
#include <sys/eventfd.h>
#include <sys/socket.h>
#include <sys/vfs.h>
#include <unistd.h>
int main(void)
{
    int p[2], sv[2];
    open("/etc/hostname", O_RDONLY);                       /* fd 3: a file on disk     */
    if (pipe(p) < 0) return 1;                             /* fd 4, 5: a pipe          */
    socketpair(AF_UNIX, SOCK_STREAM, 0, sv);               /* fd 6, 7: sockets         */
    open("/proc/self/status", O_RDONLY);                   /* fd 8: a file made by code */
    open("/dev/null", O_WRONLY);                           /* fd 9: a device           */
    eventfd(0, 0);                                         /* fd 10: an eventfd        */
    for (int fd = 0; fd <= 10; fd++) {
        char path[64], target[128] = "";
        struct statfs sf;
        snprintf(path, sizeof path, "/proc/self/fd/%d", fd);
        ssize_t n = readlink(path, target, sizeof target - 1);
        if (n < 0) continue;
        target[n] = 0;
        fstatfs(fd, &sf);
        printf("fd %2d -> %-28s  file system magic 0x%lx\n", fd, target, (unsigned long)sf.f_type);
    }
    return 0;
}
