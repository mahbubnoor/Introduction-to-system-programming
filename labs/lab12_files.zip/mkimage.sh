#!/bin/sh
# mkimage.sh - make the Lab 12.2 disk image: an ext2 file system inside a 4 MiB file (no root needed)
set -e
rm -rf files disk.img
mkdir -p files/docs
echo "hello from ext2" > files/hello.txt
printf 'Lab 12.2 notes\nline two\n' > files/docs/notes.txt
seq 1 30000 > files/docs/numbers.txt          # 168894 bytes: needs the single indirect block
seq 1 60000 > files/docs/big.txt              # 348894 bytes: needs the double indirect block too
ln -s notes.txt files/docs/readme             # a symbolic link
mkfs.ext2 -q -b 1024 -d files disk.img 4M     # 1 KiB blocks, files copied in from ./files
ls -l disk.img
