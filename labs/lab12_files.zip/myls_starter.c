/*
 * myls.c - a small "ls -li": inode, type and permissions, links, owner, size, name
 * CSE 4105 System Programming, Lab 12.1   (STARTER: fill in the parts marked TODO)
 *
 * Build:  gcc -Wall -O2 -o myls myls.c
 * Run:    ./myls  [directory]          compare with:  ls -lia [directory]
 */
#include <dirent.h>
#include <limits.h>
#include <pwd.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

/* "drwxr-xr-x" from st_mode: 1 type character + 3 x rwx */
static void mode_string(mode_t m, char s[11])
{
    /* TODO 3: s[0] is the type: 'd' directory, 'l' symlink, 'c' 'b' devices, 'p' FIFO, 's' socket, '-' file.
     *         Use S_ISDIR(m), S_ISLNK(m), ... from <sys/stat.h>.
     *         s[1..9] are the permission bits, owner rwx, group rwx, others rwx:
     *         bit 0400 is owner r, 0200 owner w, 0100 owner x, 0040 group r, ... 0001 others x.
     *         Hint: (m & (0400 >> i)) is true for the i-th letter of "rwxrwxrwx".            */
    memset(s, '?', 10);
    (void)m;
    s[10] = '\0';
}

int main(int argc, char *argv[])
{
    const char *dir = argc > 1 ? argv[1] : ".";
    /* TODO 1: open the directory with opendir(dir) and read each entry with readdir() until it returns NULL.
     *         Each entry gives you e->d_name and e->d_ino. Build "dir/name" with snprintf.          */

    /* TODO 2: lstat() the path (lstat, not stat: for a symlink we want the link itself).
     *         Print: inode, mode string (TODO 3), st_nlink, owner name (getpwuid), st_size, name.
     *         printf("%8lu %s %2lu %-8s %8ld %s", ...) gives the same columns as the reference.     */

    /* TODO 4: if it is a symlink, readlink() the path and print " -> target".
     *         readlink does NOT add a '\0': use its return value n and write target[n] = '\0'.  */

    printf("myls: nothing printed yet: start with TODO 1 (dir = %s)\n", dir);
    return 0;
}
