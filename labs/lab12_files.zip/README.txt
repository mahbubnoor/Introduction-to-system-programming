CSE 4105 System Programming - Lab 12 (Lectures 12.1 and 12.2): files, the VFS, file systems on disk
===================================================================================================
Works offline, no root needed. Needs: gcc, strace, e2fsprogs (mkfs.ext2, debugfs, dumpe2fs: installed on Ubuntu).

LAB 12.1  myls: your own "ls -li"
  gcc -Wall -O2 -o myls myls_starter.c && ./myls .
  (gcc warns that mode_string is unused until you call it: expected.)
  TODO 1 opendir + readdir loop, build "dir/name"      TODO 2 lstat, print inode, mode, links, owner, size, name
  TODO 3 mode_string: type letter + rwxrwxrwx          TODO 4 symlinks: readlink, print " -> target"
  Compare:  ls -lia .     ls -lia /dev     ls -lia /proc/self/fd

LAB 12.2  ext2cat: read a file from an ext2 disk image by hand
  ./mkimage.sh                     (makes files/ and disk.img; or use the disk.img already here)
  dumpe2fs disk.img | head -60     debugfs -R "ls -l /" disk.img     debugfs -R "stat /hello.txt" disk.img
  gcc -Wall -O2 -o ext2cat ext2cat_starter.c
  TODO 1 superblock at byte 1024, magic 0xEF53, block size    TODO 2 read_inode (group descriptor, inode table)
  TODO 3 walk a directory block with rec_len                  TODO 4 print i_size bytes from the direct blocks
  Test:  ./ext2cat disk.img /hello.txt      ./ext2cat disk.img /docs      ./ext2cat disk.img /docs/notes.txt
         strace -e trace=pread64 ./ext2cat disk.img /hello.txt
  Raw bytes:  od -A d -t x1 -j BYTE -N 64 disk.img
  NOTE: if you run ./mkimage.sh yourself, block numbers and times may differ a little from the slides
        (different mke2fs version). The disk.img in this zip is the one on the slides.

DEMO PROGRAMS (demo/), the ones on the slides:
  cd demo && for f in *.c; do gcc -Wall -O2 -o ${f%.c} $f; done
  12.1: share  fds  sparse (makes a 1 GiB sparse file: delete sparse.bin afterwards)  unlinked  dirent .
        stdio > out.txt ; strace -c -e trace=write ./stdio > out.txt ; strace -c -e trace=write ./stdio write > out.txt
        sh links.sh        namei -l $PWD/fds.c
  12.2: dd if=/dev/urandom of=big.bin bs=1M count=256 ; ./readtime big.bin drop
        ./writer w.bin 256 ; ./writer w.bin 256 fsync ; rm w.bin big.bin
        readone: one open + one read (used for the kernel traces in the QEMU guest)

HOMEWORK (homework/):
  gcc -Wall -O2 -o append append.c && for m in open2 append fork; do ./append $m; wc -l out.txt; done
  gcc -Wall -O2 -o safesave safesave.c && strace -e trace=openat,write,fsync,rename ./safesave
