COUNTL   START   0
MAXLEN   EQU     6
FIRST    STL     RETADR
         CLEAR   X
         LDT     #MAXLEN
LOOP     CLEAR   A
         LDCH    TEXT,X
         COMP    =X'000041'
         JEQ     FOUND
NEXT     TIXR    T
         JLT     LOOP
         J       @RETADR
FOUND    LDA     CNT
         ADD     =X'000001'
         STA     CNT
         J       NEXT
         LTORG
RETADR   RESW    1
CNT      WORD    0
TEXT     BYTE    C'BANANA'
TEXTEND  EQU     *
TLEN     EQU     TEXTEND-TEXT
         END     FIRST
