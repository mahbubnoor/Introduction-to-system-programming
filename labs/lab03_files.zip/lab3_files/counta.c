extern char text[];          /* defined in another file (like EXTREF) */

int counta(void)
{
    int n = 0;
    for (int i = 0; text[i] != '\0'; i++)
        if (text[i] == 'A')
            n++;
    return n;
}
