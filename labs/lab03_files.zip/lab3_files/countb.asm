COUNTB   START   0
FIRST    STL     RETADR
         CLEAR   X
         LDT     #6
LOOP     CLEAR   A
         LDCH    TEXT,X
         COMP    #65
         JEQ     FOUND
NEXT     TIXR    T
         JLT     LOOP
         J       @RETADR
         USE     CDATA
RETADR   RESW    1
CNT      WORD    0
         USE     CBLKS
BUFFER   RESB    4096
         USE     CDATA
TEXT     BYTE    C'BANANA'
         USE
FOUND    LDA     CNT
         ADD     #1
         STA     CNT
         J       NEXT
         END     FIRST
