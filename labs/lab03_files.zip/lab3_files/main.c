#include <stdio.h>

char text[] = "BANANA";      /* defined here, visible outside (like EXTDEF) */
int counta(void);            /* defined in another file (like EXTREF)       */

int main(void)
{
    printf("%d\n", counta());
    return 0;
}
