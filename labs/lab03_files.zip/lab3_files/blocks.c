int  cnt = 0;            /* initialised data   -> .data (or .bss if 0) */
int  limit = 6;          /* initialised data   -> .data */
char buffer[4096];       /* no starting value  -> .bss  */
const char text[] = "BANANA";   /* constant     -> .rodata */

int count_a(void)        /* code               -> .text */
{
    for (int i = 0; i < limit; i++)
        if (text[i] == 'A')
            cnt++;
    return cnt;
}
