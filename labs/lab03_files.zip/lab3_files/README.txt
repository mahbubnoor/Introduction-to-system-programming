CSE 4105 System Programming - Lab 3 files (Lectures 3.1, 3.2, 3.3)
Md Mahbub E Noor, University of Barishal

LAB 3.1  (your two-pass SIC assembler in C)
  sicasm_starter.c      the starter program: fill in TODO 1-4
  count.asm             test program (counts the A's in BANANA)
  count_expected.obj    the object program your assembler must produce
  dup.asm, undef.asm    must give "duplicate symbol FIRST" / "undefined symbol BETA"
  sumn.asm              homework 3.1

    gcc -Wall -o sicasm sicasm_starter.c
    ./sicasm count.asm
    diff count.obj count_expected.obj      (prints nothing when you are right)

LAB 3.2  (SIC/XE and relocation)
  countx.asm            COUNT for SIC/XE (slides 6-14)
  sumx.asm              homework 3.2
  where.c               prints the address of main and of a global: run it twice

LAB 3.3  (EQU and literals)
  countlit.asm          SIC program with EQU and literals
  countlit_expected.obj the object program your version 2 must produce
  countl.asm, countb.asm, countc.asm, multipass.asm   the SIC/XE examples of Lecture 3.3
  lit.c                 gcc -S lit.c : see where gcc puts a string literal
  ptr.c                 gcc -c ptr.c : the pointer-arithmetic error (it is meant to fail)
  blocks.c              gcc -c blocks.c ; size blocks.o
  main.c, counta.c      gcc -c main.c ; gcc -c counta.c ; nm main.o counta.o ;
                        gcc main.o counta.o -o count ; ./count
