CNTLIT   START   2000
MAXLEN   EQU     6
FIRST    LDX     =X'000000'
LOOP     LDA     =X'000000'
         LDCH    TEXT,X
         COMP    =X'000041'
         JEQ     FOUND
NEXT     TIX     =X'000006'
         JLT     LOOP
DONE     J       DONE
FOUND    LDA     TOTAL
         ADD     =X'000001'
         STA     TOTAL
         J       NEXT
         LTORG
TEXT     BYTE    C'BANANA'
TEXTEND  EQU     *
TLEN     EQU     TEXTEND-TEXT
TOTAL    WORD    0
         END     FIRST
