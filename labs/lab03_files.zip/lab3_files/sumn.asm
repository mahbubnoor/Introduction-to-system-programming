SUMN     START   1000
FIRST    LDA     ZERO
         STA     SUM
         LDX     ZERO
LOOP     TIX     N
         STX     I
         LDA     SUM
         ADD     I
         STA     SUM
         JLT     LOOP
HALT     J       HALT
N        WORD    5
ZERO     WORD    0
SUM      RESW    1
I        RESW    1
MSG      BYTE    C'SUM'
         END     FIRST
