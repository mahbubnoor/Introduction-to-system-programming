SUMX     START   0
FIRST    STL     RETADR
         +LDB    #TOTAL
         BASE    TOTAL
         CLEAR   X
         CLEAR   A
         LDS     #3
         LDT     #9
LOOP     ADD     TABLE,X
         ADDR    S,X
         COMPR   X,T
         JLT     LOOP
         STA     TOTAL
         J       @RETADR
RETADR   RESW    1
TABLE    WORD    10
         WORD    20
         WORD    30
BIG      RESB    3000
TOTAL    RESW    1
         END     FIRST
