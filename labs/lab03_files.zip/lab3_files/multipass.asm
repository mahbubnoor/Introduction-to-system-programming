MULTI    START   0
HALF     EQU     TLEN/2
TLEN     EQU     TEXTEND-TEXT
FIRST    LDA     #HALF
         J       FIRST
TEXT     BYTE    C'BANANA'
TEXTEND  EQU     *
         END     FIRST
