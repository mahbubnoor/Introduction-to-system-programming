#include <string.h>

int count_a(void)
{
    const char *text = "BANANA";
    int n = 0;
    for (int i = 0; text[i] != '\0'; i++)
        if (text[i] == 'A')
            n++;
    return n;
}
