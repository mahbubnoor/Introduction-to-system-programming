COUNT    START   2000
FIRST    LDX     ZERO
LOOP     LDA     ZERO
         LDCH    TEXT,X
         COMP    LETTERA
         JEQ     FOUND
NEXT     TIX     LENGTH
         JLT     LOOP
         J       DONE
FOUND    LDA     TOTAL
         ADD     ONE
         STA     TOTAL
         J       NEXT
DONE     J       DONE
TEXT     BYTE    C'BANANA'
LENGTH   WORD    6
LETTERA  WORD    65
ZERO     WORD    0
TOTAL    WORD    0
BUFFER   RESB    100
ONE      WORD    1
         END     FIRST
