/*
 * sicasm.c - a two-pass assembler for the SIC machine (Beck, System Software, Section 2.1)
 * CSE 4105 System Programming, Lab 3   (STUDENT STARTER: fill in the four TODOs)
 *
 * Build:   gcc -Wall -o sicasm sicasm.c
 * Run:     ./sicasm count.asm            -> prints the listing, writes count.obj
 *
 * Source format: a label starts in column 1; otherwise the line starts with a space or tab.
 *   [LABEL]  OPCODE  [OPERAND]   [comment]
 * Lines starting with '.' are comments.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAXLINES 500
#define MAXSYMS  200
#define TEXTMAX  30          /* at most 30 bytes of code in one T record */

/* ---------------- OPTAB: a fixed table, like a const array in any C program ---------------- */
struct op { const char *name; int code; };
static const struct op OPTAB[] = {
    {"ADD", 0x18}, {"AND", 0x40}, {"COMP", 0x28}, {"DIV", 0x24}, {"J", 0x3C},
    {"JEQ", 0x30}, {"JGT", 0x34}, {"JLT", 0x38}, {"JSUB", 0x48}, {"LDA", 0x00},
    {"LDCH", 0x50}, {"LDL", 0x08}, {"LDX", 0x04}, {"MUL", 0x20}, {"OR", 0x44},
    {"RD", 0xD8}, {"RSUB", 0x4C}, {"STA", 0x0C}, {"STCH", 0x54}, {"STL", 0x14},
    {"STSW", 0xE8}, {"STX", 0x10}, {"SUB", 0x1C}, {"TD", 0xE0}, {"TIX", 0x2C},
    {"WD", 0xDC},
};
#define NOPS (int)(sizeof OPTAB / sizeof OPTAB[0])

/* ---------------- SYMTAB: filled in Pass 1, read in Pass 2 ---------------- */
struct sym { char name[16]; int addr; };
static struct sym SYMTAB[MAXSYMS];
static int nsyms = 0;

/* ---------------- one source line, kept in memory between the two passes ---------------- */
struct line {
    char label[16], opcode[16], operand[64];
    int  loc;                 /* address given by Pass 1 */
    char objcode[80];         /* object code made by Pass 2 */
};
static struct line L[MAXLINES];
static int nlines = 0;

static int find_op(const char *name)
{
    for (int i = 0; i < NOPS; i++)
        if (strcmp(OPTAB[i].name, name) == 0)
            return OPTAB[i].code;
    return -1;
}

static int find_sym(const char *name)
{
    for (int i = 0; i < nsyms; i++)
        if (strcmp(SYMTAB[i].name, name) == 0)
            return SYMTAB[i].addr;
    return -1;
}

/* length in bytes of a BYTE constant: C'EOF' -> 3, X'F1' -> 1 */
static int byte_len(const char *c)
{
    int n = (int)strlen(c) - 3;          /* remove C' and the closing ' */
    return c[0] == 'C' ? n : n / 2;
}

/* split one source line into label, opcode, operand. Returns 0 for a blank or comment line. */
static int split(char *buf, struct line *ln)
{
    char *tok[3] = {0};
    int has_label = !isspace((unsigned char)buf[0]);
    if (buf[0] == '.' || buf[strspn(buf, " \t\r\n")] == '\0')
        return 0;
    int n = 0;
    for (char *t = strtok(buf, " \t\r\n"); t && n < 3; t = strtok(NULL, " \t\r\n"))
        tok[n++] = t;
    ln->label[0] = ln->opcode[0] = ln->operand[0] = '\0';
    int k = 0;
    if (has_label) strcpy(ln->label, tok[k++]);
    if (tok[k]) strcpy(ln->opcode, tok[k++]);
    if (k < 3 && tok[k] && strcmp(ln->opcode, "RSUB") != 0) strcpy(ln->operand, tok[k]);
    return 1;
}

int main(int argc, char *argv[])
{
    char buf[256];
    if (argc < 2) { fprintf(stderr, "usage: %s file.asm\n", argv[0]); return 1; }
    FILE *in = fopen(argv[1], "r");
    if (!in) { perror(argv[1]); return 1; }

    /* ======================= PASS 1: give every label an address ======================= */
    int locctr = 0, start = 0;
    while (fgets(buf, sizeof buf, in)) {
        struct line *ln = &L[nlines];
        if (!split(buf, ln)) continue;
        if (strcmp(ln->opcode, "START") == 0) {
            start = locctr = (int)strtol(ln->operand, NULL, 16);
            ln->loc = locctr;
            nlines++;
            continue;
        }
        ln->loc = locctr;
        if (ln->label[0]) {
            /* TODO 1: if the label is already in SYMTAB, print "duplicate symbol" and stop.
             *         Otherwise add (label, locctr) to SYMTAB and increase nsyms.          */
        }
        /* TODO 2: increase locctr by the size of this line:
         *         an instruction or WORD = 3 bytes, RESW n = 3*n, RESB n = n,
         *         BYTE = byte_len(operand), END = 0. Anything else: "unknown opcode".    */
        nlines++;
    }
    fclose(in);
    int length = locctr - start;

    /* ======================= PASS 2: make the object code ======================= */
    for (int i = 0; i < nlines; i++) {
        struct line *ln = &L[i];
        int opc = find_op(ln->opcode);
        ln->objcode[0] = '\0';
        if (opc >= 0) {
            /* TODO 3: build the 3-byte instruction.
             *   - if the operand ends in ",X", remove it and set x = 1
             *   - look up the operand in SYMTAB (error if it is not there); RSUB has no operand
             *   - objcode = opcode (8 bits) | x (1 bit) | address (15 bits), printed as 6 hex digits */
        } else if (!strcmp(ln->opcode, "WORD")) {
            sprintf(ln->objcode, "%06X", atoi(ln->operand) & 0xFFFFFF);
        } else if (!strcmp(ln->opcode, "BYTE")) {
            /* TODO 4: C'EOF' -> "454F46" (two hex digits per character),
             *         X'F1'  -> "F1"     (copy the hex digits between the quotes)        */
        }
    }

    /* ---------------- listing ---------------- */
    for (int i = 0; i < nlines; i++)
        printf("%04X  %-8s %-6s %-12s %s\n", L[i].loc, L[i].label, L[i].opcode, L[i].operand, L[i].objcode);

    /* ---------------- object program: H, T..., E ---------------- */
    char objname[256];
    strcpy(objname, argv[1]);
    char *dot = strrchr(objname, '.');
    if (dot) *dot = '\0';
    strcat(objname, ".obj");
    FILE *out = fopen(objname, "w");
    if (!out) { perror(objname); return 1; }

    fprintf(out, "H%-6.6s%06X%06X\n", L[0].label, start, length);
    char text[2 * TEXTMAX + 1] = "";
    int tstart = -1, tlen = 0, expect = -1;
    for (int i = 0; i < nlines; i++) {
        int n = (int)strlen(L[i].objcode) / 2;
        if (n == 0) continue;                       /* RESW/RESB make no code */
        if (tstart >= 0 && (L[i].loc != expect || tlen + n > TEXTMAX)) {
            fprintf(out, "T%06X%02X%s\n", tstart, tlen, text);   /* close the record */
            tstart = -1;
        }
        if (tstart < 0) { tstart = L[i].loc; tlen = 0; text[0] = '\0'; }
        strcat(text, L[i].objcode);
        tlen += n;
        expect = L[i].loc + n;
    }
    if (tstart >= 0)
        fprintf(out, "T%06X%02X%s\n", tstart, tlen, text);
    int first = start;
    for (int i = 0; i < nlines; i++)
        if (!strcmp(L[i].opcode, "END") && L[i].operand[0])
            first = find_sym(L[i].operand);
    fprintf(out, "E%06X\n", first);
    fclose(out);
    printf("\nobject program written to %s (%d symbols, program length %04X)\n", objname, nsyms, length);
    return 0;
}
