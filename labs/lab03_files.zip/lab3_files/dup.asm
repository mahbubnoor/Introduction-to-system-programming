BAD      START   1000
FIRST    LDA     ALPHA
         STA     BETA
FIRST    J       FIRST
ALPHA    WORD    5
         END     FIRST
