BAD      START   1000
FIRST    LDA     ALPHA
         STA     BETA
HALT     J       HALT
ALPHA    WORD    5
         END     FIRST
