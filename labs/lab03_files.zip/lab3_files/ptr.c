int main(void)
{
    char text[] = "BANANA";
    char *p = text, *q = text + 6;
    long len = q - p;     /* pointer - pointer = a number   */
    char *r = p + 3;      /* pointer + number  = a pointer  */
    char *bad = p + q;    /* pointer + pointer = error      */
    return (int)len + *r + (bad != 0);
}
