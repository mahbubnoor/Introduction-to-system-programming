MAIN     START   0
         EXTDEF  TEXT,TEXTEND
         EXTREF  COUNTA
FIRST    STL     RETADR
         +JSUB   COUNTA
         STA     CNT
         J       @RETADR
RETADR   RESW    1
CNT      RESW    1
TEXT     BYTE    C'BANANA'
TEXTEND  EQU     *
COUNTA   CSECT
         EXTREF  TEXT,TEXTEND
         CLEAR   X
         CLEAR   S
         LDT     LEN
LOOP     CLEAR   A
         +LDCH   TEXT,X
         COMP    #65
         JEQ     FOUND
NEXT     TIXR    T
         JLT     LOOP
         RMO     S,A
         RSUB
FOUND    LDA     #1
         ADDR    A,S
         J       NEXT
LEN      WORD    TEXTEND-TEXT
         END     FIRST
