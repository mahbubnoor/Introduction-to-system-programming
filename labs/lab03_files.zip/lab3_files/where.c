#include <stdio.h>

int counter = 5;

int main(void)
{
    printf("main    is at %p\n", (void *)main);
    printf("counter is at %p\n", (void *)&counter);
    return 0;
}
