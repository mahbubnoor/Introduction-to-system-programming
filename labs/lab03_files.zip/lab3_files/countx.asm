COUNTX   START   0
FIRST    STL     RETADR
         +LDB    #TOTAL
         BASE    TOTAL
         CLEAR   X
         LDT     #6
LOOP     CLEAR   A
         LDCH    TEXT,X
         COMP    #65
         JEQ     FOUND
NEXT     TIXR    T
         JLT     LOOP
         LDA     CNT
         STA     TOTAL
         +JSUB   REPORT
         J       @RETADR
FOUND    LDA     CNT
         ADD     #1
         STA     CNT
         J       NEXT
RETADR   RESW    1
CNT      WORD    0
TEXT     BYTE    C'BANANA'
BUFFER   RESB    4096
TOTAL    RESW    1
REPORT   RSUB
         END     FIRST
