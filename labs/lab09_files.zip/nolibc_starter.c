/*
 * nolibc_starter.c - a C program with no C library: we make the system calls ourselves
 * CSE 4105 System Programming, Lab 9   (STARTER: fill in the parts marked TODO)
 *
 * Build:  gcc -Wall -O1 -ffreestanding -nostdlib -static -fno-stack-protector -o nolibc nolibc_starter.c
 * Run:    ./nolibc hello ; echo $?        then:  strace ./nolibc hello
 *
 * -nostdlib: no C library at all (no printf, no strlen, no main, no exit).
 * Until TODO 1 works, nothing is printed and the program ends with "Illegal instruction":
 * exit never reached the kernel, so we stop the program with a trap instruction.
 */
typedef unsigned long size_t;
typedef long ssize_t;

/* x86-64 Linux: number in rax; arguments in rdi, rsi, rdx; result in rax.
   The syscall instruction overwrites rcx and r11, so we must tell gcc they change. */
static long my_syscall3(long nr, long a1, long a2, long a3)
{
    long ret = -38;     /* -ENOSYS: "no such system call", until you write the real one */
    /* TODO 1: replace the line above by inline assembly:
     *   __asm__ volatile ("syscall"
     *                     : "=a"(ret)                                   output: rax
     *                     : "a"(nr), "D"(a1), "S"(a2), "d"(a3)          inputs: rax rdi rsi rdx
     *                     : "rcx", "r11", "memory");                    changed by syscall
     */
    (void)nr; (void)a1; (void)a2; (void)a3;
    return ret;
}

/* TODO 2: the system call numbers. Find them in /usr/include/x86_64-linux-gnu/asm/unistd_64.h
 *         (grep for __NR_write, __NR_getpid, __NR_exit) and replace the 1000s below.
 *         1000 is not a system call: the kernel answers -38 (ENOSYS) for it. */
static ssize_t my_write(int fd, const void *buf, size_t n) { return my_syscall3(1000 /* TODO */, fd, (long)buf, n); }
static long my_getpid(void) { return my_syscall3(1000 /* TODO */, 0, 0, 0); }
static void my_exit(int status) { my_syscall3(1000 /* TODO */, status, 0, 0); __builtin_trap(); }

static size_t my_strlen(const char *s) { size_t n = 0; while (s[n]) n++; return n; }
static void put(const char *s) { my_write(1, s, my_strlen(s)); }

/* TODO 3: print a long in decimal, without printf. Hint: fill a char array from the END:
 *         the last digit is v % 10, then v /= 10; repeat; then a '-' if v was negative. */
static void put_num(long v)
{
    (void)v;
    put("?");
}

/* No libc, so no main: the kernel jumps to _start (Lecture 8.2) with rsp -> argc. */
void _start_c(long *sp)
{
    long argc = 0;            /* TODO 4: argc is at sp[0]; argv[0] is at sp[1], argv[1] at sp[2], ... */
    char **argv = 0;
    (void)sp;
    put("my PID is ");
    put_num(my_getpid());
    put("\nargc = ");
    put_num(argc);
    put("\n");
    for (long i = 1; i < argc; i++) { put("argv: "); put(argv[i]); put("\n"); }
    long r = my_write(42, "x", 1);                 /* fd 42 is not open */
    put("write(42, ...) returned ");
    put_num(r);
    put("   (the kernel returns -errno; 9 = EBADF)\n");
    my_exit(argc);
}
__asm__(".globl _start\n"
        "_start:\n"
        "  mov %rsp, %rdi\n"      /* pass the stack pointer: argc is there */
        "  and $-16, %rsp\n"      /* align the stack as the C ABI wants */
        "  call _start_c\n");
