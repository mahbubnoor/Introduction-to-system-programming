/* syscost.c - how much does crossing into the kernel cost? */
#define _GNU_SOURCE
#include <stdio.h>
#include <time.h>
#include <unistd.h>
#include <sys/syscall.h>
#define N 2000000
static double now(void)
{
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec * 1e9 + t.tv_nsec;
}
__attribute__((noinline)) static long plain_function(long x) { __asm__ volatile ("" ::: "memory"); return x + 1; }
static long raw_getpid(void)
{
    long r;
    __asm__ volatile ("syscall" : "=a"(r) : "a"(SYS_getpid) : "rcx", "r11", "memory");
    return r;
}
int main(void)
{
    struct timespec ts;
    volatile long sink = 0;
    double t0, t1;
    t0 = now(); for (long i = 0; i < N; i++) sink += plain_function(i);                      t1 = now();
    printf("a C function call                  %7.1f ns\n", (t1 - t0) / N);
    t0 = now(); for (long i = 0; i < N; i++) sink += raw_getpid();                           t1 = now();
    printf("getpid, raw syscall instruction    %7.1f ns\n", (t1 - t0) / N);
    t0 = now(); for (long i = 0; i < N; i++) sink += getpid();                               t1 = now();
    printf("getpid() from libc                 %7.1f ns\n", (t1 - t0) / N);
    t0 = now(); for (long i = 0; i < N; i++) { clock_gettime(CLOCK_MONOTONIC, &ts); sink += ts.tv_nsec; } t1 = now();
    printf("clock_gettime() from libc (vDSO)   %7.1f ns\n", (t1 - t0) / N);
    t0 = now(); for (long i = 0; i < N; i++) { syscall(SYS_clock_gettime, CLOCK_MONOTONIC, &ts); sink += ts.tv_nsec; } t1 = now();
    printf("clock_gettime as a real syscall    %7.1f ns\n", (t1 - t0) / N);
    t0 = now(); for (long i = 0; i < N; i++) sink += write(-1, "", 0);                       t1 = now();
    printf("write(-1, ...) failing at once     %7.1f ns\n", (t1 - t0) / N);
    return 0;
}
