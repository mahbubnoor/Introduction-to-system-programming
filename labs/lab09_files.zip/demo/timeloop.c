/* timeloop.c - 1000 calls to clock_gettime and gettimeofday: how many system calls? */
#include <stdio.h>
#include <time.h>
#include <sys/time.h>
int main(void)
{
    struct timespec ts; struct timeval tv; long sum = 0;
    for (int i = 0; i < 1000; i++) {
        clock_gettime(CLOCK_MONOTONIC, &ts); gettimeofday(&tv, NULL);
        sum += ts.tv_nsec + tv.tv_usec;
    }
    printf("%d\n", sum != 0);
    return 0;
}
