# rawhello.s - hello world with no C library: two system calls, nothing else
# Build: gcc -nostdlib -static -o rawhello rawhello.s
        .globl  _start
        .text
_start:
        mov     $1, %rax            # system call number 1 = write
        mov     $1, %rdi            # arg 1: fd 1 (the screen)
        lea     msg(%rip), %rsi     # arg 2: address of the bytes
        mov     $len, %rdx          # arg 3: how many bytes
        syscall                     # enter the kernel; result in rax
        mov     $60, %rax           # system call number 60 = exit
        mov     $0, %rdi            # arg 1: exit status 0
        syscall                     # never returns
        .section .rodata
msg:    .ascii  "hello from the kernel, no libc\n"
        len = . - msg
