#define _GNU_SOURCE
#include <sched.h>
#include <stdio.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>
int main(void)
{
    struct timespec ts; struct timeval tv;
    write(1, "-- time\n", 8);          time(NULL);
    write(1, "-- gettimeofday\n", 16); gettimeofday(&tv, NULL);
    write(1, "-- clock_gettime\n", 17); clock_gettime(CLOCK_MONOTONIC, &ts);
    write(1, "-- sched_getcpu\n", 16); sched_getcpu();
    write(1, "-- getpid x3\n", 13);    getpid(); getpid(); getpid();
    write(1, "-- getppid\n", 11);      getppid();
    write(1, "-- end\n", 7);
    return 0;
}
