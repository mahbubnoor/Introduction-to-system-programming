/* libsys.c - which C library calls become system calls?  Run: strace ./libsys */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
int main(void)
{
    write(1, "--- start\n", 10);              /* a marker in the trace */
    size_t n = strlen("hello");                /* 1 */
    char *p = malloc(100);                     /* 2 */
    char *q = malloc(200000);                  /* 3 */
    time_t t = time(NULL);                     /* 4 */
    pid_t me = getpid();                       /* 5 */
    printf("n=%zu me=%d t>0:%d\n", n, me, t > 0);  /* 6 */
    printf("second line\n");                   /* 7 */
    free(q);                                   /* 8 */
    free(p);
    write(1, "--- end\n", 8);
    return 0;
}
