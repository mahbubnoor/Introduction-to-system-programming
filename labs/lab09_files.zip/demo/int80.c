/* int80.c - the old 32-bit way into the kernel, from a 64-bit program */
#include <stdio.h>
static const char msg[] = "hello through int 0x80\n";   /* static, non-PIE build: address below 4 GB */
int main(void)
{
    long r;
    __asm__ volatile ("int $0x80"
                      : "=a"(r)
                      : "a"(4), "b"(1), "c"(msg), "d"(sizeof msg - 1) 
                      : "memory");
    printf("int $0x80 returned %ld\n", r);
    long r2;
    __asm__ volatile ("syscall" : "=a"(r2) : "a"(4), "D"(1), "S"(msg), "d"(sizeof msg - 1) : "rcx", "r11", "memory");
    printf("syscall with rax = 4 returned %ld\n", r2);
    return 0;
}
