/* bytes.c - write 1 MiB one byte at a time: with write() or with putchar()? */
#include <stdio.h>
#include <string.h>
#include <unistd.h>
int main(int argc, char *argv[])
{
    int raw = argc > 1 && strcmp(argv[1], "write") == 0;
    for (int i = 0; i < 1 << 20; i++)
        if (raw) { if (write(1, "x", 1) != 1) return 1; } else putchar('x');
    return 0;
}
