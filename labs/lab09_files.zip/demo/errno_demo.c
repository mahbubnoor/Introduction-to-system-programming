/* errno_demo.c - how the kernel reports errors, and what libc does with them */
#define _GNU_SOURCE
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/syscall.h>
static long raw3(long nr, long a1, long a2, long a3)      /* the bare kernel answer */
{
    long ret;
    __asm__ volatile ("syscall" : "=a"(ret) : "a"(nr), "D"(a1), "S"(a2), "d"(a3) : "rcx", "r11", "memory");
    return ret;
}
static void show(const char *what, long r)
{
    int e = errno;                                        /* save it first: printf may change errno */
    printf("%-40s returns %3ld", what, r);
    if (r == -1) printf("   errno = %2d  %s", e, strerror(e));
    printf("\n");
}
int main(void)
{
    char *volatile nothing = NULL;                        /* volatile: so gcc does not warn */
    errno = 0; show("raw syscall: write(42, \"x\", 1)", raw3(SYS_write, 42, (long)"x", 1));
    errno = 0; show("libc: write(42, \"x\", 1)", write(42, "x", 1));
    errno = 0; show("libc: write(1, NULL, 5)", write(1, nothing, 5));
    errno = 0; show("libc: write(1, kernel address, 5)", write(1, (void *)0xffffffff81000000UL, 5));
    errno = 0; show("libc: syscall(1000)", syscall(1000));
    errno = 0; show("raw syscall: syscall(1000)", raw3(1000, 0, 0, 0));
    errno = 0; show("libc: write(1, \"ok\\n\", 3)", write(1, "ok\n", 3));
    return 0;
}
