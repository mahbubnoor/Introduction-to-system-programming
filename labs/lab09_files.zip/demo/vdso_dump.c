/* vdso_dump.c - copy the vDSO, the small library the kernel puts into every process, into a file */
#include <stdio.h>
#include <string.h>
#include <sys/auxv.h>
int main(void)
{
    unsigned long base = getauxval(AT_SYSINFO_EHDR);       /* the kernel told us where (Lecture 8.2) */
    char line[256];
    unsigned long lo, hi;
    FILE *m = fopen("/proc/self/maps", "r");
    while (fgets(line, sizeof line, m))
        if (strstr(line, "[vdso]") && sscanf(line, "%lx-%lx", &lo, &hi) == 2) break;
    fclose(m);
    printf("AT_SYSINFO_EHDR = 0x%lx, [vdso] = %lx-%lx (%lu bytes)\n", base, lo, hi, hi - lo);
    FILE *f = fopen("vdso.so", "wb");
    fwrite((void *)lo, 1, hi - lo, f);                      /* it is ordinary memory: just copy it */
    fclose(f);
    printf("wrote vdso.so; try: readelf -h vdso.so ; objdump -T vdso.so\n");
    return 0;
}
