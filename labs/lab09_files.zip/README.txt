CSE 4105 System Programming - Lab 9 (Lecture 9): system calls
==============================================================
Works offline. Needs: gcc, strace, gdb (Ubuntu's normal developer packages).

LAB 9  nolibc: a C program with no C library
  gcc -Wall -O1 -ffreestanding -nostdlib -static -fno-stack-protector -o nolibc nolibc_starter.c
  ./nolibc hello world ; echo $?          strace ./nolibc hello
  TODO 1 my_syscall3 (inline assembly)    TODO 2 the numbers (grep __NR_ /usr/include/x86_64-linux-gnu/asm/unistd_64.h)
  TODO 3 put_num                           TODO 4 argc and argv from the stack
  Before TODO 1 the program prints nothing and ends with "Illegal instruction": that is expected.
  Use -O1, not -O2: at -O2 gcc replaces the strlen loop by a call to strlen, which does not exist without libc.

  Then:  gcc -Wall -O2 -o syscost syscost.c && ./syscost     (run it 3 times; numbers vary)

DEMO PROGRAMS (demo/), the ones on the slides:
  gcc -nostdlib -static -o rawhello rawhello.s && ./rawhello && strace ./rawhello
  gcc -Wall -O0 -o libsys libsys.c && strace ./libsys            (the quiz: which lines enter the kernel?)
  gcc -Wall -O2 -o errno_demo errno_demo.c && ./errno_demo
  gcc -Wall -O2 -o vdso_dump vdso_dump.c && ./vdso_dump && objdump -T vdso.so
  gcc -Wall -O2 -o timeloop timeloop.c && strace -c ./timeloop
  Homework: gcc -O2 -static -o int80 int80.c ; gcc -O2 -o bytes bytes.c ; gcc -o which which.c
  gdb -batch -ex "disassemble getpid" -ex "disassemble write" /lib/x86_64-linux-gnu/libc.so.6

tables/: the system call tables of Linux 6.8: x86-64 (syscall_64.tbl), i386 (syscall_32.tbl),
         and the generic one used by arm64 and RISC-V (asm-generic_unistd.h).  For Homework 3.
