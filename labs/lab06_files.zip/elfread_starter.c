/*
 * elfread.c - a small readelf: header, sections, symbols, relocations, program headers
 * CSE 4105 System Programming, Lab 6   (STARTER: fill in the parts marked TODO)
 *
 * TODO 1 header check, TODO 2 sections, TODO 3 symbols, TODO 4 relocations, TODO 5 program headers.
 * The program compiles and runs at every stage; each TODO makes one more part of the output appear.
 *
 * Build:  gcc -Wall -o elfread elfread.c
 * Run:    ./elfread main.o        ./elfread count        ./elfread tiny
 *
 * Only 64-bit little-endian ELF files (what gcc makes on the lab PCs).
 * Idea: read the whole file into memory, then point C structs from <elf.h> at the bytes.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <elf.h>

static unsigned char *buf;      /* the whole file */
static long fsize;

static void die(const char *msg)
{
    fflush(stdout);
    fprintf(stderr, "elfread: %s\n", msg);
    exit(1);
}

/* make sure bytes [off, off + n) are inside the file before we touch them */
static void *at(unsigned long off, unsigned long n)
{
    if (off > (unsigned long)fsize || n > (unsigned long)fsize - off)
        die("file is truncated or damaged (an offset points outside it)");
    return buf + off;
}

static const char *type_name(int t)
{
    switch (t) {
    case ET_REL:  return "REL (relocatable: a .o file)";
    case ET_EXEC: return "EXEC (executable at a fixed address)";
    case ET_DYN:  return "DYN (shared object or PIE executable)";
    case ET_CORE: return "CORE (core dump)";
    default:      return "unknown";
    }
}

static const char *sec_type(unsigned t)
{
    switch (t) {
    case SHT_NULL: return "NULL";       case SHT_PROGBITS: return "PROGBITS";
    case SHT_SYMTAB: return "SYMTAB";   case SHT_STRTAB: return "STRTAB";
    case SHT_RELA: return "RELA";       case SHT_HASH: return "HASH";
    case SHT_DYNAMIC: return "DYNAMIC"; case SHT_NOTE: return "NOTE";
    case SHT_NOBITS: return "NOBITS";   case SHT_DYNSYM: return "DYNSYM";
    case SHT_INIT_ARRAY: return "INIT_ARRAY"; case SHT_FINI_ARRAY: return "FINI_ARRAY";
    case SHT_GNU_HASH: return "GNU_HASH"; case SHT_GNU_versym: return "VERSYM";
    case SHT_GNU_verneed: return "VERNEED";
    default: return "OTHER";
    }
}

static const char *sym_type(int t)
{
    switch (t) {
    case STT_NOTYPE: return "NOTYPE";   case STT_OBJECT: return "OBJECT";
    case STT_FUNC: return "FUNC";       case STT_SECTION: return "SECTION";
    case STT_FILE: return "FILE";       default: return "OTHER";
    }
}

static const char *sym_bind(int b)
{
    switch (b) {
    case STB_LOCAL: return "LOCAL";     case STB_GLOBAL: return "GLOBAL";
    case STB_WEAK: return "WEAK";       default: return "OTHER";
    }
}

static const char *rel_type(unsigned t)
{
    switch (t) {
    case R_X86_64_64: return "R_X86_64_64";             case R_X86_64_PC32: return "R_X86_64_PC32";
    case R_X86_64_PLT32: return "R_X86_64_PLT32";       case R_X86_64_GLOB_DAT: return "R_X86_64_GLOB_DAT";
    case R_X86_64_JUMP_SLOT: return "R_X86_64_JUMP_SLOT"; case R_X86_64_RELATIVE: return "R_X86_64_RELATIVE";
    case R_X86_64_GOTPCREL: return "R_X86_64_GOTPCREL"; case R_X86_64_32: return "R_X86_64_32";
    case R_X86_64_32S: return "R_X86_64_32S";           case R_X86_64_GOTPCRELX: return "R_X86_64_GOTPCRELX";
    case R_X86_64_REX_GOTPCRELX: return "R_X86_64_REX_GOTPCRELX";
    default: return "other";
    }
}

static const char *seg_type(unsigned t)
{
    switch (t) {
    case PT_NULL: return "NULL";        case PT_LOAD: return "LOAD";
    case PT_DYNAMIC: return "DYNAMIC";  case PT_INTERP: return "INTERP";
    case PT_NOTE: return "NOTE";        case PT_PHDR: return "PHDR";
    case PT_TLS: return "TLS";          case PT_GNU_EH_FRAME: return "GNU_EH_FRAME";
    case PT_GNU_STACK: return "GNU_STACK"; case PT_GNU_RELRO: return "GNU_RELRO";
    case PT_GNU_PROPERTY: return "GNU_PROPERTY";
    default: return "OTHER";
    }
}

int main(int argc, char *argv[])
{
    if (argc != 2) { fprintf(stderr, "usage: %s file\n", argv[0]); return 1; }

    /* ---- read the whole file into buf ---- */
    FILE *f = fopen(argv[1], "rb");
    if (!f) { perror(argv[1]); return 1; }
    fseek(f, 0, SEEK_END);
    fsize = ftell(f);
    rewind(f);
    buf = malloc(fsize > 0 ? fsize : 1);
    if (!buf || fread(buf, 1, fsize, f) != (size_t)fsize) die("cannot read the file");
    fclose(f);

    /* ================= 1. the ELF header: the first 64 bytes ================= */
    /* TODO 1: if the file is shorter than sizeof(Elf64_Ehdr), or its first SELFMAG (4) bytes
     *         are not ELFMAG ("\177ELF"), call die("not an ELF file (the first 4 bytes are not 7f 45 4c 46)").
     *         Hint: memcmp(buf, ELFMAG, SELFMAG).  Test: ./elfread elfread.c                          */

    if (buf[EI_CLASS] != ELFCLASS64 || buf[EI_DATA] != ELFDATA2LSB)
        die("only 64-bit little-endian ELF files are supported");
    Elf64_Ehdr *eh = (Elf64_Ehdr *)buf;

    printf("ELF header\n");
    printf("  Type:                %s\n", type_name(eh->e_type));
    printf("  Machine:             %d%s\n", eh->e_machine, eh->e_machine == EM_X86_64 ? " (x86-64)" : "");
    printf("  Entry point:         0x%lx\n", (unsigned long)eh->e_entry);
    printf("  Program headers:     %d, at offset %lu, %d bytes each\n", eh->e_phnum, (unsigned long)eh->e_phoff, eh->e_phentsize);
    printf("  Section headers:     %d, at offset %lu, %d bytes each\n", eh->e_shnum, (unsigned long)eh->e_shoff, eh->e_shentsize);
    printf("  Section name table:  section %d\n", eh->e_shstrndx);

    /* ================= 2. the section header table ================= */
    Elf64_Shdr *sh = NULL;
    const char *shstr = NULL;
    if (eh->e_shnum > 0) {
        /* TODO 2: the section header table is an ARRAY of e_shnum Elf64_Shdr structs at file offset e_shoff.
         *   sh    = at(eh->e_shoff, e_shnum * sizeof(Elf64_Shdr));
         *   shstr = the contents of section number e_shstrndx (use its sh_offset and sh_size with at()).
         *   Then print one line per section, in this format (the name is shstr + sh[i].sh_name):
         *   printf("  [%2d] %-20s %-10s %08lx %08lx %lx\n", i, name, sec_type(type), offset, size, address);  */
        printf("\nSections\n");
        printf("  [Nr] %-20s %-10s %-8s %-8s %s\n", "Name", "Type", "Offset", "Size", "Address");
        if (!sh) { printf("  (TODO 2 not done yet)\n"); }
    } else {
        printf("\nSections\n  (none: this file has no section header table)\n");
    }

    /* ================= 3. symbols: .symtab (or .dynsym if the file was stripped) ================= */
    for (int pass = 0; pass < 2 && sh; pass++) {
        unsigned want = pass == 0 ? SHT_SYMTAB : SHT_DYNSYM;
        int found = 0;
        for (int i = 0; i < eh->e_shnum; i++) {
            if (sh[i].sh_type != want) continue;
            found = 1;
            Elf64_Sym *sym = at(sh[i].sh_offset, sh[i].sh_size);
            /* TODO 3a: the names are in another section: number sh[i].sh_link. Point str at its contents.
             * TODO 3b: n = how many Elf64_Sym structs fit in sh[i].sh_size bytes?                         */
            const char *str = "";
            int n = 0;
            printf("\nSymbols in %s (%d)\n", shstr + sh[i].sh_name, n);
            printf("  %3s %-16s %5s %-7s %-6s %-4s %s\n", "Num", "Value", "Size", "Type", "Bind", "Ndx", "Name");
            for (int k = 0; k < n; k++) {
                char ndx[8];
                if (sym[k].st_shndx == SHN_UNDEF) strcpy(ndx, "UND");
                else if (sym[k].st_shndx == SHN_ABS) strcpy(ndx, "ABS");
                else snprintf(ndx, sizeof ndx, "%d", sym[k].st_shndx);
                printf("  %3d %016lx %5lu %-7s %-6s %-4s %s\n", k, (unsigned long)sym[k].st_value, (unsigned long)sym[k].st_size,
                       /* TODO 3c: st_info packs two numbers: use ELF64_ST_TYPE() and ELF64_ST_BIND() */
                       sym_type(0), sym_bind(0), ndx, str + sym[k].st_name);
            }
        }
        if (found) break;            /* .symtab found: do not print .dynsym too */
    }

    /* ================= 4. relocations: every SHT_RELA section ================= */
    for (int i = 0; sh && i < eh->e_shnum; i++) {
        if (sh[i].sh_type != SHT_RELA) continue;
        Elf64_Rela *r = at(sh[i].sh_offset, sh[i].sh_size);
        int n = sh[i].sh_size / sizeof(Elf64_Rela);
        Elf64_Shdr *symsec = &sh[sh[i].sh_link];                 /* sh_link = the symbol table it uses */
        Elf64_Sym *sym = at(symsec->sh_offset, symsec->sh_size);
        const char *str = at(sh[symsec->sh_link].sh_offset, sh[symsec->sh_link].sh_size);
        printf("\nRelocations in %s (%d)\n", shstr + sh[i].sh_name, n);
        printf("  %-12s %-22s %-14s %s\n", "Offset", "Type", "Symbol", "Addend");
        for (int k = 0; k < n; k++) {
            /* TODO 4: r_info = (symbol index << 32) | type. Take them apart with ELF64_R_SYM and ELF64_R_TYPE. */
            unsigned s = 0, t = 0;
            const char *name = "";
            if (s != 0) {
                name = str + sym[s].st_name;
                if (ELF64_ST_TYPE(sym[s].st_info) == STT_SECTION)    /* a section symbol has no name: use the section's */
                    name = shstr + sh[sym[s].st_shndx].sh_name;
            }
            printf("  %012lx %-22s %-14s %ld\n", (unsigned long)r[k].r_offset, rel_type(t), name, (long)r[k].r_addend);
        }
    }

    /* ================= 5. program headers: what the kernel loads ================= */
    printf("\nProgram headers\n");
    if (eh->e_phnum == 0) {
        printf("  (none: this file cannot be run, only linked)\n");
    } else {
        printf("  %-13s %-8s %-16s %-8s %-8s %s\n", "Type", "Offset", "VirtAddr", "FileSiz", "MemSiz", "Flags");
        /* TODO 5: an array of e_phnum Elf64_Phdr at offset e_phoff (like TODO 2). One line each:
         *   printf("  %-13s %08lx %016lx %08lx %08lx %c%c%c\n", seg_type(p_type), p_offset, p_vaddr,
         *          p_filesz, p_memsz, R or -, W or -, X or -);      flags: p_flags & PF_R, PF_W, PF_X     */
    }
    free(buf);
    return 0;
}
