CSE 4105 System Programming - Lab 6: Object file formats (ELF)
==============================================================
Works offline on the lab PCs. Needs gcc, binutils (readelf, objdump, nm, strip, size), nasm, strace.

PART 1  Write a small readelf: elfread_starter.c
  gcc -Wall -o elfread elfread_starter.c
  TODO 1  check the magic number                    ./elfread elfread_starter.c  -> "not an ELF file"
  TODO 2  section header table and section names     compare with: readelf -S main.o
  TODO 3  symbols (sh_link, ELF64_ST_TYPE/BIND)      compare with: readelf -s main.o
  TODO 4  relocations (ELF64_R_SYM/TYPE)             compare with: readelf -r main.o
  TODO 5  program headers                            compare with: readelf -l count
  Final check (uses the files in reference_objects/, built on Ubuntu 24.04 with gcc 13.3):
     ./elfread reference_objects/main.o     | diff - expected_main.o.txt
     ./elfread reference_objects/sections.o | diff - expected_sections.o.txt
     ./elfread reference_objects/tiny       | diff - expected_tiny.txt
  No output from diff means your program is right.
  reference_objects/count is the program used for homework 1.

PART 2  Demos (folder demo/)
  cd demo && ./run_all6.sh > my_output.txt 2>&1   and compare with run_all6_output.txt.
  tiny.asm: a complete 132-byte program with a hand-written ELF header (nasm -f bin).
  Files you build yourself may differ slightly from ours with another gcc version;
  that is fine, the structure is the same.
