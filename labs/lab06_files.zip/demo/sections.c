/* sections.c - where does each line of C go in the object file? */
int counter = 5;                 /* initialised global      */
int buffer[1000];                /* uninitialised global    */
const char title[] = "BANANA";   /* constant                */
static int hidden = 7;           /* static: only this file  */
static int helper(int x)         /* static function         */
{
    return x + hidden;
}
int count_calls(void)            /* ordinary function       */
{
    static int calls;            /* static local            */
    int local = helper(1);       /* local: on the stack     */
    calls++;
    return calls + local + counter + buffer[0] + title[0];
}
