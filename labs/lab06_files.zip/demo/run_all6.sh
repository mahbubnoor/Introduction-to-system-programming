#!/bin/bash
# Lecture 6 demos (ELF). Run in this folder on the lab PC; no internet needed.
set -x
gcc -c main.c counta.c data.c sections.c
gcc -no-pie -o count main.o counta.o data.o
gcc -o count_pie main.o counta.o data.o
gcc -fPIC -shared -o libcount.so counta.c data.c
file main.o count count_pie libcount.so
od -A x -t x1z -N 64 main.o                 # the ELF header, raw
readelf -h main.o
readelf -h count
gcc -o sizes sizes.c && ./sizes            # the C structs from <elf.h>
readelf -SW main.o                         # sections
nm sections.o
readelf -sW sections.o                     # symbols: LOCAL = static
size sections.o
sed 's/int buffer\[1000\];  /int buffer[1000] = {1};/' sections.c > sections_init.c
gcc -c sections_init.c && ls -l sections.o sections_init.o
readelf -p .strtab main.o
readelf -x .strtab main.o
readelf -rW main.o                         # relocations
gcc -o st a1.c a2.c && ./st; echo "exit=$?"    # two static helper() functions: fine
readelf -lW count                          # program headers (segments)
objdump -d count | sed -n '/<_start>:/,/hlt/p'
readelf -dW count_pie | head -5
cp count count_strip && strip count_strip && ls -l count count_strip && ./count_strip
nm count_strip; nm -D count_strip
nasm -f bin tiny.asm -o tiny && chmod +x tiny && ./tiny; echo "exit=$?"
ls -l tiny; od -A x -t x1 tiny; readelf -hl tiny
strace ./tiny
cp count bad && printf 'X' | dd of=bad bs=1 seek=1 conv=notrunc 2>/dev/null && ./bad; echo "exit=$?"
readelf -h bad
chmod +x main.o; ./main.o; echo "exit=$?"
