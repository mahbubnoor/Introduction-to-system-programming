static int helper(void) { return 2; }
int f2(void) { return helper(); }
int f1(void);
int main(void) { return f1() + f2(); }
