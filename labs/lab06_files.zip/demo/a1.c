static int helper(void) { return 1; }
int f1(void) { return helper(); }
