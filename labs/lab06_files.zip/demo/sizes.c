/* sizes.c - the ELF structures are ordinary C structs (from /usr/include/elf.h) */
#include <stdio.h>
#include <elf.h>
int main(void)
{
    printf("Elf64_Ehdr %zu bytes (file header)\n", sizeof(Elf64_Ehdr));
    printf("Elf64_Shdr %zu bytes (one section header)\n", sizeof(Elf64_Shdr));
    printf("Elf64_Phdr %zu bytes (one program header)\n", sizeof(Elf64_Phdr));
    printf("Elf64_Sym  %zu bytes (one symbol)\n", sizeof(Elf64_Sym));
    printf("Elf64_Rela %zu bytes (one relocation)\n", sizeof(Elf64_Rela));
    return 0;
}
