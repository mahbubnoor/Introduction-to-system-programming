; tiny.asm - a complete Linux x86-64 program, ELF header written by hand
; build:  nasm -f bin tiny.asm -o tiny && chmod +x tiny && ./tiny; echo $?
BITS 64
        org     0x400000                ; where the program will be in memory

ehdr:                                   ; ---- ELF header (Elf64_Ehdr), 64 bytes
        db      0x7F, "ELF"             ; e_ident: magic number
        db      2, 1, 1, 0              ;   64-bit, little-endian, version 1, System V
        times 8 db 0                    ;   padding
        dw      2                       ; e_type:      2 = EXEC
        dw      0x3E                    ; e_machine:   62 = x86-64
        dd      1                       ; e_version
        dq      _start                  ; e_entry:     first instruction
        dq      phdr - $$               ; e_phoff:     program headers start here
        dq      0                       ; e_shoff:     no section headers at all
        dd      0                       ; e_flags
        dw      ehdrsize                ; e_ehsize:    64
        dw      phdrsize                ; e_phentsize: 56
        dw      1                       ; e_phnum:     one program header
        dw      0, 0, 0                 ; e_shentsize, e_shnum, e_shstrndx
ehdrsize equ $ - ehdr

phdr:                                   ; ---- program header (Elf64_Phdr), 56 bytes
        dd      1                       ; p_type:   1 = PT_LOAD
        dd      5                       ; p_flags:  R + X  (4 + 1)
        dq      0                       ; p_offset: from the start of the file
        dq      $$                      ; p_vaddr:  to address 0x400000
        dq      $$                      ; p_paddr
        dq      filesize                ; p_filesz
        dq      filesize                ; p_memsz
        dq      0x1000                  ; p_align
phdrsize equ $ - phdr

_start:                                 ; ---- the code, 12 bytes
        mov     edi, 42                 ; exit status
        mov     eax, 60                 ; system call 60 = exit
        syscall
filesize equ $ - $$
