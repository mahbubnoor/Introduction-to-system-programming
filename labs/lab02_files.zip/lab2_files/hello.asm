; hello.asm - print a message using only system calls (no C library)
        global  _start

        section .data
msg:    db      "Hello from assembly!", 10    ; 10 = newline
len:    equ     $ - msg                       ; length = here - start of msg

        section .text
_start:
        mov     rax, 1          ; system call 1 = write
        mov     rdi, 1          ; file descriptor 1 = standard output
        mov     rsi, msg        ; address of the text
        mov     rdx, len        ; number of bytes
        syscall                 ; ask the kernel to do it

        mov     rax, 60         ; system call 60 = exit
        mov     rdi, 0          ; exit status 0
        syscall
