CSE 4105 System Programming - Lab 2 files
Md Mahbub E Noor, University of Barishal

hello.asm         Program 4: hello world with only system calls (slide 28)
sum.asm           Program 5: 1 + 2 + ... + 10, result as exit status (slide 29)
sumto.c, maxab.c  C functions to compile with  gcc -O0 -S  (slides 26, lab task 3)
absval.c          for homework task 4
sic_programs.txt  the SIC programs from slides 5, 14, 15 and 17

Build and run an assembly program:
    nasm -f elf64 hello.asm -o hello.o
    ld hello.o -o hello
    ./hello

See gcc's assembly for a C file:
    gcc -O0 -S maxab.c               (AT&T syntax, like gcc prints)
    gcc -O0 -S -masm=intel maxab.c   (Intel syntax, like nasm)
