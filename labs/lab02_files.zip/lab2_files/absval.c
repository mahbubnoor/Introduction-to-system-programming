int abs_val(int n)
{
    if (n < 0)
        return -n;
    return n;
}
