; sum.asm - add 1 + 2 + ... + 10 and return the result as the exit status
        global  _start

        section .text
_start:
        mov     ecx, 1          ; i = 1
        mov     eax, 0          ; s = 0
loop:
        add     eax, ecx        ; s = s + i
        inc     ecx             ; i++
        cmp     ecx, 10         ; compare i with 10
        jle     loop            ; if i <= 10, go back to loop

        mov     edi, eax        ; exit status = s
        mov     eax, 60         ; system call 60 = exit
        syscall
