CSE 4105 System Programming - Lab 8 (Lectures 8.1 and 8.2): processes, execve and scheduling
==========================================================================================
Works offline. Needs: gcc, strace, gdb (all in Ubuntu's normal developer packages).

LAB 8.1  mysh.c: a small shell
  gcc -Wall -o mysh mysh_starter.c && ./mysh          (Ctrl-D quits)
  gcc -o segv segv.c                                  (a program that crashes, to test TODO 3)
  TODO 1 split the line with strtok     TODO 2 fork + execvp + _exit(127)
  TODO 3 waitpid + report               TODO 4 cd as a built-in      TODO 5 a trailing &
  Until TODO 3, gcc warns that report() is unused: that is expected.
  expected_mysh_session.txt shows a session with the finished shell.

LAB 8.2  stack.c and the nice experiment
  gcc -Wall -o stack stack_starter.c && ./stack hello world      TODO 1 count envp, TODO 2 walk auxv
  LD_SHOW_AUXV=1 ./stack                    gcc -Wall -static -o stack_static stack_starter.c
  gcc -Wall -O2 -o shares shares.c && ./shares 5 5     (second number = seconds; try nice 1, 5, 10, 19)
  gcc -Wall -O2 -o ctxsw ctxsw.c && ./ctxsw            grep CONFIG_HZ= /boot/config-$(uname -r)

DEMO PROGRAMS (demo/), the ones shown on the slides:
  cd demo && for f in *.c; do gcc -Wall -O2 -pthread -o ${f%.c} $f; done
  fork1 nobuf exec1 waitst zombie orphan states threads forkcost   (Lecture 8.1)
  stack run hashbang hello.py noshebang tiny                        (Lecture 8.2)
  ./hashbang a b        ./run ./noshebang        ./run ./nosuchfile
  cp /bin/true noexec && chmod a-x noexec && ./run ./noexec          (EACCES)
  gdb -q --args ./tiny one two   then:  starti   info registers rip rsp   x/4gx $rsp
  tiny is the 132-byte hand-made ELF file from Lecture 6.
Addresses, PIDs and times will differ from the slides: ASLR, and a different machine.
