/* ctxsw.c - voluntary vs involuntary context switches */
#define _GNU_SOURCE
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sched.h>
#include <time.h>
#include <sys/wait.h>
static void show(const char *who)
{
    char line[128];
    FILE *f = fopen("/proc/self/status", "r");
    while (fgets(line, sizeof line, f))
        if (strstr(line, "ctxt_switches")) printf("%-8s %s", who, line);
    fclose(f);
    fflush(stdout);
}
int main(void)
{
    cpu_set_t one; CPU_ZERO(&one); CPU_SET(0, &one);
    sched_setaffinity(0, sizeof one, &one);           /* everyone on CPU 0 */
    if (fork() == 0) {                                /* the sleeper: 100 naps of 10 ms */
        for (int i = 0; i < 100; i++) usleep(10000);
        show("sleeper"); _exit(0);
    }
    for (int k = 0; k < 2; k++)
        if (fork() == 0) {                            /* two hogs: 2 s of pure computing */
            time_t end = time(NULL) + 2;
            while (time(NULL) < end) ;
            if (k == 0)
                show("hog");
            _exit(0);
        }
    while (wait(NULL) > 0) ;
    return 0;
}
