/* threads.c - threads are tasks that share one process */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
int shared = 0;                                   /* one copy for all threads */
static void *work(void *arg)
{
    shared += 1;
    printf("thread %ld: getpid() = %d, gettid() = %d\n", (long)arg, getpid(), gettid());
    sleep(1);
    return NULL;
}
int main(void)
{
    pthread_t t[2];
    printf("main    : getpid() = %d, gettid() = %d\n", getpid(), gettid());
    for (long i = 0; i < 2; i++) { pthread_create(&t[i], NULL, work, (void *)(i + 1)); usleep(100000); }
    fflush(stdout);
    char cmd[96];
    snprintf(cmd, sizeof cmd, "ps -L -o pid,lwp,nlwp,stat,comm -p %d; ls /proc/%d/task", getpid(), getpid());
    if (system(cmd) == -1) perror("system");
    for (int i = 0; i < 2; i++) pthread_join(t[i], NULL);
    printf("shared = %d (both threads changed the same variable)\n", shared);
    return 0;
}
