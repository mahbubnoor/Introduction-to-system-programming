/* orphan.c - the parent ends first: who adopts the child? */
#include <stdio.h>
#include <unistd.h>
int main(void)
{
    pid_t p = fork();
    if (p > 0) {                                   /* parent */
        printf("parent %d: ending now, child is %d\n", getpid(), p);
        return 0;
    }
    printf("child  %d: my parent is %d\n", getpid(), getppid());
    sleep(1);                                      /* parent is gone by now */
    printf("child  %d: my parent is now %d\n", getpid(), getppid());
    return 0;
}
