/* forkcost.c - how long does it take to create a process? a thread? */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <time.h>
#include <sys/wait.h>
#define N 2000
static double now(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return t.tv_sec + t.tv_nsec / 1e9; }
static void *nothing(void *a) { return a; }
int main(int argc, char *argv[])
{
    size_t mb = argc > 1 ? atol(argv[1]) : 0;          /* optional: touch this many MB first */
    char *big = malloc(mb << 20 | 1);
    for (size_t i = 0; i < (mb << 20); i += 4096) big[i] = 1;
    double t0 = now();
    for (int i = 0; i < N; i++) {
        pid_t p = fork();
        if (p == 0) _exit(0);
        waitpid(p, NULL, 0);
    }
    double t1 = now();
    for (int i = 0; i < N; i++) {
        pthread_t t;
        pthread_create(&t, NULL, nothing, NULL);
        pthread_join(t, NULL);
    }
    double t2 = now();
    printf("memory touched: %4zu MB   fork+exit+wait: %6.1f us   thread create+join: %5.1f us\n",
           mb, (t1 - t0) / N * 1e6, (t2 - t1) / N * 1e6);
    return 0;
}
