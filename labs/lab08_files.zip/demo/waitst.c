/* waitst.c - how a parent learns how its child ended */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
static void report(pid_t pid, int st)
{
    if (WIFEXITED(st))   printf("child %d exited, status %d   (raw 0x%04x)\n", pid, WEXITSTATUS(st), st);
    if (WIFSIGNALED(st)) printf("child %d killed by signal %d (raw 0x%04x)\n", pid, WTERMSIG(st), st);
}
int main(void)
{
    int st;
    pid_t p = fork();
    if (p == 0) exit(42);                         /* normal exit */
    waitpid(p, &st, 0); report(p, st);
    p = fork();
    if (p == 0) { int *q = NULL; return *q; }    /* crash: SIGSEGV */
    waitpid(p, &st, 0); report(p, st);
    return 0;
}
