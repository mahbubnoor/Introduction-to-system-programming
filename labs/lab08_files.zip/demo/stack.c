/* stack.c - what the kernel put on the new program's stack: argc, argv, envp, auxv */
#include <stdio.h>
#include <elf.h>
#include <sys/auxv.h>
int main(int argc, char *argv[], char *envp[])
{
    printf("argc = %d   (&argc is %p)\n", argc, (void *)&argc);
    for (int i = 0; i < argc; i++)
        printf("argv[%d] at %p -> \"%s\"\n", i, (void *)argv[i], argv[i]);
    int n = 0;
    while (envp[n]) n++;
    printf("envp: %d strings, the first at %p\n", n, (void *)envp[0]);
    Elf64_auxv_t *a = (Elf64_auxv_t *)(envp + n + 1);         /* auxv starts right after envp's NULL */
    for (; a->a_type != AT_NULL; a++) {
        const char *name = a->a_type == AT_PHDR ? "AT_PHDR  (program headers)" :
                           a->a_type == AT_PHNUM ? "AT_PHNUM (how many)" :
                           a->a_type == AT_PAGESZ ? "AT_PAGESZ" :
                           a->a_type == AT_BASE ? "AT_BASE  (where ld.so is)" :
                           a->a_type == AT_ENTRY ? "AT_ENTRY (the program's _start)" :
                           a->a_type == AT_RANDOM ? "AT_RANDOM (16 random bytes)" :
                           a->a_type == AT_EXECFN ? "AT_EXECFN (file name)" : NULL;
        if (name) printf("auxv %-32s 0x%lx\n", name, (unsigned long)a->a_un.a_val);
    }
    printf("main is at %p; getauxval(AT_ENTRY) = 0x%lx\n", (void *)main, getauxval(AT_ENTRY));
    return 0;
}
