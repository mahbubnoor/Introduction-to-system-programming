/* fork1.c - one call, two returns */
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
int main(void)
{
    int x = 10;
    printf("before fork: I am PID %d\n", getpid());
    fflush(stdout);
    pid_t pid = fork();
    if (pid == 0) {                       /* child */
        x = x + 5;
        printf("child : fork returned %d, my PID %d, parent %d, x = %d\n", pid, getpid(), getppid(), x);
        return 0;
    }
    waitpid(pid, NULL, 0);                /* parent */
    printf("parent: fork returned %d, my PID %d, x = %d\n", pid, getpid(), x);
    return 0;
}
