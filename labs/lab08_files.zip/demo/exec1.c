/* exec1.c - exec replaces the program, keeps the PID */
#include <stdio.h>
#include <unistd.h>
int main(void)
{
    printf("exec1: my PID is %d, now I exec the shell\n", getpid());
    fflush(stdout);
    execlp("sh", "sh", "-c", "echo \"sh   : my PID is $$, and exec1 is gone\"", (char *)NULL);
    perror("execlp");          /* only reached if exec failed */
    return 1;
}
