/* run.c - call execv directly and print the error, if any */
#include <stdio.h>
#include <unistd.h>
int main(int argc, char *argv[])
{
    if (argc < 2) return 2;
    execv(argv[1], argv + 1);
    perror(argv[1]);          /* reached only if the kernel said no */
    return 1;
}
