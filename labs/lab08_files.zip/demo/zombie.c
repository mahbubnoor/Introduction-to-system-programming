/* zombie.c - a child that has exited but was not waited for */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
int main(void)
{
    pid_t p = fork();
    if (p == 0) exit(7);                  /* child ends at once */
    sleep(1);                             /* parent does not wait yet */
    char cmd[64];
    snprintf(cmd, sizeof cmd, "ps -o pid,ppid,stat,comm -p %d,%d", getpid(), p);
    if (system(cmd) == -1) perror("system");                          /* look at both */
    int st;
    waitpid(p, &st, 0);                   /* now collect it */
    printf("after waitpid: status %d\n", WEXITSTATUS(st));
    if (system(cmd) == -1) perror("system");
    return 0;
}
