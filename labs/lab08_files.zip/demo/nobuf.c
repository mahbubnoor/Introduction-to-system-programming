/* nobuf.c - why fflush matters before fork */
#include <stdio.h>
#include <unistd.h>
int main(void)
{
    printf("hello ");          /* stays in the stdio buffer, not yet written */
    fork();                    /* the buffer is copied too */
    printf("world\n");
    return 0;
}
