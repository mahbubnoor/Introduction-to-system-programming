#!/usr/bin/python3
print("hello from python, run by the kernel via #!")
