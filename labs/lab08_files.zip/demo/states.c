/* states.c - make processes in states R, S, T and Z, then show them with ps */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
int main(void)
{
    pid_t run = fork();
    if (run == 0) for (;;) ;                      /* R: always wants the CPU */
    pid_t slp = fork();
    if (slp == 0) { pause(); }                    /* S: sleeps until a signal */
    pid_t stp = fork();
    if (stp == 0) { pause(); }
    kill(stp, SIGSTOP);                           /* T: stopped */
    pid_t zmb = fork();
    if (zmb == 0) exit(0);                        /* Z: exited, not waited for */
    sleep(1);
    char cmd[128];
    snprintf(cmd, sizeof cmd, "ps -o pid,ppid,stat,wchan:16,comm -p %d,%d,%d,%d,%d", getpid(), run, slp, stp, zmb);
    if (system(cmd) == -1) perror("system");
    kill(run, SIGKILL); kill(slp, SIGKILL); kill(stp, SIGKILL);
    return 0;
}
