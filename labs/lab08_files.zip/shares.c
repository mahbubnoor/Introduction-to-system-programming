/*
 * shares.c - two busy processes on ONE CPU: how does nice split the time?
 * CSE 4105 System Programming, Lab 8.2   (complete program: run it, do not change it)
 *
 * Build:  gcc -O2 -Wall -o shares shares.c
 * Run:    ./shares NICE SECONDS      e.g.  ./shares 5 5
 */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sched.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <time.h>
static double cpu_seconds(void)
{
    struct timespec t;
    clock_gettime(CLOCK_PROCESS_CPUTIME_ID, &t);
    return t.tv_sec + t.tv_nsec / 1e9;
}
int main(int argc, char *argv[])
{
    int nice2 = argc > 1 ? atoi(argv[1]) : 5;      /* nice value of the second process */
    int secs = argc > 2 ? atoi(argv[2]) : 5;
    cpu_set_t one;
    CPU_ZERO(&one);
    CPU_SET(0, &one);
    sched_setaffinity(0, sizeof one, &one);        /* children inherit: both on CPU 0 */
    int fds[2][2];
    for (int k = 0; k < 2; k++) {
        if (pipe(fds[k]) != 0) return 1;
        if (fork() == 0) {
            if (k == 1) setpriority(PRIO_PROCESS, 0, nice2);
            time_t end = time(NULL) + secs;
            while (time(NULL) < end) ;                 /* burn CPU */
            double c = cpu_seconds();
            if (write(fds[k][1], &c, sizeof c) < 0) _exit(1);
            _exit(0);
        }
    }
    double c[2];
    for (int k = 0; k < 2; k++) if (read(fds[k][0], &c[k], sizeof c[k]) < 0) return 1;
    while (wait(NULL) > 0) ;
    printf("nice 0 : %.2f s CPU (%4.1f%%)   nice %d : %.2f s CPU (%4.1f%%)\n",
           c[0], 100 * c[0] / (c[0] + c[1]), nice2, c[1], 100 * c[1] / (c[0] + c[1]));
    return 0;
}
