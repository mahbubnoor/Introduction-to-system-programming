/*
 * stack.c - what the kernel put on a new program's stack: argc, argv, envp and the auxiliary vector
 * CSE 4105 System Programming, Lab 8.2   (STARTER: fill in the parts marked TODO)
 *
 * Build:  gcc -Wall -o stack stack.c
 * Run:    ./stack hello world          then compare with:  LD_SHOW_AUXV=1 ./stack
 */
#include <stdio.h>
#include <elf.h>
#include <sys/auxv.h>
int main(int argc, char *argv[], char *envp[])
{
    printf("argc = %d   (&argc is %p)\n", argc, (void *)&argc);
    for (int i = 0; i < argc; i++)
        printf("argv[%d] at %p -> \"%s\"\n", i, (void *)argv[i], argv[i]);
    int n = 0;
    /* TODO 1: count the environment strings: envp is a NULL-terminated array, like argv. */
    printf("envp: %d strings, the first at %p\n", n, (void *)envp[0]);
    /* TODO 2: the kernel put the auxiliary vector right after envp's NULL pointer:
     *         Elf64_auxv_t *a = (Elf64_auxv_t *)(envp + n + 1);
     *         Loop until a->a_type == AT_NULL; each entry has a_type and a_un.a_val.          */
    Elf64_auxv_t end = { AT_NULL, { 0 } }, *a = &end;
    for (; a->a_type != AT_NULL; a++) {
        const char *name = a->a_type == AT_PHDR ? "AT_PHDR  (program headers)" :
                           a->a_type == AT_PHNUM ? "AT_PHNUM (how many)" :
                           a->a_type == AT_PAGESZ ? "AT_PAGESZ" :
                           a->a_type == AT_BASE ? "AT_BASE  (where ld.so is)" :
                           a->a_type == AT_ENTRY ? "AT_ENTRY (the program's _start)" :
                           a->a_type == AT_RANDOM ? "AT_RANDOM (16 random bytes)" :
                           a->a_type == AT_EXECFN ? "AT_EXECFN (file name)" : NULL;
        if (name) printf("auxv %-32s 0x%lx\n", name, (unsigned long)a->a_un.a_val);
    }
    printf("main is at %p; getauxval(AT_ENTRY) = 0x%lx\n", (void *)main, getauxval(AT_ENTRY));
    return 0;
}
