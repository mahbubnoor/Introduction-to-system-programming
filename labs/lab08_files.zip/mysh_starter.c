/*
 * mysh.c - a small shell: read a line, fork, exec, wait
 * CSE 4105 System Programming, Lab 8.1   (STARTER: fill in the parts marked TODO)
 *
 * TODO 1 split the line   TODO 2 fork + exec   TODO 3 wait + report   TODO 4 cd   TODO 5 background (&)
 *
 * Build:  gcc -Wall -o mysh mysh.c
 * Run:    ./mysh            (type commands; exit or Ctrl-D to leave)
 *
 * Supports:  programs with arguments, the built-ins cd and exit,
 *            "&" at the end of a line (run in the background), and it reports how each child ended.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/wait.h>

#define MAXARGS 32

/* print how a child ended, like the shell's $? but in words */
static void report(pid_t pid, int status, int background)
{
    if (WIFEXITED(status) && WEXITSTATUS(status) != 0)
        printf("[%d exited with status %d]\n", pid, WEXITSTATUS(status));
    else if (WIFSIGNALED(status))
        printf("[%d killed by signal %d]\n", pid, WTERMSIG(status));
    else if (background)
        printf("[%d done]\n", pid);
}

int main(void)
{
    char line[1024];
    char *argv[MAXARGS + 1];

    for (;;) {
        /* collect finished background children, so they do not stay zombies */
        int status;
        pid_t done;
        /* TODO 5b: loop: done = waitpid(-1, &status, WNOHANG); while it returns a PID > 0,
         *          report(done, status, 1).  WNOHANG = "do not wait if nobody has finished".   */
        (void)done; (void)status;

        printf("mysh> ");
        fflush(stdout);
        if (!fgets(line, sizeof line, stdin))        /* Ctrl-D: end of input */
            break;

        /* 1. split the line into words: argv[0] is the program */
        int argc = 0;
        /* TODO 1: use strtok(line, " \t\n") and strtok(NULL, " \t\n") to put each word in argv[argc++]
         *         (at most MAXARGS words). End the list with argv[argc] = NULL: execvp needs it.        */
        argv[argc] = NULL;
        if (argc == 0)
            continue;

        /* a trailing & means: do not wait */
        int background = 0;
        /* TODO 5a: if the last word is "&": background = 1, remove it from argv (and from argc). */

        /* 2. built-ins: these must run inside the shell itself */
        if (strcmp(argv[0], "exit") == 0)
            exit(argc > 1 ? atoi(argv[1]) : 0);
        if (strcmp(argv[0], "cd") == 0) {
            /* TODO 4: chdir() to argv[1] (or to getenv("HOME") if there is no argument); perror on error.
             *         Question for your report: why can cd NOT be a separate program like ls?        */
            continue;
        }

        /* 3. everything else: a new process */
        /* TODO 2: pid = fork(); on error perror and continue.
         *         In the child (pid == 0): execvp(argv[0], argv); if it returns, print
         *         "mysh: <name>: <strerror(errno)>" to stderr and _exit(127).                       */
        pid_t pid = -1;
        (void)errno;
        if (pid < 0) {
            printf("(TODO 2: no process started for %s)\n", argv[0]);
            continue;
        }

        /* 4. parent: wait for it, unless it runs in the background */
        if (background) {
            printf("[%d running in the background]\n", pid);
        } else {
            /* TODO 3: waitpid(pid, &status, 0); then report(pid, status, 0). */
        }
    }
    printf("\n");
    return 0;
}
