CSE 4105 System Programming - Lab 13: interrupts and exceptions
===============================================================
Works offline, no root needed. Needs: gcc (strace optional).

LAB 13  irqtop: which interrupts are firing right now?
  gcc -Wall -O2 -o irqtop irqtop_starter.c && ./irqtop
  (gcc warns that by_count_desc is unused until TODO 4: expected.)
  TODO 1 count "CPU" in the header line            TODO 2 parse each line: id, sum of the per-CPU numbers, name
  TODO 3 match the two snapshots by id, subtract   TODO 4 qsort, biggest first
  Careful: the lines ERR and MIS have only one number.
  Test:  ./irqtop        then, while it runs, type / move the mouse / copy a big file / run  yes > /dev/null
         cat /proc/interrupts     cat /proc/softirqs

DEMO PROGRAMS (demo/):
  gcc -Wall -O2 -o exc exc.c && ./exc        the CPU's exception numbers (trap) and page-fault error codes (err)
  gcc -Wall -O2 -o slack slack.c && ./slack  how late is a 1 ms sleep? (takes about 2.2 s)

HOMEWORK (homework/):
  gcc -Wall -O0 -o pferr pferr.c && ./pferr  (predict each err value BEFORE you run it)
  grep CONFIG_HZ= /boot/config-$(uname -r)
