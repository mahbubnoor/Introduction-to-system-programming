/* pferr.c - Homework 13 task 1: predict the page-fault error code (err) of each line, then run it */
#define _GNU_SOURCE
#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <sys/wait.h>
#include <ucontext.h>
#include <unistd.h>
static void handler(int sig, siginfo_t *si, void *ctx)
{
    ucontext_t *uc = ctx;
    char m[120];
    int n = snprintf(m, sizeof m, "trap %lld  err 0x%llx  si_code %d  addr %p\n",
                     (long long)uc->uc_mcontext.gregs[REG_TRAPNO], (long long)uc->uc_mcontext.gregs[REG_ERR], si->si_code, si->si_addr);
    if (write(1, m, n) < 0) _exit(2);
    (void)sig;
    _exit(0);
}
static void run(const char *name, int what)
{
    printf("%-30s -> ", name);
    fflush(stdout);
    if (fork() == 0) {
        struct sigaction sa;
        memset(&sa, 0, sizeof sa);
        sa.sa_sigaction = handler;
        sa.sa_flags = SA_SIGINFO;
        sigaction(SIGSEGV, &sa, NULL);
        switch (what) {
        case 0: *(volatile char *)0 = 1; break;                                   /* write to NULL           */
        case 1: ((void (*)(void))0)(); break;                                     /* call address 0          */
        case 2: *(volatile char *)(void *)run = 1; break;                         /* write into our own code */
        case 3: { volatile char c = *(volatile char *)0xffffffff81000000UL; (void)c; break; } /* kernel address */
        }
        _exit(1);
    }
    wait(NULL);
}
int main(void)
{
    run("write *NULL", 0);
    run("call address 0", 1);
    run("write into main's code", 2);
    run("read a kernel address", 3);
    return 0;
}
