/* slack.c - ask to sleep 1 ms, 1000 times: how long does each sleep really take? */
#include <stdio.h>
#include <stdlib.h>
#include <sys/prctl.h>
#include <time.h>
static double now_us(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return t.tv_sec * 1e6 + t.tv_nsec / 1e3; }
static void test(const char *label)
{
    struct timespec ms = { 0, 1000000 };
    double sum = 0, worst = 0;
    for (int i = 0; i < 1000; i++) {
        double t = now_us();
        nanosleep(&ms, NULL);
        double late = now_us() - t - 1000;           /* microseconds after the 1 ms */
        sum += late;
        if (late > worst) worst = late;
    }
    printf("%-28s late by %6.1f us on average, worst %7.1f us\n", label, sum / 1000, worst);
}
int main(void)
{
    printf("timer slack: %d ns\n", prctl(PR_GET_TIMERSLACK, 0, 0, 0, 0));
    test("default slack (50 us)");
    prctl(PR_SET_TIMERSLACK, 1, 0, 0, 0);             /* 1 ns: please be exact */
    test("slack 1 ns");
    return 0;
}
