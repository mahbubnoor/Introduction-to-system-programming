/* exc.c - make the CPU raise each kind of exception; print what the kernel tells the program */
#define _GNU_SOURCE
#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <sys/wait.h>
#include <ucontext.h>
#include <unistd.h>

static void handler(int sig, siginfo_t *si, void *ctx)
{
    ucontext_t *uc = ctx;
    char m[160];
    int n = snprintf(m, sizeof m, "%-8s si_code %d  trap %2lld  err 0x%llx  addr %p\n", sigabbrev_np(sig), si->si_code,
                     (long long)uc->uc_mcontext.gregs[REG_TRAPNO], (long long)uc->uc_mcontext.gregs[REG_ERR], si->si_addr);
    if (write(1, m, n) < 0) _exit(2);     /* printf is not async-signal-safe (Lecture 10.2) */
    _exit(0);
}

static volatile int zero = 0, seven = 7;
static const char rodata[] = "hello";

static void run(const char *name, int what)
{
    printf("%-26s -> ", name);
    fflush(stdout);
    if (fork() == 0) {
        struct sigaction sa;
        memset(&sa, 0, sizeof sa);
        sa.sa_sigaction = handler;
        sa.sa_flags = SA_SIGINFO;
        for (int s = 1; s < 32; s++) sigaction(s, &sa, NULL);
        switch (what) {
        case 0: { volatile int x = seven / zero; (void)x; break; }      /* #DE  divide error        */
        case 1: __asm__ volatile("int3"); break;                         /* #BP  breakpoint          */
        case 2: __asm__ volatile("ud2"); break;                          /* #UD  invalid opcode      */
        case 3: __asm__ volatile("hlt"); break;                          /* #GP  privileged insn     */
        case 4: __asm__ volatile("inb $0x60, %%al" ::: "eax"); break;    /* #GP  I/O port            */
        case 5: { volatile char c = *(volatile char *)0; (void)c; break; } /* #PF read, not present  */
        case 6: *(volatile char *)rodata = 'J'; break;                   /* #PF write, read-only     */
        case 7: { unsigned char code[] = { 0xc3 }; ((void (*)(void))code)(); break; } /* #PF exec, NX stack */
        }
        printf("no exception?\n");
        _exit(1);
    }
    wait(NULL);
}

int main(void)
{
    run("7 / 0", 0);
    run("int3", 1);
    run("ud2", 2);
    run("hlt (kernel only)", 3);
    run("inb $0x60 (port I/O)", 4);
    run("read *NULL", 5);
    run("write \"hello\" (rodata)", 6);
    run("call code on the stack", 7);
    return 0;
}
