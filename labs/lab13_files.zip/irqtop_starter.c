/*
 * irqtop.c - which interrupts are firing right now? Read /proc/interrupts twice, one second apart.
 * CSE 4105 System Programming, Lab 13   (STARTER: fill in the parts marked TODO)
 *
 * Build:  gcc -Wall -O2 -o irqtop irqtop.c
 * Run:    ./irqtop            (meanwhile, in another terminal: type, move the mouse, or copy a big file)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define MAXLINES 512
struct irq {
    char id[16];                    /* "37", "LOC", "NMI", ... */
    unsigned long long count;       /* sum over all CPUs */
    char name[64];                  /* "virtio1-req.0", "Local timer interrupts", ... */
};

/* read /proc/interrupts into v[]; return the number of lines */
static int snapshot(struct irq *v)
{
    FILE *f = fopen("/proc/interrupts", "r");
    if (!f) { perror("/proc/interrupts"); exit(1); }
    char line[1024];
    int ncpu = 0, n = 0;

    /* TODO 1: read the first line (the header) with fgets and count how many times "CPU" appears in it:
     *         that is ncpu. Hint: strstr(p, "CPU") in a loop, moving p forward each time.          */
    (void)line;

    /* TODO 2: for every other line (fgets until NULL, and n < MAXLINES):
     *   - skip the spaces; the id is the text before ':'  ("37", "LOC", "NMI" ...): copy it to v[n].id
     *   - then up to ncpu numbers: add them into v[n].count (strtoull(p, &end, 10); stop when end == p,
     *     because the lines ERR and MIS have only one number)
     *   - the rest of the line (without leading spaces and the '\n') is the name: copy it to v[n].name
     *   - n++                                                                                        */
    (void)ncpu;

    fclose(f);
    return n;
}

static int by_count_desc(const void *a, const void *b)
{
    const struct irq *x = a, *y = b;
    return (y->count > x->count) - (y->count < x->count);   /* given: no overflow, unlike y - x */
}

int main(int argc, char *argv[])
{
    int top = argc > 1 ? atoi(argv[1]) : 10;
    static struct irq before[MAXLINES], after[MAXLINES], diff[MAXLINES];
    int nb = snapshot(before);
    sleep(1);
    int na = snapshot(after);

    int nd = 0;
    /* TODO 3: for each line in after[], find the line with the same id in before[] (strcmp),
     *         copy it into diff[nd] with count = after - before, and nd++.                    */
    (void)na; (void)nb; (void)after; (void)before;

    /* TODO 4: sort diff[] so the biggest count comes first: qsort with by_count_desc.        */

    printf("%6s  %10s  %s\n", "IRQ", "per second", "name");
    for (int i = 0; i < nd && i < top && diff[i].count > 0; i++)
        printf("%6s  %10llu  %s\n", diff[i].id, diff[i].count, diff[i].name);
    if (nd == 0) printf("(no lines yet: start with TODO 1 and 2)\n");
    return 0;
}
