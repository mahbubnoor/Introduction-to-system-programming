/* stubborn.c - a program that ignores SIGTERM (for testing mytimeout) */
#include <signal.h>
#include <stdio.h>
#include <unistd.h>
int main(void)
{
    signal(SIGTERM, SIG_IGN);
    printf("stubborn %d: I ignore SIGTERM\n", getpid());
    fflush(stdout);
    for (;;) pause();
}
