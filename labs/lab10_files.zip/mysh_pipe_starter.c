/*
 * mysh_pipe.c - the Lab 8.1 shell, plus one pipe:  cmd1 args | cmd2 args
 * CSE 4105 System Programming, Lab 10.1   (STARTER: fill in the parts marked TODO)
 *
 * Build:  gcc -Wall -o mysh mysh_pipe.c
 * Try:    ls / | wc -l        cat /etc/passwd | grep root        yes | head -3
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/wait.h>

#define MAXARGS 32

/* print how a child ended, like the shell's $? but in words */
static void report(pid_t pid, int status, int background)
{
    if (WIFEXITED(status) && WEXITSTATUS(status) != 0)
        printf("[%d exited with status %d]\n", pid, WEXITSTATUS(status));
    else if (WIFSIGNALED(status))
        printf("[%d killed by signal %d]\n", pid, WTERMSIG(status));
    else if (background)
        printf("[%d done]\n", pid);
}

/* in a child: become the program, or report why not */
static void run(char **argv)
{
    execvp(argv[0], argv);
    fprintf(stderr, "mysh: %s: %s\n", argv[0], strerror(errno));
    _exit(127);
}

/* left | right : two children joined by one pipe */
static void run_pipeline(char **left, char **right)
{
    int fd[2];
    /* TODO 2: make the pipe: pipe(fd). fd[0] is the read end, fd[1] the write end. */
    (void)fd;

    /* TODO 3: child 1 runs "left" with its standard output going INTO the pipe:
     *         fork; in the child: dup2(fd[1], 1); close BOTH pipe ends; run(left).          */

    /* TODO 4: child 2 runs "right" with its standard input coming FROM the pipe:
     *         fork; in the child: dup2(fd[0], 0); close BOTH pipe ends; run(right).         */

    /* TODO 5: the shell itself: close BOTH ends (why? see eof.c from Lecture 10.1),
     *         then waitpid for each child and report() how it ended.                        */
    fprintf(stderr, "mysh: pipes are not done yet (TODO 2-5)\n");
    (void)left; (void)right;
}

int main(void)
{
    char line[1024];
    char *argv[MAXARGS + 1];

    for (;;) {
        int status;
        pid_t done;
        while ((done = waitpid(-1, &status, WNOHANG)) > 0)
            report(done, status, 1);

        printf("mysh> ");
        fflush(stdout);
        if (!fgets(line, sizeof line, stdin))
            break;

        int argc = 0;
        for (char *w = strtok(line, " \t\n"); w && argc < MAXARGS; w = strtok(NULL, " \t\n"))
            argv[argc++] = w;
        argv[argc] = NULL;
        if (argc == 0)
            continue;

        /* a "|" word splits the line into two commands */
        int bar = -1;
        /* TODO 1: find the word "|" in argv[0..argc-1] and put its index in bar */
        if (bar >= 0) {
            if (bar == 0 || bar == argc - 1) { fprintf(stderr, "mysh: | needs a command on both sides\n"); continue; }
            argv[bar] = NULL;
            run_pipeline(argv, argv + bar + 1);
            continue;
        }

        int background = 0;
        if (strcmp(argv[argc - 1], "&") == 0) {
            background = 1;
            argv[--argc] = NULL;
            if (argc == 0) continue;
        }

        if (strcmp(argv[0], "exit") == 0)
            exit(argc > 1 ? atoi(argv[1]) : 0);
        if (strcmp(argv[0], "cd") == 0) {
            const char *dir = argc > 1 ? argv[1] : getenv("HOME");
            if (chdir(dir) != 0)
                perror("cd");
            continue;
        }

        pid_t pid = fork();
        if (pid < 0) { perror("fork"); continue; }
        if (pid == 0)
            run(argv);
        if (background) {
            printf("[%d running in the background]\n", pid);
        } else {
            waitpid(pid, &status, 0);
            report(pid, status, 0);
        }
    }
    printf("\n");
    return 0;
}
