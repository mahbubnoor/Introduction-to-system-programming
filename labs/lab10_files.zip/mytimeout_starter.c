/*
 * mytimeout.c - run a program, but stop it after N seconds (like coreutils "timeout")
 * CSE 4105 System Programming, Lab 10.2   (STARTER: fill in the parts marked TODO)
 *
 * Build:  gcc -Wall -o mytimeout mytimeout.c
 * Try:    ./mytimeout 2 sleep 10 ; echo $?      (124 = timed out, as in coreutils)
 *         ./mytimeout 5 sleep 1  ; echo $?      (0: finished in time)
 *         ./mytimeout 1 ./stubborn ; echo $?    (ignores SIGTERM: gets SIGKILL 2 s later)
 */
#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

static volatile sig_atomic_t alarms = 0;         /* the only thing the handler touches */
static void on_alarm(int sig) { (void)sig; alarms++; }

int main(int argc, char *argv[])
{
    if (argc < 3) {
        fprintf(stderr, "usage: %s SECONDS PROGRAM [ARGS...]\n", argv[0]);
        return 125;
    }
    int secs = atoi(argv[1]);

    /* 1. TODO 1: install on_alarm as the SIGALRM handler with sigaction().
     *    Use sa_flags = 0, NOT SA_RESTART: we WANT the alarm to interrupt waitpid (EINTR).
     *    (Until you do this, the alarm's default action kills mytimeout itself: try it.)       */

    /* 2. start the program */
    pid_t child = fork();
    if (child < 0) { perror("fork"); return 125; }
    if (child == 0) {
        execvp(argv[2], argv + 2);
        fprintf(stderr, "mytimeout: %s: %s\n", argv[2], strerror(errno));
        _exit(127);
    }

    /* 3. TODO 2: start the timer: SIGALRM in secs seconds (one call). */

    /* 4. wait; an alarm makes waitpid return -1 with errno EINTR */
    int status, timed_out = 0;
    for (;;) {
        pid_t r = waitpid(child, &status, 0);
        if (r == child)
            break;                               /* it ended (by itself, or because we killed it) */
        if (r < 0 && errno == EINTR) {
            /* TODO 3: the alarm interrupted waitpid.
             *   first alarm  (alarms == 1): print a message, kill(child, SIGTERM), set timed_out = 1,
             *                               and alarm(2) to give the child 2 more seconds;
             *   second alarm (alarms == 2): kill(child, SIGKILL): this one cannot be ignored.
             *   Then "continue" to wait again.                                                     */
            continue;
        }
        perror("waitpid");
        return 125;
    }
    alarm(0);                                    /* cancel a pending alarm */

    /* 5. TODO 4: our exit status, like coreutils timeout:
     *    124 if we timed it out; else the child's exit status; else 128 + the signal that killed it. */
    (void)timed_out;
    return 0;
}
