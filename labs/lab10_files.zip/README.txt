CSE 4105 System Programming - Lab 10 (Lectures 10.1 and 10.2): pipes, shared memory, signals
=========================================================================================
Works offline. Needs: gcc, strace, gdb.

LAB 10.1  pipes in mysh
  gcc -Wall -o mysh mysh_pipe_starter.c && ./mysh
  TODO 1 find "|"   TODO 2 pipe()   TODO 3 child 1: dup2(fd[1], 1)   TODO 4 child 2: dup2(fd[0], 0)
  TODO 5 the shell closes both ends and waits for both children
  Test:  ls / | wc -l      cat /etc/passwd | grep root      yes | head -3
  If "ls / | wc -l" hangs: some process still holds the write end (see demo/eof.c).
  expected_mysh_pipe_session.txt shows the finished shell.

LAB 10.2  mytimeout: stop a program after N seconds
  gcc -Wall -o mytimeout mytimeout_starter.c && gcc -Wall -o stubborn stubborn.c
  (gcc warns that on_alarm and secs are unused until TODO 1 and 2: expected)
  TODO 1 sigaction for SIGALRM, without SA_RESTART   TODO 2 alarm(secs)
  TODO 3 on EINTR: SIGTERM first, SIGKILL 2 s later   TODO 4 exit status 124 / child's status / 128+signal
  Test:  ./mytimeout 2 sleep 10; echo $?     ./mytimeout 5 sleep 1; echo $?     ./mytimeout 1 ./stubborn; echo $?
         compare: timeout 2 sleep 10; echo $?        strace ./mytimeout 1 ./stubborn

DEMO PROGRAMS (demo/), the ones on the slides:
  cd demo && for f in *.c; do gcc -Wall -O2 -o ${f%.c} $f; done
  10.1: pipe1 pipecap block eof ("./eof forget" hangs: stop it with Ctrl-C) sigpipe pipebw shmrace interleave ; ./fifo_demo.sh
  10.2: catch (press Ctrl-C) deflt (try: ulimit -c unlimited first) mask eintr sigchld nokill segv_loop (homework)
  shmrace needs 2 or more CPUs to show the race; "taskset -c 0 ./shmrace" runs it on one CPU.
