/* eintr.c - a signal arrives while read() waits: restarted, or EINTR? */
#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
static void on_alarm(int sig) { (void)sig; if (write(1, "  [SIGALRM handler ran]\n", 24) < 0) { } }
int main(void)
{
    for (int restart = 0; restart < 2; restart++) {
        struct sigaction sa;
        memset(&sa, 0, sizeof sa);
        sa.sa_handler = on_alarm;
        sa.sa_flags = restart ? SA_RESTART : 0;
        sigaction(SIGALRM, &sa, NULL);
        int fd[2];
        if (pipe(fd) != 0) return 1;              /* a pipe nobody writes: read() waits for ever */
        printf("%s: read() from an empty pipe, alarm in 1 s\n", restart ? "SA_RESTART" : "no flags  ");
        fflush(stdout);
        alarm(1);
        if (restart) {
            /* with SA_RESTART read would wait for ever: a child writes one byte at 2 s */
            if (fork() == 0) { sleep(2); if (write(fd[1], "x", 1) < 0) { } _exit(0); }
        }
        char c;
        ssize_t n = read(fd[0], &c, 1);
        printf("   read returned %zd%s%s\n\n", n, n < 0 ? ", errno = " : " (the data came at 2 s)", n < 0 ? strerror(errno) : "");
        fflush(stdout);
        close(fd[0]); close(fd[1]);
    }
    return 0;
}
