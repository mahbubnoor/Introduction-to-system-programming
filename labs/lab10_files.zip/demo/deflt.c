/* deflt.c - what happens by default when a process gets each signal? */
#define _GNU_SOURCE
#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
int main(void)
{
    int sigs[] = { SIGINT, SIGQUIT, SIGSEGV, SIGTERM, SIGKILL, SIGUSR1, SIGPIPE, SIGALRM, SIGCHLD, SIGSTOP, SIGTSTP };
    for (unsigned k = 0; k < sizeof sigs / sizeof sigs[0]; k++) {
        int s = sigs[k];
        pid_t pid = fork();
        if (pid == 0) {
            pause();                              /* wait to be signalled */
            _exit(0);
        }
        usleep(50000);
        kill(pid, s);
        usleep(50000);
        int st;
        if (waitpid(pid, &st, WUNTRACED | WNOHANG) == 0) {   /* still running: the signal was ignored */
            kill(pid, SIGKILL);
            waitpid(pid, &st, 0);
            printf("%2d %-8s -> ignored (still running; we killed it)\n", s, sigabbrev_np(s));
            fflush(stdout);
            continue;
        }
        printf("%2d %-8s -> ", s, sigabbrev_np(s));
        if (WIFSIGNALED(st)) printf("killed%s\n", WCOREDUMP(st) ? " (core dumped)" : "");
        else if (WIFSTOPPED(st)) { printf("stopped\n"); kill(pid, SIGKILL); waitpid(pid, &st, 0); }
        else printf("exited\n");
        fflush(stdout);
    }
    return 0;
}
