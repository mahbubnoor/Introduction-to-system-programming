/* nokill.c - can a program catch or ignore SIGKILL and SIGSTOP? */
#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <string.h>
static void h(int s) { (void)s; }
int main(void)
{
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = h;
    int sigs[] = { SIGKILL, SIGSTOP, SIGTERM };
    for (int i = 0; i < 3; i++) {
        int r = sigaction(sigs[i], &sa, NULL);
        printf("sigaction(%-7s, handler) = %2d  %s\n", sigs[i] == SIGKILL ? "SIGKILL" : sigs[i] == SIGSTOP ? "SIGSTOP" : "SIGTERM", r, r ? strerror(errno) : "(allowed)");
    }
    return 0;
}
