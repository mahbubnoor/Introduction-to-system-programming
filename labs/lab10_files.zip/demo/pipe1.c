/* pipe1.c - the parent sends a line to its child through a pipe */
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
int main(void)
{
    int fd[2];
    if (pipe(fd) != 0) { perror("pipe"); return 1; }
    printf("pipe() gave fd[0] = %d (read end), fd[1] = %d (write end)\n", fd[0], fd[1]);
    fflush(stdout);
    if (fork() == 0) {                           /* child: the reader */
        close(fd[1]);                            /* it never writes */
        char buf[100];
        ssize_t n = read(fd[0], buf, sizeof buf - 1);
        buf[n > 0 ? n : 0] = '\0';
        printf("child  %d read %zd bytes: \"%s\"\n", getpid(), n, buf);
        n = read(fd[0], buf, sizeof buf);        /* parent closed its end: end of file */
        printf("child  %d read again: %zd (0 = end of file)\n", getpid(), n);
        return 0;
    }
    close(fd[0]);                                /* parent: the writer */
    const char *msg = "hello through a pipe";
    ssize_t n = write(fd[1], msg, strlen(msg));
    printf("parent %d wrote %zd bytes\n", getpid(), n);
    fflush(stdout);
    close(fd[1]);                                /* this is what gives the child its end of file */
    wait(NULL);
    return 0;
}
