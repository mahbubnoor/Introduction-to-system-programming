/* sigchld.c - five children end at the same moment: how many SIGCHLD arrive? */
#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
static volatile sig_atomic_t signals, reaped;
static void on_chld(int sig)
{
    (void)sig;
    int saved = errno;                            /* waitpid may change errno: restore it */
    signals++;
    while (waitpid(-1, NULL, WNOHANG) > 0)        /* collect ALL finished children, not just one */
        reaped++;
    errno = saved;
}
int main(void)
{
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = on_chld;
    sa.sa_flags = SA_RESTART;
    sigaction(SIGCHLD, &sa, NULL);
    sigset_t chld, old;
    sigemptyset(&chld);
    sigaddset(&chld, SIGCHLD);
    sigprocmask(SIG_BLOCK, &chld, &old);          /* hold SIGCHLD back while we start them */
    for (int i = 0; i < 5; i++)
        if (fork() == 0) _exit(0);
    sleep(1);                                     /* by now all five have ended: zombies */
    sigprocmask(SIG_SETMASK, &old, NULL);         /* let SIGCHLD in */
    printf("children: 5   SIGCHLD handler calls: %d   children reaped: %d\n", (int)signals, (int)reaped);
    return 0;
}
