/* pipebw.c - how fast can a pipe move data? 1 GiB in chunks of different sizes */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <sys/wait.h>
#define TOTAL (1L << 30)
static double now(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return t.tv_sec + t.tv_nsec / 1e9; }
int main(void)
{
    static char buf[1 << 16];
    int sizes[] = { 64, 4096, 65536 };
    for (int k = 0; k < 3; k++) {
        int chunk = sizes[k];
        int fd[2];
        if (pipe(fd) != 0) return 1;
        double t0 = now();
        if (fork() == 0) {                        /* writer */
            close(fd[0]);
            for (long done = 0; done < TOTAL; done += chunk)
                if (write(fd[1], buf, chunk) != chunk) _exit(1);
            _exit(0);
        }
        close(fd[1]);                             /* reader */
        long got = 0; ssize_t n;
        while ((n = read(fd[0], buf, sizeof buf)) > 0) got += n;
        close(fd[0]);
        wait(NULL);
        double t = now() - t0;
        printf("chunk %6d bytes: %5.0f MB/s  (%ld writes in %.2f s)\n", chunk, got / t / 1e6, TOTAL / chunk, t);
    }
    return 0;
}
