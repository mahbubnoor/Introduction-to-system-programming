/* sigpipe.c - writing into a pipe that nobody can read */
#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
int main(void)
{
    for (int ignore = 0; ignore < 2; ignore++) {
        int fd[2];
        if (pipe(fd) != 0) return 1;
        close(fd[0]);                             /* no reader at all */
        pid_t pid = fork();
        if (pid == 0) {
            if (ignore) signal(SIGPIPE, SIG_IGN);
            ssize_t n = write(fd[1], "hi", 2);
            printf("  child: write returned %zd, errno %d (%s)\n", n, errno, strerror(errno));
            fflush(stdout);
            _exit(0);
        }
        close(fd[1]);
        int st;
        waitpid(pid, &st, 0);
        printf("%s: ", ignore ? "SIGPIPE ignored" : "default        ");
        if (WIFSIGNALED(st)) printf("child killed by signal %d (%s)\n", WTERMSIG(st), strsignal(WTERMSIG(st)));
        else printf("child exited with status %d\n", WEXITSTATUS(st));
        fflush(stdout);                           /* before the next fork (Lecture 8.1) */
    }
    return 0;
}
