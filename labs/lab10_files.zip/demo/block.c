/* block.c - a writer that is faster than its reader has to wait (state S, inside pipe_write) */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
static void show(pid_t pid)                     /* state and wchan, read from /proc */
{
    char path[64], wchan[64] = "", stat[256] = "";
    snprintf(path, sizeof path, "/proc/%d/wchan", pid);
    FILE *f = fopen(path, "r");
    if (f) { if (!fgets(wchan, sizeof wchan, f)) wchan[0] = 0; fclose(f); }
    snprintf(path, sizeof path, "/proc/%d/stat", pid);
    f = fopen(path, "r");
    if (f) { if (!fgets(stat, sizeof stat, f)) stat[0] = 0; fclose(f); }
    char *p = strrchr(stat, ')');                 /* the state letter follows "(name) " */
    printf("writer %d: state %c, waiting in %s\n", pid, p ? p[2] : '?', wchan);
    fflush(stdout);
}
int main(void)
{
    int fd[2];
    if (pipe(fd) != 0) return 1;
    pid_t w = fork();
    if (w == 0) {                                 /* writer: 100000 bytes at once */
        close(fd[0]);
        static char big[100000];
        memset(big, 'x', sizeof big);
        ssize_t n = write(fd[1], big, sizeof big);
        fprintf(stderr, "writer: write returned %zd\n", n);
        _exit(0);
    }
    close(fd[1]);
    sleep(1);
    printf("after 1 s, nobody has read yet:\n");
    show(w);
    char buf[65536];
    long total = 0;
    ssize_t n;
    while ((n = read(fd[0], buf, sizeof buf)) > 0) total += n;
    waitpid(w, NULL, 0);
    printf("reader got %ld bytes, then end of file\n", total);
    return 0;
}
