/* interleave.c - two writers share one pipe: do their blocks get mixed? */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
int main(int argc, char *argv[])
{
    int size = argc > 1 ? atoi(argv[1]) : 4096;   /* bytes per write() */
    int blocks = 2000;
    int fd[2];
    if (pipe(fd) != 0) return 1;
    for (int k = 0; k < 2; k++)
        if (fork() == 0) {                        /* writer k writes only 'A' (k = 0) or only 'B' */
            close(fd[0]);
            char *b = malloc(size);
            memset(b, 'A' + k, size);
            for (int i = 0; i < blocks; i++)
                if (write(fd[1], b, size) != size) _exit(1);
            _exit(0);
        }
    close(fd[1]);
    /* read everything; count blocks of 'size' bytes that are not all the same letter */
    char *buf = malloc(size);
    long mixed = 0, total = 0;
    for (;;) {
        int got = 0;
        while (got < size) {
            ssize_t n = read(fd[0], buf + got, size - got);
            if (n <= 0) break;
            got += n;
        }
        if (got < size) break;
        total++;
        for (int i = 1; i < size; i++)
            if (buf[i] != buf[0]) { mixed++; break; }
    }
    while (wait(NULL) > 0) ;
    printf("write size %6d: %ld blocks read, %ld of them mixed A and B\n", size, total, mixed);
    return 0;
}
