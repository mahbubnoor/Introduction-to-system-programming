/* catch.c - catch Ctrl-C (SIGINT) three times, then give up */
#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
static volatile sig_atomic_t hits = 0;
static void on_int(int sig)
{
    (void)sig;
    hits++;
    if (write(1, "  caught SIGINT\n", 16) < 0) { }   /* write is async-signal-safe; printf is not */
}
int main(void)
{
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = on_int;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGINT, &sa, NULL);
    printf("PID %d: press Ctrl-C three times\n", getpid());
    fflush(stdout);
    while (hits < 3)
        pause();                                 /* sleep until a signal arrives */
    printf("three times: goodbye\n");
    return 0;
}
