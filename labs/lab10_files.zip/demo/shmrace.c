/* shmrace.c - two processes add 1 to the same shared counter, 10 million times each */
#define _GNU_SOURCE
#include <semaphore.h>
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
#define N 10000000
struct shared { volatile long counter; sem_t lock; };
static double now(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return t.tv_sec + t.tv_nsec / 1e9; }
static void run(struct shared *s, const char *how)
{
    s->counter = 0;
    double t0 = now();
    for (int k = 0; k < 2; k++)
        if (fork() == 0) {                        /* both children see the same page */
            for (long i = 0; i < N; i++) {
                if (strcmp(how, "plain") == 0)
                    s->counter++;                 /* load, add, store: three steps */
                else if (strcmp(how, "atomic") == 0)
                    __atomic_fetch_add(&s->counter, 1, __ATOMIC_SEQ_CST);   /* one locked instruction */
                else {
                    sem_wait(&s->lock);           /* only one process at a time */
                    s->counter++;
                    sem_post(&s->lock);
                }
            }
            _exit(0);
        }
    while (wait(NULL) > 0) ;
    printf("%-10s counter = %9ld   (expected %d)   %.2f s\n", how, s->counter, 2 * N, now() - t0);
    fflush(stdout);
}
int main(void)
{
    /* MAP_SHARED: after fork, parent and children share these bytes (no copy-on-write) */
    struct shared *s = mmap(NULL, sizeof *s, PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    if (s == MAP_FAILED) { perror("mmap"); return 1; }
    sem_init(&s->lock, 1, 1);                     /* 1 = shared between processes */
    run(s, "plain");
    run(s, "atomic");
    run(s, "semaphore");
    return 0;
}
