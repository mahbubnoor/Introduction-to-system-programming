/* segv_loop.c - a SIGSEGV handler that just returns: what happens next? */
#include <signal.h>
#include <string.h>
#include <unistd.h>
static volatile sig_atomic_t calls;
static void on_segv(int sig)
{
    (void)sig;
    calls++;
    if (write(1, "handler ran\n", 12) < 0) { }
    if (calls == 5) { if (write(1, "5 times: giving up\n", 19) < 0) { } _exit(1); }
}                                                /* returning: back to the faulting instruction */
int main(void)
{
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = on_segv;
    sigaction(SIGSEGV, &sa, NULL);
    volatile int *p = NULL;
    *p = 42;                                     /* SIGSEGV */
    if (write(1, "after the bad store\n", 20) < 0) { }
    return 0;
}
