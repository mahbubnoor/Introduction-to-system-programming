/* mask.c - block a signal, send it 3 times, unblock: how many times does the handler run? */
#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
static volatile sig_atomic_t count;
static void handler(int sig) { (void)sig; count++; }
static void status_line(const char *key)          /* ShdPnd / SigBlk from /proc/self/status */
{
    char line[256];
    FILE *f = fopen("/proc/self/status", "r");
    while (fgets(line, sizeof line, f))
        if (strncmp(line, key, strlen(key)) == 0) printf("   %s", line);
    fclose(f);
}
static void test(int sig, const char *name)
{
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = handler;
    sigaction(sig, &sa, NULL);
    sigset_t set, old;
    sigemptyset(&set);
    sigaddset(&set, sig);
    sigprocmask(SIG_BLOCK, &set, &old);            /* from now on: held back, not delivered */
    count = 0;
    for (int i = 0; i < 3; i++) kill(getpid(), sig);
    printf("%s sent 3 times while blocked: handler ran %d times\n", name, (int)count);
    status_line("ShdPnd");          /* kill() targets the process: "shared pending" */
    status_line("SigBlk");
    sigprocmask(SIG_SETMASK, &old, NULL);          /* unblock: pending signals are delivered now */
    printf("   after unblocking: handler ran %d times\n", (int)count);
}
int main(void)
{
    test(SIGUSR1, "SIGUSR1 (10)");
    test(SIGRTMIN, "SIGRTMIN (34)");
    return 0;
}
