/* pipecap.c - how much can a pipe hold before write() has to wait? */
#define _GNU_SOURCE
#include <fcntl.h>
#include <stdio.h>
#include <errno.h>
#include <unistd.h>
static long fill(int fd)
{
    long n = 0;
    while (write(fd, "x", 1) == 1) n++;          /* nobody reads: count until it is full */
    return errno == EAGAIN ? n : -1;
}
int main(void)
{
    int fd[2];
    if (pipe2(fd, O_NONBLOCK) != 0) return 1;   /* non-blocking: "full" gives EAGAIN instead of waiting */
    printf("F_GETPIPE_SZ      = %d bytes\n", fcntl(fd[1], F_GETPIPE_SZ));
    printf("filled with       %ld bytes, then write() said EAGAIN\n", fill(fd[1]));
    int fd2[2];
    if (pipe2(fd2, O_NONBLOCK) != 0) return 1;
    printf("F_SETPIPE_SZ 1 MiB -> %d bytes\n", fcntl(fd2[1], F_SETPIPE_SZ, 1 << 20));
    printf("filled with       %ld bytes\n", fill(fd2[1]));
    return 0;
}
