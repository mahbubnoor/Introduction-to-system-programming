#!/bin/sh
# fifo_demo.sh - a FIFO is a pipe with a name in the file system
rm -f /tmp/myfifo
mkfifo /tmp/myfifo
ls -l /tmp/myfifo
cat /tmp/myfifo &                  # the reader: open() waits until a writer comes
sleep 1
echo "reader is waiting in: $(cat /proc/$!/wchan)"
echo "hello from another process" > /tmp/myfifo
wait
rm /tmp/myfifo
