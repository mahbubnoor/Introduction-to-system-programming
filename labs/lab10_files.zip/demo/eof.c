/* eof.c - the reader only sees end of file when EVERY write end is closed */
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
int main(int argc, char *argv[])
{
    int forget = argc > 1;                        /* ./eof forget : the parent keeps its write end */
    int fd[2];
    if (pipe(fd) != 0) return 1;
    if (fork() == 0) {                            /* child: write two lines, then end */
        close(fd[0]);
        if (write(fd[1], "line 1\nline 2\n", 14) != 14) _exit(1);
        _exit(0);                                 /* exit closes the child's write end */
    }
    if (!forget) close(fd[1]);
    char buf[100];
    ssize_t n;
    while ((n = read(fd[0], buf, sizeof buf)) > 0)
        printf("parent read %zd bytes\n", n), fflush(stdout);
    printf("parent: read returned %zd: end of file\n", n);
    wait(NULL);
    return 0;
}
