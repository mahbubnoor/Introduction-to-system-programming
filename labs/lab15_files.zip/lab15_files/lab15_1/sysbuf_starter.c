// SPDX-License-Identifier: GPL-2.0
/*
 * sysbuf.c - a character device: /dev/sysbuf is a 4 KiB buffer in the kernel that you can write, read and seek
 * CSE 4105 System Programming, Lab 15.1   (STARTER: fill in TODO 1-4)
 *
 * In the QEMU guest:  insmod sysbuf.ko ; echo hello > /dev/sysbuf ; cat /dev/sysbuf ; ./sbtest
 */
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/fs.h>
#include <linux/module.h>
#include <linux/mutex.h>
#include <linux/uaccess.h>
#include "sysbuf.h"

#define SYSBUF_SIZE 4096

static char data[SYSBUF_SIZE];            /* the device's "hardware": a buffer */
static size_t used;                       /* bytes stored */
static DEFINE_MUTEX(lock);

static dev_t devno;                       /* major + minor, from alloc_chrdev_region */
static struct cdev cdev;
static struct class *cls;

static int sysbuf_open(struct inode *inode, struct file *f)
{
    pr_info("sysbuf: open by %s (pid %d), minor %d, flags 0x%x\n", current->comm, current->pid, iminor(inode), f->f_flags);
    if ((f->f_flags & O_ACCMODE) != O_RDONLY && (f->f_flags & O_TRUNC)) {   /* echo > /dev/sysbuf truncates */
        mutex_lock(&lock);
        used = 0;
        mutex_unlock(&lock);
    }
    return 0;
}

static ssize_t sysbuf_read(struct file *f, char __user *buf, size_t count, loff_t *pos)
{
    /* TODO 2: under the mutex:
     *   - if *pos >= used: return 0 (end of file)
     *   - n = min(count, used - *pos)
     *   - copy_to_user(buf, data + *pos, n); if it fails return -EFAULT   (buf is a USER pointer!)
     *   - *pos += n; return n
     * Do not forget mutex_unlock on every return path. */
    return 0;
}

static ssize_t sysbuf_write(struct file *f, const char __user *buf, size_t count, loff_t *pos)
{
    /* TODO 3: under the mutex:
     *   - if *pos >= SYSBUF_SIZE: return -ENOSPC  ("No space left on device")
     *   - n = min(count, SYSBUF_SIZE - *pos)
     *   - copy_from_user(data + *pos, buf, n); if it fails return -EFAULT
     *   - *pos += n; if *pos > used then used = *pos; return n */
    pr_info("sysbuf: write is TODO 3\n");
    return -EINVAL;
}

static long sysbuf_ioctl(struct file *f, unsigned int cmd, unsigned long arg)
{
    /* TODO 4: switch (cmd)
     *   SYSBUF_CLEAR:   used = 0 (under the mutex), return 0
     *   SYSBUF_GETSIZE: put_user((int)used, (int __user *)arg)   -- arg is a user address
     *   default:        return -ENOTTY  ("Inappropriate ioctl for device") */
    return -ENOTTY;
}

static const struct file_operations sysbuf_fops = {
    .owner = THIS_MODULE,
    .open = sysbuf_open,
    .read = sysbuf_read,
    .write = sysbuf_write,
    .llseek = default_llseek,
    .unlocked_ioctl = sysbuf_ioctl,
};

static int __init sysbuf_init(void)
{
    /* TODO 1: register the device, in this order, undoing everything on failure (goto, reverse order):
     *   alloc_chrdev_region(&devno, 0, 1, "sysbuf")     a free major, minor 0
     *   cdev_init(&cdev, &sysbuf_fops); cdev_add(&cdev, devno, 1)
     *   cls = class_create("sysbuf")                     check with IS_ERR / PTR_ERR
     *   device_create(cls, NULL, devno, NULL, "sysbuf")  makes /dev/sysbuf (devtmpfs)
     *   pr_info("sysbuf: ready as /dev/sysbuf, major %d minor %d\n", MAJOR(devno), MINOR(devno));
     * sysbuf_exit below already undoes all four. */
    pr_info("sysbuf: not registered yet: TODO 1\n");
    return -ENODEV;
}

static void __exit sysbuf_exit(void)
{
    device_destroy(cls, devno);
    class_destroy(cls);
    cdev_del(&cdev);
    unregister_chrdev_region(devno, 1);
    pr_info("sysbuf: removed\n");
}

module_init(sysbuf_init);
module_exit(sysbuf_exit);
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Lecture 15.1 lab: a character device");
