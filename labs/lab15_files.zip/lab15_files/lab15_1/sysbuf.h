/* sysbuf.h - the ioctl commands of /dev/sysbuf, shared by the driver and user programs */
#ifndef SYSBUF_H
#define SYSBUF_H
#include <linux/ioctl.h>
#define SYSBUF_MAGIC 'S'
#define SYSBUF_CLEAR    _IO(SYSBUF_MAGIC, 1)          /* empty the buffer          */
#define SYSBUF_GETSIZE  _IOR(SYSBUF_MAGIC, 2, int)    /* how many bytes are stored */
#endif
