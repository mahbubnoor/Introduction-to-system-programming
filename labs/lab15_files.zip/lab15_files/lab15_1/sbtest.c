/* sbtest.c - use /dev/sysbuf from C: write, lseek, read, ioctl */
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include "sysbuf.h"
int main(void)
{
    int fd = open("/dev/sysbuf", O_RDWR);
    if (fd < 0) { perror("open /dev/sysbuf"); return 1; }
    int size;
    ioctl(fd, SYSBUF_CLEAR);
    ssize_t w = write(fd, "University of Barishal", 22);
    ioctl(fd, SYSBUF_GETSIZE, &size);
    printf("write: %zd bytes, size now %d\n", w, size);
    lseek(fd, 14, SEEK_SET);                          /* jump to "Barishal" */
    char buf[32] = {0};
    ssize_t r = read(fd, buf, sizeof buf - 1);
    printf("read at offset 14: %zd bytes \"%s\"\n", r, buf);
    r = read(fd, buf, sizeof buf - 1);
    printf("read again: %zd (end of file)\n", r);
    if (ioctl(fd, 0x1234) < 0) perror("ioctl 0x1234");
    printf("SYSBUF_GETSIZE = 0x%lx  (_IOR('S', 2, int))\n", (unsigned long)SYSBUF_GETSIZE);
    close(fd);
    return 0;
}
