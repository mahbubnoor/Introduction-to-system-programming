#!/bin/sh
# run_guest.sh - boot the lab PC's own kernel in QEMU with busybox and your files, and give you a root shell.
#   ./run_guest.sh DIR...          every *.ko and every executable file in the DIRs is copied to /mod in the guest
#   USB=1 ./run_guest.sh DIR...    also plug in a USB host controller (UHCI) with a USB keyboard and a USB mouse
# KERNEL: a readable copy of this PC's kernel (once, by the instructor or with sudo):
#   sudo cp /boot/vmlinuz-$(uname -r) guest/vmlinuz && sudo chmod a+r guest/vmlinuz   (next to this script)
# Leave the guest with:  poweroff -f      (or Ctrl-A then X)
# QEMU monitor (Lab 15.3): Ctrl-A then C switches between the guest shell and the monitor. In the monitor:
#   sendkey h          press and release the key h on the USB keyboard
#   device_del kbd1    unplug the keyboard       device_add usb-kbd,id=kbd2,bus=uhci.0    plug a new one in
set -e
HERE=$(cd "$(dirname "$0")" && pwd)
KERNEL=${KERNEL:-$HERE/vmlinuz}
BB=${BUSYBOX:-$HERE/busybox}
[ -r "$KERNEL" ] || { echo "no readable kernel at $KERNEL (see the comment at the top)"; exit 1; }
R=$(mktemp -d)
chmod 755 $R; mkdir -p $R/bin $R/proc $R/sys $R/dev $R/tmp $R/mod $R/mnt
cp "$BB" $R/bin/busybox
for a in $($R/bin/busybox --list); do [ "$a" = busybox ] || ln -sf busybox $R/bin/$a; done
for d in "$@"; do
  find "$d" -maxdepth 2 -name '*.ko' -exec cp {} $R/mod/ \;
  find "$d" -maxdepth 2 -type f -perm -u+x ! -name '*.ko' ! -name '*.sh' ! -name busybox ! -name vmlinuz -exec cp {} $R/mod/ \;
done
cat > $R/init <<'EOI'
#!/bin/sh
mount -t proc proc /proc
mount -t sysfs sysfs /sys
mount -t devtmpfs devtmpfs /dev
export PATH=/bin:/mod
cd /mod
echo; echo "guest $(uname -r): your files are in /mod:"; ls /mod; echo "(poweroff -f to leave)"
exec setsid cttyhack sh
EOI
chmod +x $R/init
(cd $R && find . | cpio -o -H newc 2>/dev/null | gzip > "$HERE/guest.cpio.gz")
rm -rf $R
USBDEV=
[ -n "$USB" ] && USBDEV="-device piix3-usb-uhci,id=uhci -device usb-kbd,id=kbd1,bus=uhci.0 -device usb-mouse,id=mouse1,bus=uhci.0"
exec qemu-system-x86_64 -m 512 -nographic -no-reboot -kernel "$KERNEL" -initrd "$HERE/guest.cpio.gz" \
     -append "console=ttyS0 quiet panic=-1" $USBDEV $EXTRA_QEMU
