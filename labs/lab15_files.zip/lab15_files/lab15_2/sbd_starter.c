// SPDX-License-Identifier: GPL-2.0
/*
 * sbd.c - a simple block device: a RAM disk /dev/sbd0, using blk-mq (Linux 6.8)
 * CSE 4105 System Programming, Lab 15.2   (STARTER: fill in TODO 1-3)
 *
 * In the QEMU guest:  insmod sbd.ko size_mb=16 ; mkfs.ext2 /dev/sbd0 ; mount /dev/sbd0 /mnt ; ...
 */
#include <linux/blk-mq.h>
#include <linux/blkdev.h>
#include <linux/highmem.h>
#include <linux/module.h>
#include <linux/vmalloc.h>
#include <linux/version.h>

/* API differences between kernel versions (this file was written and tested on 6.8) */
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 14, 0)
#define SBD_TAG_FLAGS 0                          /* 6.14+: BLK_MQ_F_SHOULD_MERGE is gone, merging is always on */
#else
#define SBD_TAG_FLAGS BLK_MQ_F_SHOULD_MERGE
#endif
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 9, 0)
#define sbd_alloc_disk(set) blk_mq_alloc_disk(set, NULL, NULL)   /* 6.9+: (set, queue limits, queuedata) */
#else
#define sbd_alloc_disk(set) blk_mq_alloc_disk(set, NULL)         /* 6.8: (set, queuedata) */
#endif

static int size_mb = 16;
module_param(size_mb, int, 0444);
MODULE_PARM_DESC(size_mb, "disk size in MiB");
static bool trace;                           /* print every request (echo 1 > /sys/module/sbd/parameters/trace) */
module_param(trace, bool, 0644);

static int major;                            /* from register_blkdev */
static u8 *store;                            /* the "platters": size_mb MiB of kernel memory */
static struct blk_mq_tag_set tag_set;
static struct gendisk *disk;
static atomic_t nreq = ATOMIC_INIT(0);

/* the heart of the driver: called by the block layer for every request */
static blk_status_t sbd_queue_rq(struct blk_mq_hw_ctx *hctx, const struct blk_mq_queue_data *bd)
{
    struct request *rq = bd->rq;
    loff_t pos = (loff_t)blk_rq_pos(rq) << SECTOR_SHIFT;  /* first byte: sector number * 512 */
    struct req_iterator iter;
    struct bio_vec bv;

    blk_mq_start_request(rq);
    if (pos + blk_rq_bytes(rq) > (loff_t)size_mb << 20) {
        blk_mq_end_request(rq, BLK_STS_IOERR);              /* beyond the end of the disk */
        return BLK_STS_OK;
    }
    if (trace)
        pr_info("sbd: %s sector %llu, %u bytes\n", rq_data_dir(rq) == WRITE ? "WRITE" : "READ ",
                (unsigned long long)blk_rq_pos(rq), blk_rq_bytes(rq));
    atomic_inc(&nreq);

    /* TODO 1: copy the data. A request is a list of memory pieces (segments):
     *   rq_for_each_segment(bv, rq, iter) {
     *       void *buf = bvec_kmap_local(&bv);            map the page-cache page
     *       WRITE: memcpy(store + pos, buf, bv.bv_len)   READ: memcpy(buf, store + pos, bv.bv_len)
     *       kunmap_local(buf); pos += bv.bv_len;
     *   }
     * Until then every write is lost and every read returns zeros. */
    (void)iter; (void)bv;

    blk_mq_end_request(rq, BLK_STS_OK);                    /* done: wake up whoever waits */
    return BLK_STS_OK;
}

static const struct blk_mq_ops sbd_mq_ops = {
    .queue_rq = sbd_queue_rq,
};

static const struct block_device_operations sbd_fops = {
    .owner = THIS_MODULE,
};

static int __init sbd_init(void)
{
    int err;
    if (size_mb < 1 || size_mb > 256)
        return -EINVAL;
    store = vzalloc((size_t)size_mb << 20);
    if (!store)
        return -ENOMEM;
    major = register_blkdev(0, "sbd");                     /* 0: give me a free major */
    if (major < 0) {
        err = major;
        goto undo_store;
    }
    /* TODO 2: the request queue and the disk
     *   err = blk_mq_alloc_sq_tag_set(&tag_set, &sbd_mq_ops, 16, SBD_TAG_FLAGS);   1 queue, 16 deep
     *   disk = sbd_alloc_disk(&tag_set);           check with IS_ERR / PTR_ERR
     *   disk->major = major; disk->first_minor = 0; disk->minors = 1; disk->fops = &sbd_fops;
     *   snprintf(disk->disk_name, DISK_NAME_LEN, "sbd0");
     * TODO 3: make it visible
     *   set_capacity(disk, size in 512-byte SECTORS);   (size_mb << 20) bytes = (size_mb << 11) sectors
     *   err = add_disk(disk);                           now /dev/sbd0 exists and I/O can start
     * On every failure, jump to the right undo label below (reverse order). */
    pr_info("sbd: no disk yet: TODO 2 and 3\n");
    err = -ENODEV;
    goto undo_major;

    pr_info("sbd: /dev/sbd0 ready, %d MiB, major %d\n", size_mb, major);
    return 0;
undo_disk:
    put_disk(disk);
undo_tags:
    blk_mq_free_tag_set(&tag_set);
undo_major:
    unregister_blkdev(major, "sbd");
undo_store:
    vfree(store);
    return err;
}

static void __exit sbd_exit(void)
{
    del_gendisk(disk);
    put_disk(disk);
    blk_mq_free_tag_set(&tag_set);
    unregister_blkdev(major, "sbd");
    vfree(store);
    pr_info("sbd: removed after %d requests\n", atomic_read(&nreq));
}

module_init(sbd_init);
module_exit(sbd_exit);
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Lecture 15.2 lab: a RAM block device with blk-mq");
