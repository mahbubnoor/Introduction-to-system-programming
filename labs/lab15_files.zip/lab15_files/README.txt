CSE 4105 System Programming - Lab 15 (Lectures 15.1-15.3): character, block and USB device drivers
====================================================================================================
Works offline. Needs: gcc, make, the kernel headers of this PC (/lib/modules/$(uname -r)/build must exist;
Ubuntu installs them with the kernel: package linux-headers-$(uname -r)), glibc's static library for the
test programs (package libc6-dev, normally installed with gcc) and qemu-system-x86_64.

RULE: build on the PC, LOAD ONLY IN THE VIRTUAL MACHINE. A bug in a driver is a bug in the kernel.

ONCE PER PC (needs sudo, or the instructor does it): a readable copy of this PC's kernel for the VM
  sudo cp /boot/vmlinuz-$(uname -r) guest/vmlinuz && sudo chmod a+r guest/vmlinuz

guest/run_guest.sh DIR...   boots the VM; every .ko AND every executable program (sbtest, mylsusb) found in
                            the DIRs is copied to /mod (also on PATH). Root shell. Leave with: poweroff -f
USB=1 guest/run_guest.sh …  also plugs in a USB host controller (UHCI), a USB keyboard (id kbd1) and a mouse.
QEMU monitor (Lab 15.3):    press Ctrl-A, then C. Type commands, then Ctrl-A, C again to get back:
                              sendkey h          sendkey shift-b        info usb
                              device_del kbd1    device_add usb-kbd,id=kbd2,bus=uhci.0
                            Wait a second after sendkey before dmesg: the reports arrive asynchronously.

LAB 15.1  /dev/sysbuf, a character device            cd lab15_1 && make && ../guest/run_guest.sh .
  (make also builds the static test program sbtest; gcc warns 'data' unused until TODO 2/3: expected)
  Before TODO 1, insmod fails with "No such device" (status 19): the starter says "TODO 1" in dmesg.
  TODO 1 init: alloc_chrdev_region, cdev_init + cdev_add, class_create, device_create (goto ladder on errors)
  TODO 2 read (EOF, copy_to_user)   TODO 3 write (-ENOSPC, copy_from_user)   TODO 4 ioctl (CLEAR, GETSIZE, -ENOTTY)
  Test: insmod sysbuf_starter.ko ; ls -l /dev/sysbuf ; echo hello > /dev/sysbuf ; cat /dev/sysbuf
        dd if=/dev/zero of=/dev/sysbuf bs=1024 count=5   (the 5th block: No space left on device) ; ./sbtest

LAB 15.2  /dev/sbd0, a RAM disk with blk-mq          cd lab15_2 && make && ../guest/run_guest.sh .
  (gcc warns that labels undo_disk and undo_tags are unused until TODO 2-3: expected)
  TODO 2 tag set + gendisk   TODO 3 set_capacity (in 512-byte SECTORS) + add_disk   TODO 1 the segment loop
  Test: insmod sbd_starter.ko ; mke2fs -q /dev/sbd0 ; mount /dev/sbd0 /mnt ; echo hi > /mnt/f ; umount /mnt
        mount /dev/sbd0 /mnt ; cat /mnt/f ; cat /sys/block/sbd0/stat
        echo 1 > /sys/module/sbd_starter/parameters/trace   (every request in dmesg)
  Without TODO 1, mke2fs "works" but mount fails with "Invalid argument": the data never reached the disk.

LAB 15.3  a USB keyboard driver                      cd lab15_3 && make && USB=1 ../guest/run_guest.sh .
  (make also builds mylsusb; gcc warns skbd_irq and usage_to_char unused until TODO 3-4: expected)
  First: ./mylsusb   (the keyboard's interface 1-1:1.0 has no driver: our guest has no usbhid)
  TODO 1 id_table (class 3, subclass 1, protocol 1)   TODO 2 find the interrupt IN endpoint
  TODO 3 usb_fill_int_urb + usb_set_intfdata + usb_submit_urb   TODO 4 print the report, resubmit (GFP_ATOMIC)
  Test: insmod sysprog_kbd_starter.ko ; dmesg ; Ctrl-A C ; sendkey h ; Ctrl-A C ; dmesg | grep report
        unplug and plug in the monitor (device_del / device_add) and watch probe and disconnect

Written and tested on kernel 6.8 (Ubuntu 24.04). sbd_starter.c has two macros at the top (SBD_TAG_FLAGS,
sbd_alloc_disk) that pick the right block-layer calls for 6.9+ and 6.14+ kernels: use them in TODO 2.
If the compiler names another function on a newer kernel, ask the instructor.
