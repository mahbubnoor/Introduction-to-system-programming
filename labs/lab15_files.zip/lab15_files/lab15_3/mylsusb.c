/* mylsusb.c - a small lsusb: list USB devices and their interfaces from /sys/bus/usb/devices */
#include <dirent.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

static void attr(const char *dir, const char *name, char *out, size_t n)
{
    char path[PATH_MAX];
    snprintf(path, sizeof path, "/sys/bus/usb/devices/%s/%s", dir, name);
    FILE *f = fopen(path, "r");
    out[0] = '\0';
    if (!f) { snprintf(out, n, "-"); return; }
    if (fgets(out, n, f)) out[strcspn(out, "\n")] = '\0';
    fclose(f);
}

static int by_name(const struct dirent **a, const struct dirent **b) { return strcmp((*a)->d_name, (*b)->d_name); }

int main(void)
{
    struct dirent **e;
    int n = scandir("/sys/bus/usb/devices", &e, NULL, by_name);
    if (n < 0) { perror("/sys/bus/usb/devices"); return 1; }
    for (int i = 0; i < n; i++) {
        const char *d = e[i]->d_name;
        char a[128], b[128], c[128], p[128], m[128], drv[PATH_MAX] = "-", path[PATH_MAX];
        if (d[0] == '.') continue;
        snprintf(path, sizeof path, "/sys/bus/usb/devices/%s/driver", d);
        ssize_t k = readlink(path, drv, sizeof drv - 1);
        if (k > 0) { drv[k] = '\0'; memmove(drv, strrchr(drv, '/') + 1, strlen(strrchr(drv, '/'))); }
        if (strchr(d, ':')) {                               /* an interface, e.g. 1-1:1.0 */
            attr(d, "bInterfaceClass", a, sizeof a);
            attr(d, "bInterfaceSubClass", b, sizeof b);
            attr(d, "bInterfaceProtocol", c, sizeof c);
            attr(d, "bNumEndpoints", p, sizeof p);
            printf("    %-10s interface class %s/%s/%s, %s endpoints, driver %s\n", d, a, b, c, p, drv);
        } else {                                            /* a device, e.g. 1-1 or usb1 (a root hub) */
            attr(d, "idVendor", a, sizeof a);
            attr(d, "idProduct", b, sizeof b);
            attr(d, "speed", c, sizeof c);
            attr(d, "manufacturer", m, sizeof m);
            attr(d, "product", p, sizeof p);
            printf("%-10s %s:%s  %s Mbit/s  %s / %s  (driver %s)\n", d, a, b, c, m, p, drv);
        }
        free(e[i]);
    }
    free(e);
    return 0;
}
