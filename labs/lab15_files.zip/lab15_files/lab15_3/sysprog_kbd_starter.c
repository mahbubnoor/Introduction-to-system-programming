// SPDX-License-Identifier: GPL-2.0
/*
 * sysprog_kbd.c - a USB driver for a boot-protocol keyboard (QEMU's usb-kbd):
 *                 find the interrupt IN endpoint, keep one URB in flight, print every key report.
 * CSE 4105 System Programming, Lab 15.3   (STARTER: fill in TODO 1-4)
 *
 * QEMU:   -device piix3-usb-uhci,id=uhci -device usb-kbd,bus=uhci.0   (usbhid is a module that is not in our guest,
 *         so our driver gets the keyboard)
 * Guest:  insmod sysprog_kbd.ko ; dmesg            (keys typed into the QEMU monitor with "sendkey" arrive as reports)
 */
#include <linux/module.h>
#include <linux/slab.h>
#include <linux/usb.h>

struct skbd {                                   /* one per keyboard (per interface) */
    struct usb_device *udev;
    struct urb *urb;
    u8 *buf;                                    /* 8-byte boot report: modifiers, reserved, 6 key codes */
    dma_addr_t dma;
    int maxp, reports;
};

/* HID usage codes 0x04..0x1d are the letters a..z (USB HID Usage Tables, keyboard page) */
static char usage_to_char(u8 u)
{
    if (u >= 0x04 && u <= 0x1d) return 'a' + (u - 0x04);
    if (u >= 0x1e && u <= 0x26) return '1' + (u - 0x1e);
    if (u == 0x27) return '0';
    if (u == 0x2c) return ' ';
    return '?';
}

/* called in interrupt context when the host controller finished our URB */
static void skbd_irq(struct urb *urb)
{
    struct skbd *k = urb->context;
    u8 *r = k->buf;
    switch (urb->status) {
    case 0:
        break;
    case -ECONNRESET: case -ENOENT: case -ESHUTDOWN:   /* unlinked or device gone: stop */
        return;
    default:
        goto resubmit;
    }
    k->reports++;
    /* TODO 4a: print the report. r[0] = modifier bits (0x02 left shift, 0x20 right shift), r[2] = first key's usage code.
     *   dev_info(&k->udev->dev, "report %d: %8ph  key 0x%02x '%c'%s\n", k->reports, r, r[2], usage_to_char(r[2]), ...);
     *   r[2] == 0 means all keys are up. */
    (void)r;
resubmit:
    /* TODO 4b: give the URB back to the host controller, or this is the last report you ever get:
     *   usb_submit_urb(urb, GFP_ATOMIC)      we are in interrupt context: no sleeping allocation */
    ;
}

static int skbd_probe(struct usb_interface *intf, const struct usb_device_id *id)
{
    struct usb_device *udev = interface_to_usbdev(intf);
    struct usb_host_interface *alt = intf->cur_altsetting;
    struct usb_endpoint_descriptor *ep = NULL;
    struct skbd *k;
    int i, err;

    dev_info(&intf->dev, "probe: %04x:%04x \"%s\" \"%s\", interface %d class %d/%d/%d, %d endpoint(s)\n",
             le16_to_cpu(udev->descriptor.idVendor), le16_to_cpu(udev->descriptor.idProduct),
             udev->manufacturer ?: "?", udev->product ?: "?", alt->desc.bInterfaceNumber,
             alt->desc.bInterfaceClass, alt->desc.bInterfaceSubClass, alt->desc.bInterfaceProtocol,
             alt->desc.bNumEndpoints);

    for (i = 0; i < alt->desc.bNumEndpoints; i++) {     /* find an interrupt IN endpoint */
        struct usb_endpoint_descriptor *e = &alt->endpoint[i].desc;
        dev_info(&intf->dev, "  endpoint 0x%02x: %s %s, max packet %d, interval %d\n", e->bEndpointAddress,
                 usb_endpoint_xfer_int(e) ? "interrupt" : usb_endpoint_xfer_bulk(e) ? "bulk" : "other",
                 usb_endpoint_dir_in(e) ? "IN" : "OUT", usb_endpoint_maxp(e), e->bInterval);
        /* TODO 2: remember the first INTERRUPT IN endpoint in ep (usb_endpoint_is_int_in(e)) */
    }
    if (!ep)
        return -ENODEV;

    k = kzalloc(sizeof(*k), GFP_KERNEL);
    if (!k)
        return -ENOMEM;
    k->udev = udev;
    k->maxp = usb_endpoint_maxp(ep);
    k->buf = usb_alloc_coherent(udev, 8, GFP_KERNEL, &k->dma);   /* DMA-able: the controller writes here */
    k->urb = usb_alloc_urb(0, GFP_KERNEL);
    if (!k->buf || !k->urb) {
        err = -ENOMEM;
        goto fail;
    }
    /* TODO 3: describe the transfer and start it
     *   usb_fill_int_urb(k->urb, udev, usb_rcvintpipe(udev, ep->bEndpointAddress), k->buf, min(k->maxp, 8),
     *                    skbd_irq, k, ep->bInterval);
     *   k->urb->transfer_dma = k->dma;  k->urb->transfer_flags |= URB_NO_TRANSFER_DMA_MAP;
     *   usb_set_intfdata(intf, k);       (disconnect gets k back with usb_get_intfdata)
     *   err = usb_submit_urb(k->urb, GFP_KERNEL);  if (err) goto fail;                         */
    err = -ENODEV;
    dev_info(&intf->dev, "probe: no URB yet: TODO 3\n");
    goto fail;
    dev_info(&intf->dev, "listening on endpoint 0x%02x\n", ep->bEndpointAddress);
    return 0;
fail:
    usb_free_urb(k->urb);
    if (k->buf)
        usb_free_coherent(udev, 8, k->buf, k->dma);
    kfree(k);
    return err;
}

static void skbd_disconnect(struct usb_interface *intf)
{
    struct skbd *k = usb_get_intfdata(intf);
    usb_kill_urb(k->urb);                                /* wait until it is no longer in flight */
    usb_free_urb(k->urb);
    usb_free_coherent(k->udev, 8, k->buf, k->dma);
    dev_info(&intf->dev, "disconnect after %d reports\n", k->reports);
    kfree(k);
}

static const struct usb_device_id skbd_ids[] = {
    /* TODO 1: which interfaces do we want?  class 3 (HID), subclass 1 (boot), protocol 1 (keyboard):
     *   { USB_INTERFACE_INFO(USB_CLASS_HID, 1, 1) },
     * With an empty table probe is never called. Compare with the MODALIAS in the uevent. */
    { }
};
MODULE_DEVICE_TABLE(usb, skbd_ids);                     /* -> modules.alias, so udev can load us */

static struct usb_driver skbd_driver = {
    .name = "sysprog_kbd",
    .id_table = skbd_ids,
    .probe = skbd_probe,
    .disconnect = skbd_disconnect,
};
module_usb_driver(skbd_driver);

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Lecture 15.3 lab: a USB keyboard driver with an interrupt URB");
