/* usable.c - how many bytes does malloc really give you? */
#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>
int main(void)
{
    size_t req[] = { 0, 1, 24, 25, 40, 41, 1000 };
    for (int i = 0; i < 7; i++) {
        void *p = malloc(req[i]);
        printf("malloc(%4zu): usable %4zu, chunk %4zu\n", req[i], malloc_usable_size(p), ((size_t *)p)[-1] & ~(size_t)7);
    }
    return 0;
}
