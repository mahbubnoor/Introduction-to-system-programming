/* deep.c - how deep can recursion go before the stack runs out? */
#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
static volatile long depth;
static char altstack[65536];
static void on_segv(int s) { (void)s; char m[80]; int n = snprintf(m, sizeof m, "SIGSEGV at depth %ld (about %ld KiB of stack)\n", depth, depth); if (write(1, m, n) < 0) {} _exit(1); }
__attribute__((noinline)) static long dive(long n)   /* infinite on purpose */
{
    volatile char frame[1000];                    /* about 1 KiB per call */
    frame[0] = (char)n;
    depth = n;
    return dive(n + 1) + frame[0];
}
int main(void)
{
    stack_t ss = { .ss_sp = altstack, .ss_size = sizeof altstack };
    sigaltstack(&ss, NULL);                       /* the handler needs a stack of its own: the normal one is full */
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = on_segv;
    sa.sa_flags = SA_ONSTACK;
    sigaction(SIGSEGV, &sa, NULL);
    return (int)dive(1);
}
