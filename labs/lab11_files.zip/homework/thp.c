/* thp.c - 100 MiB with 4 KiB pages, then with 2 MiB huge pages: count the page faults */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/resource.h>
#define SIZE (100L << 20)
static long minflt(void) { struct rusage u; getrusage(RUSAGE_SELF, &u); return u.ru_minflt; }
int main(void)
{
    for (int huge = 0; huge < 2; huge++) {
        char *p = aligned_alloc(2L << 20, SIZE);              /* 2 MiB aligned, so huge pages can fit */
        if (huge) madvise(p, SIZE, MADV_HUGEPAGE);           /* please use 2 MiB pages here */
        long f0 = minflt();
        memset(p, 1, SIZE);
        printf("%-16s %6ld page faults\n", huge ? "MADV_HUGEPAGE:" : "normal 4 KiB:", minflt() - f0);
        free(p);
    }
    return 0;
}
