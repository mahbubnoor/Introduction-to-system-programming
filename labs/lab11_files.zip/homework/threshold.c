/* threshold.c - malloc(200000), free, and again: does it still use mmap? Run with strace -e trace=brk,mmap,munmap */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
int main(void)
{
    for (int i = 1; i <= 3; i++) {
        if (write(2, "--- malloc(200000)\n", 19) < 0) return 1;
        char *p = malloc(200000);
        p[0] = 1;
        printf("round %d: %p\n", i, (void *)p);
        free(p);
    }
    return 0;
}
