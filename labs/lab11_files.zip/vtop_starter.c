/*
 * vtop.c - virtual to physical: ask /proc/self/pagemap where each page really is
 * CSE 4105 System Programming, Lab 11.1   (STARTER: fill in the parts marked TODO)
 *
 * Build:  gcc -Wall -O0 -o vtop vtop.c
 * Run:    sudo ./vtop        (without root, every frame number reads as 0; the other bits still work)
 */
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define PAGE 4096UL
static int pagemap_fd;
int global_var = 7;

/* print one address: its page-table indices, and what pagemap says about its page */
static void lookup(const char *name, const void *ptr)
{
    uintptr_t v = (uintptr_t)ptr;

    /* TODO 1: x86-64 uses 4 levels: 9 + 9 + 9 + 9 bits of index, then 12 bits of offset.
     *         pgd = bits 47-39, pud = bits 38-30, pmd = bits 29-21, pte = bits 20-12, off = bits 11-0.
     *         Hint: (v >> 39) & 511                                                               */
    unsigned pgd = 0, pud = 0, pmd = 0, pte = 0;
    unsigned off = 0;

    /* TODO 2: pagemap has one 8-byte entry per virtual page. Read the entry for v with
     *         pread(pagemap_fd, &e, 8, offset); the offset is (v / PAGE) * 8.                     */
    uint64_t e = 0;

    /* TODO 3: decode the entry (Linux: Documentation/admin-guide/mm/pagemap.rst):
     *         bit 63 present, bit 61 file page or shared, bit 56 mapped only by this process,
     *         bits 0-54 the physical frame number (PFN).                                          */
    int present = 0, file = 0, mine = 0;
    uint64_t pfn = 0;
    (void)v; (void)e;

    printf("%-16s %14p  [%3u %3u %3u %3u] +0x%03x  ", name, ptr, pgd, pud, pmd, pte, off);
    if (!present)
        printf("not present\n");
    else
        /* TODO 4: the physical address is the frame's start (pfn * PAGE) plus the offset */
        printf("present  file %d  only mine %d  frame 0x%-7llx physical 0x%llx\n", file, mine,
               (unsigned long long)pfn, 0ULL);
}

int main(void)
{
    pagemap_fd = open("/proc/self/pagemap", O_RDONLY);
    if (pagemap_fd < 0) { perror("/proc/self/pagemap"); return 1; }

    int local = 1;
    char *small = malloc(64);
    char *big = malloc(10 << 20);                 /* 10 MiB: mmap, not touched yet */
    printf("name             virtual         [pgd pud pmd pte] offset\n");
    lookup("main (code)", (void *)main);
    lookup("printf (libc)", (void *)printf);
    lookup("global_var", &global_var);
    lookup("local", &local);
    lookup("malloc(64)", small);
    lookup("big, untouched", big + 5 * 4096);
    big[5 * 4096] = 1;                            /* the first write: a page fault gives it a frame */
    lookup("big, touched", big + 5 * 4096);
    return 0;
}
