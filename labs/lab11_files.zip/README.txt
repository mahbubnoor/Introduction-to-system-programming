CSE 4105 System Programming - Lab 11 (Lectures 11.1 and 11.2): virtual memory and memory allocation
====================================================================================================
Works offline. Needs: gcc, strace (gdb optional). Tested with gcc 13.3 and glibc 2.39 (Ubuntu 24.04).

LAB 11.1  vtop: virtual address -> page-table indices -> physical frame
  gcc -Wall -O0 -o vtop vtop_starter.c && sudo ./vtop
  TODO 1 split the address into 4 x 9-bit indices + 12-bit offset
  TODO 2 pread the 8-byte entry for the page from /proc/self/pagemap
  TODO 3 decode the bits: 63 present, 62 swapped, 56 "only mine" (exclusively mapped), 0-54 frame number
  TODO 4 physical address = frame * 4096 + offset
  Without root the kernel hides frame numbers (they read as 0). If students have no sudo on the lab PCs,
  build it static (gcc -static) and run it as root inside the QEMU guest from Lab 7.
  Then: add a fork() and look at global_var in parent and child before and after the child writes it.

LAB 11.2  mymalloc: your own malloc on top of sbrk
  gcc -Wall -O0 -o mymalloc mymalloc_starter.c && ./mymalloc
  (gcc warns that "last" is unused until TODO 2: expected. Until TODO 2 is done the program says so and stops.)
  TODO 2 grow: sbrk(header + n), fill in the header, append to the list   (do this one first)
  TODO 1 find_fit: first free block with size >= n
  TODO 3 split: if the block is much bigger than n, cut the rest into a new free block
  TODO 4 free: mark it free; merge with the next block while it is free and adjacent
  Test:  ./mymalloc       strace -e trace=brk ./mymalloc
  The program uses a static stdout buffer on purpose: printf would otherwise call glibc malloc,
  and two allocators would fight over the same program break.

DEMO PROGRAMS (demo/), the ones on the slides:
  cd demo && for f in *.c; do gcc -Wall -O2 -o ${f%.c} $f; done
  then rebuild these two at -O0 (at -O2 gcc removes or changes the very bug we want to see):
    gcc -Wall -O0 -o segv2 segv2.c
    gcc -Wall -O0 -o bugs bugs.c        and with AddressSanitizer:   gcc -O0 -g -fsanitize=address -o bugs_asan bugs.c
  (gcc -Wall warns about bugs.c: use-after-free and overflow. That is the point: read the warnings.)
  11.1: vmphys (sudo for frame numbers)  layout  rss  major  cow  segv2  mmapfile
  11.2: mallocsz (try: strace -e trace=brk,mmap,munmap ./mallocsz)  chunk  bugs double|overflow|uaf
        overcommit: "./overcommit" tries big mallocs; "./overcommit touch 600" touches 600 MiB.
        CAREFUL: touch mode on a lab PC can start the OOM killer. Use a size below free RAM,
        or run it in the QEMU guest (512 MiB), as on the slides.

HOMEWORK (homework/):
  gcc -Wall -O2 -o thp thp.c
  gcc -Wall -O0 -Wno-infinite-recursion -o deep deep.c       (try ulimit -s first; then ulimit -s 16384)
  gcc -Wall -O2 -o usable usable.c      (a -Warray-bounds warning is expected: it reads the chunk header at p[-1] on purpose)
  gcc -Wall -O2 -o threshold threshold.c && strace -e trace=brk,mmap,munmap ./threshold
  thp shows huge pages only if /sys/kernel/mm/transparent_hugepage/enabled is "madvise" or "always".
