/*
 * mymalloc.c - a small malloc and free of our own, on top of sbrk()
 * CSE 4105 System Programming, Lab 11.2   (STARTER: fill in the parts marked TODO)
 *
 * Build:  gcc -Wall -O0 -o mymalloc mymalloc.c
 * Run:    ./mymalloc            then:  strace -e trace=brk ./mymalloc
 *
 * Design: every block starts with a header; all blocks are in one list, in address order.
 *         malloc = first fit (+ split a big free block); free = mark free (+ merge with the next free block).
 */
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>

struct header {
    size_t size;                 /* bytes of user data after this header */
    struct header *next;         /* the next block in the list (= in memory, unless the heap had a gap) */
    int free;                    /* 1 = free, 0 = in use */
};
#define HDR sizeof(struct header)          /* 24 bytes; we round it to 32 to keep data 16-aligned */
#define HDR_ALIGNED 32
#define MIN_SPLIT 32                       /* do not leave free pieces smaller than this */

static struct header *first, *last;

static size_t align16(size_t n) { return (n + 15) & ~(size_t)15; }
static void *data_of(struct header *h) { return (char *)h + HDR_ALIGNED; }
static struct header *header_of(void *p) { return (struct header *)((char *)p - HDR_ALIGNED); }

static struct header *find_fit(size_t n)            /* first fit: the first free block that is big enough */
{
    /* TODO 1: walk the list from "first"; return the first block that is free and has size >= n */
    (void)n;
    return NULL;
}

static struct header *grow(size_t n)                /* ask the kernel for more heap */
{
    /* TODO 2: h = sbrk(HDR_ALIGNED + n): the old program break is the start of the new block.
     *         sbrk returns (void *)-1 on failure. Fill in size, next = NULL, free = 0,
     *         and append the block at the end of the list (update first/last).                  */
    (void)n;
    return NULL;
}

static void split(struct header *h, size_t n)       /* cut the unused end of a big block into a new free block */
{
    /* TODO 3: if the block is big enough (h->size >= n + HDR_ALIGNED + MIN_SPLIT), make a new free block
     *         "rest" that starts right after the first n bytes of data, link it after h, and shrink h.
     *         Draw it on paper first!                                                               */
    (void)h; (void)n;
}

void *my_malloc(size_t n)
{
    if (n == 0) return NULL;
    n = align16(n);
    struct header *h = find_fit(n);
    if (h) {
        h->free = 0;
        split(h, n);
    } else {
        h = grow(n);
        if (!h) return NULL;
    }
    return data_of(h);
}

void my_free(void *p)
{
    if (!p) return;
    struct header *h = header_of(p);
    /* TODO 4: mark h free. Then, while the next block is free AND starts exactly where h's data ends,
     *         merge it into h: h->size grows by HDR_ALIGNED + next->size; unlink next (update last). */
    (void)h;
}

static void dump(const char *title)                  /* print the heap, block by block */
{
    printf("%s\n", title);
    for (struct header *h = first; h; h = h->next)
        printf("   block at %p: data %p, %5zu bytes, %s\n", (void *)h, data_of(h), h->size, h->free ? "FREE" : "used");
    printf("   program break now %p\n", sbrk(0));
}

int main(void)
{
    static char outbuf[4096];
    setvbuf(stdout, outbuf, _IOLBF, sizeof outbuf);  /* a static buffer: printf must not call malloc */

    char *a = my_malloc(100), *b = my_malloc(1000), *c = my_malloc(50);
    if (!a || !b || !c) { printf("my_malloc returned NULL: start with TODO 2 (grow)\n"); return 1; }
    strcpy(a, "A"); strcpy(b, "B"); strcpy(c, "C");
    dump("1. a = 100, b = 1000, c = 50 bytes:");
    my_free(b);
    dump("2. free(b):");
    char *d = my_malloc(200);
    dump("3. d = malloc(200): first fit takes b's place and splits it:");
    my_free(d);
    dump("4. free(d): it merges with the free rest:");
    my_free(a);
    char *e = my_malloc(3000);
    dump("5. free(a); e = malloc(3000): nothing fits, the heap grows:");
    printf("c still holds \"%s\", e is %p\n", c, (void *)e);
    return 0;
}
