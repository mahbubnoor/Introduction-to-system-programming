/* segv2.c - three bad accesses: what does the kernel say about each? */
#define _GNU_SOURCE
#include <setjmp.h>
#include <signal.h>
#include <stdio.h>
#include <string.h>
static sigjmp_buf back;
static volatile void *addr;
static volatile int code;
static void on_segv(int sig, siginfo_t *si, void *ctx)
{
    (void)sig; (void)ctx;
    addr = si->si_addr;                           /* the address that faulted */
    code = si->si_code;                           /* why: not mapped, or not allowed */
    siglongjmp(back, 1);                          /* do not return to the bad instruction */
}
static void try(const char *what, void (*f)(void))
{
    if (sigsetjmp(back, 1) == 0) { f(); printf("%-30s no fault\n", what); return; }
    printf("%-30s SIGSEGV at %p  si_code %d = %s\n", what, (void *)addr, code,
           code == SEGV_MAPERR ? "SEGV_MAPERR (nothing mapped there)" :
           code == SEGV_ACCERR ? "SEGV_ACCERR (mapped, but not allowed)" : "?");
}
static void null_read(void) { volatile int *p = NULL; (void)*p; }
static void far_away(void) { volatile int *p = (int *)0x123456789000; (void)*p; }
static void write_literal(void) { char *s = (char *)"hello"; s[0] = 'J'; }
static void write_code(void) { volatile unsigned char *c = (unsigned char *)try; c[0] = 0x90; }
int main(void)
{
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_sigaction = on_segv;
    sa.sa_flags = SA_SIGINFO;
    sigaction(SIGSEGV, &sa, NULL);
    try("read *NULL", null_read);
    try("read 0x123456789000", far_away);
    try("write into \"hello\" (rodata)", write_literal);
    try("write into the code of try()", write_code);
    return 0;
}
