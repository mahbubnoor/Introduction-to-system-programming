/* cow.c - copy-on-write, counted: who pays for the copy, and when? */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
#define SIZE (100L * 1024 * 1024)
static long minflt(void) { struct rusage u; getrusage(RUSAGE_SELF, &u); return u.ru_minflt; }
static double now(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return t.tv_sec * 1e3 + t.tv_nsec / 1e6; }
int main(void)
{
    char *p = malloc(SIZE);
    memset(p, 1, SIZE);                           /* 25600 pages, all present */
    double t0 = now();
    pid_t pid = fork();
    if (pid == 0) {
        long f0 = minflt();
        double t1 = now();
        volatile long s = 0;
        for (long i = 0; i < SIZE; i += 4096) s += p[i];          /* only read */
        printf("child read 100 MiB:   %6ld page faults  %6.1f ms\n", minflt() - f0, now() - t1);
        f0 = minflt(); t1 = now();
        for (long i = 0; i < SIZE; i += 4096) p[i] = 2;           /* write: copy each page */
        printf("child wrote 100 MiB:  %6ld page faults  %6.1f ms\n", minflt() - f0, now() - t1);
        f0 = minflt(); t1 = now();
        for (long i = 0; i < SIZE; i += 4096) p[i] = 3;           /* write again: already private */
        printf("child wrote it again: %6ld page faults  %6.1f ms\n", minflt() - f0, now() - t1);
        return 0;
    }
    printf("fork took %.2f ms\n", now() - t0);
    fflush(stdout);
    wait(NULL);
    printf("parent still sees p[0] = %d\n", p[0]);
    return 0;
}
