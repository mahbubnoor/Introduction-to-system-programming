/* bugs.c - three classic heap bugs: ./bugs double | overflow | uaf */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(int argc, char *argv[])
{
    const char *what = argc > 1 ? argv[1] : "double";
    if (strcmp(what, "double") == 0) {            /* free the same pointer twice */
        char *p = malloc(32);
        free(p);
        free(p);
    } else if (strcmp(what, "overflow") == 0) {   /* write past the end: into the next chunk's header */
        char *p = malloc(24);
        memset(p, 'A', 24 + 8 + 8);               /* 16 bytes too many */
        char *q = malloc(5000);                   /* malloc now trips over the damage */
        printf("q = %p\n", (void *)q);
    } else {                                      /* use after free */
        char *p = malloc(32);
        strcpy(p, "secret");
        free(p);
        char *q = malloc(32);                     /* gets the same chunk back */
        strcpy(q, "new data");
        printf("p still points to: \"%s\"\n", p);
    }
    printf("%s: the program went on\n", what);
    return 0;
}
