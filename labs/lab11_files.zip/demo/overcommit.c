/* overcommit.c - ask for more memory than the machine has; then (with "touch") really use it */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(int argc, char *argv[])
{
    if (argc > 1 && strcmp(argv[1], "touch") == 0) {      /* really use N MiB, 10 MiB at a time */
        long mb = argc > 2 ? atol(argv[2]) : 600;
        for (long done = 0; done < mb; done += 10) {
            char *p = malloc(10L << 20);
            if (!p) { printf("malloc failed at %ld MiB\n", done); return 1; }
            memset(p, 1, 10L << 20);                       /* now the pages are real */
            if (done % 100 == 0) { printf("touched %ld MiB\n", done); fflush(stdout); }
        }
        printf("touched all %ld MiB\n", mb);
        return 0;
    }
    for (long gb = 1; gb <= 1024; gb *= 2) {               /* only ask, never touch */
        void *p = malloc(gb << 30);
        printf("malloc(%5ld GiB) %s\n", gb, p ? "succeeded" : "FAILED");
        free(p);
        if (!p) break;
    }
    return 0;
}
