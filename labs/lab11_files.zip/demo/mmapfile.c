/* mmapfile.c - a file as an array: count lines with mmap, then change a byte with MAP_SHARED */
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
int main(int argc, char *argv[])
{
    const char *path = argc > 1 ? argv[1] : "/usr/include/stdio.h";
    int fd = open(path, O_RDONLY);
    struct stat st;
    fstat(fd, &st);
    const char *p = mmap(NULL, st.st_size, PROT_READ, MAP_PRIVATE, fd, 0);   /* no read() at all */
    long lines = 0;
    for (off_t i = 0; i < st.st_size; i++)
        if (p[i] == '\n') lines++;                /* the file IS this array */
    printf("%s: %ld bytes, %ld lines, mapped at %p\n", path, (long)st.st_size, lines, (void *)p);
    munmap((void *)p, st.st_size);
    close(fd);

    /* MAP_SHARED: writing to memory writes the file */
    int out = open("/tmp/shared.txt", O_RDWR | O_CREAT | O_TRUNC, 0644);
    if (write(out, "hello, file\n", 12) != 12) return 1;
    char *q = mmap(NULL, 12, PROT_READ | PROT_WRITE, MAP_SHARED, out, 0);
    q[0] = 'J';                                   /* a plain memory store */
    munmap(q, 12);
    close(out);
    return 0;
}
