/* vmphys.c - same virtual address in parent and child: same physical page? */
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
static int x = 1;
static void where(const char *who)
{
    uint64_t e = 0;
    int fd = open("/proc/self/pagemap", O_RDONLY);
    uintptr_t v = (uintptr_t)&x;
    if (pread(fd, &e, 8, (v / 4096) * 8) != 8) e = 0;   /* one 8-byte entry per virtual page */
    close(fd);
    uint64_t pfn = e & ((1ULL << 55) - 1);               /* bits 0-54: the physical frame number */
    printf("%-14s &x = %p  x = %d  present %d  only mine %d  frame 0x%llx\n", who, (void *)&x, x,
           (int)(e >> 63), (int)(e >> 56 & 1), (unsigned long long)pfn);
    fflush(stdout);
}
int main(void)
{
    where("parent");
    if (fork() == 0) {
        where("child, before");
        x = 2;                                    /* the first write: copy-on-write */
        where("child, after");
        return 0;
    }
    wait(NULL);
    where("parent, end");
    return 0;
}
