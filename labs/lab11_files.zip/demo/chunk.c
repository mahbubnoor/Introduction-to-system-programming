/* chunk.c - look at glibc's chunk headers: the 8 bytes just before what malloc returns */
#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>
static void show(const char *name, void *p)
{
    size_t field = ((size_t *)p)[-1];                     /* the size field of this chunk */
    printf("%-6s %p  size field 0x%03zx = chunk %4zu bytes, flags %zu   usable %zu\n",
           name, p, field, field & ~(size_t)7, field & 7, malloc_usable_size(p));
}
int main(void)
{
    char *a = malloc(1), *b = malloc(24), *c = malloc(25), *d = malloc(100);
    show("a(1)", a); show("b(24)", b); show("c(25)", c); show("d(100)", d);
    printf("b - a = %ld, c - b = %ld, d - c = %ld\n", (long)(b - a), (long)(c - b), (long)(d - c));
    free(b);
    char *e = malloc(20);                                 /* same size class as b */
    printf("free(b); malloc(20) = %p  (%s)\n", (void *)e, e == b ? "the same place as b" : "somewhere else");
    char *big = malloc(200000);
    show("big", big);
    return 0;
}
