/* major.c - read a file through mmap: minor faults (in RAM) or major faults (from disk)? */
#define _GNU_SOURCE
#include <fcntl.h>
#include <stdio.h>
#include <sys/mman.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <unistd.h>
static void faults(const char *when, long *mi, long *ma)
{
    struct rusage u;
    getrusage(RUSAGE_SELF, &u);
    if (when) printf("%-34s %6ld minor  %5ld major\n", when, u.ru_minflt - *mi, u.ru_majflt - *ma);
    *mi = u.ru_minflt; *ma = u.ru_majflt;
}
static volatile long sink;
static void touch(const char *p, long n) { long s = 0; for (long i = 0; i < n; i += 4096) s += p[i]; sink = s; }
int main(int argc, char *argv[])
{
    const char *path = argc > 1 ? argv[1] : "/usr/bin/gdb";
    int fd = open(path, O_RDONLY);
    struct stat st;
    fstat(fd, &st);
    long mi, ma;
    printf("%s: %ld bytes = %ld pages\n", path, (long)st.st_size, (long)(st.st_size + 4095) / 4096);
    posix_fadvise(fd, 0, 0, POSIX_FADV_DONTNEED);          /* ask the kernel to drop it from the page cache */
    char *p = mmap(NULL, st.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
    madvise(p, st.st_size, MADV_RANDOM);                    /* no read-ahead: one fault per page */
    faults(NULL, &mi, &ma);
    touch(p, st.st_size);
    faults("first pass (from disk)", &mi, &ma);
    munmap(p, st.st_size);
    p = mmap(NULL, st.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
    madvise(p, st.st_size, MADV_RANDOM);
    faults(NULL, &mi, &ma);
    touch(p, st.st_size);
    faults("second pass (page cache)", &mi, &ma);
    return 0;
}
