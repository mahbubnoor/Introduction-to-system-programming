/* mallocsz.c - which malloc sizes ask the kernel for memory, and how? Run: strace ./mallocsz */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
int main(void)
{
    size_t sizes[] = { 100, 1000, 100000, 200000, 1 << 20 };
    for (int i = 0; i < 5; i++) {
        char msg[64];
        int n = snprintf(msg, sizeof msg, "--- malloc(%zu)\n", sizes[i]);
        if (write(2, msg, n) < 0) return 1;      /* a marker in strace's output */
        void *p = malloc(sizes[i]);
        printf("malloc(%7zu) = %p\n", sizes[i], p);
    }
    return 0;
}
