/* rss.c - malloc 100 MiB: when does it really use memory? */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/resource.h>
#define MB (1024L * 1024)
static void show(const char *when)
{
    char line[256];
    long rss = 0;
    FILE *f = fopen("/proc/self/status", "r");
    while (fgets(line, sizeof line, f))
        if (sscanf(line, "VmRSS: %ld kB", &rss) == 1) break;
    fclose(f);
    struct rusage u;
    getrusage(RUSAGE_SELF, &u);
    printf("%-28s VmRSS %7ld kB   page faults so far: %6ld minor, %ld major\n", when, rss, u.ru_minflt, u.ru_majflt);
    fflush(stdout);
}
int main(void)
{
    show("start");
    char *p = malloc(100 * MB);
    show("after malloc(100 MiB)");
    for (long i = 0; i < 50 * MB; i += 4096) p[i] = 1;   /* touch one byte per page */
    show("after touching 50 MiB");
    for (long i = 50 * MB; i < 100 * MB; i += 4096) p[i] = 1;
    show("after touching 100 MiB");
    for (long i = 0; i < 100 * MB; i += 4096) p[i] = 2;
    show("touching it all again");
    free(p);
    show("after free");
    return 0;
}
