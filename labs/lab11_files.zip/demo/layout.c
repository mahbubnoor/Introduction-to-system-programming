/* layout.c - where does each kind of C variable live? Compare with /proc/self/maps */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int global_init = 42;          /* .data */
int global_zero;               /* .bss  */
const char *text = "hello";    /* the string is in .rodata */
int main(void)
{
    int local = 1;                                /* the stack */
    char *small = malloc(100);                    /* the heap (brk) */
    char *big = malloc(1 << 20);                  /* 1 MiB: its own mmap */
    printf("main (code)     %p\n", (void *)main);
    printf("\"hello\" rodata  %p\n", (void *)text);
    printf("global_init     %p\n", (void *)&global_init);
    printf("global_zero     %p\n", (void *)&global_zero);
    printf("malloc(100)     %p\n", (void *)small);
    printf("malloc(1 MiB)   %p\n", (void *)big);
    printf("printf (libc)   %p\n", (void *)printf);
    printf("local (stack)   %p\n", (void *)&local);
    fflush(stdout);
    char line[512];                               /* now the map, line by line */
    FILE *f = fopen("/proc/self/maps", "r");
    while (fgets(line, sizeof line, f)) {
        char range[64], perms[8], path[256] = "";
        unsigned long off;
        if (sscanf(line, "%63s %7s %lx %*s %*s %255s", range, perms, &off, path) >= 3)
            printf("  %-34s %s  %s\n", range, perms, path);
    }
    fclose(f);
    return 0;
}
