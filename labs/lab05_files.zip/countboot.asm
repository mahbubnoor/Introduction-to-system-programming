. The count program, assembled to run at 80 (hex): the bootstrap loads it there
COUNTB   START   80
FIRST    LDX     #0
LOOP     LDCH    TEXT,X
         COMP    #65
         JEQ     FOUND
NEXT     TIX     #6
         JLT     LOOP
HALT     J       HALT
FOUND    LDA     TOTAL
         ADD     #1
         STA     TOTAL
         J       NEXT
TEXT     BYTE    C'BANANA'
TOTAL    WORD    0
         END     FIRST
