. data.asm: only data, like a C file with global variables
. C:  char text[] = "BANANA"; int len = 6; int total;
DATA     START   0
         EXTDEF  TEXT,LEN,TOTAL
TEXT     BYTE    C'BANANA'
LEN      WORD    6
TOTAL    WORD    0
         END
