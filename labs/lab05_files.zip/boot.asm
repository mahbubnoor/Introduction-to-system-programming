. Bootstrap loader for SIC/XE (our version of the idea in Beck, Section 3.4.4)
. Reads the program as hex characters from device F1, two characters per byte,
. stores the bytes from address 80 (hex) upward, and jumps to 80 at end of input (X'04').
BOOT     START   0
FIRST    CLEAR   A
         LDX     #128          . X = 80 hex: where the first byte goes
LOOP     JSUB    GETC          . A = value of the first hex digit
         RMO     A,S
         SHIFTL  S,4           . S = digit * 16
         JSUB    GETC          . A = value of the second hex digit
         ADDR    S,A           . A = the whole byte
         STCH    0,X           . store it at address X
         TIXR    X,X           . X = X + 1
         J       LOOP
. GETC: read one character, return its hex value in A
GETC     TD      INPUT
         JEQ     GETC          . device busy: wait
         RD      INPUT
         COMP    #4            . end of input?
         JEQ     128           . yes: start the loaded program at 80 hex
         COMP    #48           . below '0'? ignore it (line breaks)
         JLT     GETC
         SUB     #48           . '0'..'9' -> 0..9
         COMP    #10
         JLT     RETURN
         SUB     #7            . 'A'..'F' -> 10..15
RETURN   RSUB
INPUT    BYTE    X'F1'
         END     FIRST
