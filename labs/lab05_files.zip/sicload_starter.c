/*
 * sicload.c - loaders for SIC / SIC-XE object programs (Beck, System Software, Chapter 3)
 * CSE 4105 System Programming, Lab 5   (STARTER: fill in the parts marked TODO)
 *
 * Lab 5.1: TODO 1, TODO 2, TODO 3      Lab 5.2: TODO 4, TODO 5      Extra: TODO 6
 * Until a TODO is done, the program still compiles and runs; the dump just shows xx or wrong bytes.
 *
 * Build:  gcc -Wall -o sicload sicload.c
 *
 * Usage:  ./sicload [-v] [-x] file.obj                  absolute loader: load where the H record says
 *         ./sicload [-v] [-x] -r ADDR file.obj          relocating loader: load at ADDR, apply M records
 *         ./sicload [-v] [-x] -b ADDR file.obj          relocating loader with bit-mask T records (SIC)
 *         ./sicload [-v] -l ADDR a.obj b.obj ...        linking loader: ESTAB in Pass 1, T and M in Pass 2
 *
 *   ADDR is hexadecimal (like PROGADDR).  -v prints every T and M record as it is used.
 *   -x runs the loaded program on a small SIC simulator (plain SIC only) and dumps memory again.
 *
 * Object record formats (columns as in Beck):
 *   H name(6) start(6) length(6)
 *   D name(6) addr(6) name(6) addr(6) ...
 *   R name(6) name(6) ...
 *   T start(6) length(2) bytes...           (with -b: T start(6) length(2) mask(3) bytes...)
 *   M addr(6) halfbytes(2) [+NAME or -NAME]
 *   E [entry(6)]
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MEMSIZE  (1 << 20)          /* SIC/XE has 1 MB of memory */
#define MAXSYM   200
#define MAXSEC   20
#define LINELEN  300

static unsigned char mem[MEMSIZE];
static unsigned char valid[MEMSIZE];  /* 1 = this byte was loaded (the dump prints xx otherwise) */
static int verbose = 0;

/* ---------------- ESTAB: external symbol table of the linking loader ---------------- */
struct sym { char name[8]; int addr; int length; int is_section; };
static struct sym ESTAB[MAXSYM];
static int nsym = 0;

static int estab_find(const char *name)
{
    for (int i = 0; i < nsym; i++)
        if (strcmp(ESTAB[i].name, name) == 0)
            return i;
    return -1;
}

/* ---------------- small helpers ---------------- */
static void die(const char *msg, const char *what)
{
    fflush(stdout);
    fprintf(stderr, "error: %s%s\n", msg, what ? what : "");
    exit(1);
}

/* hex number from n characters of s */
static int hexn(const char *s, int n)
{
    char buf[16];
    memcpy(buf, s, (size_t)n);
    buf[n] = '\0';
    return (int)strtol(buf, NULL, 16);
}

/* a 6-character name field without the blanks at the end */
static void name6(const char *s, char *out)
{
    int n = 0;
    while (n < 6 && s[n] && s[n] != '\n' && s[n] != '\r') { out[n] = s[n]; n++; }
    out[n] = '\0';
    while (n > 0 && out[n - 1] == ' ') out[--n] = '\0';
}

static void store(int addr, int byte)
{
    if (addr < 0 || addr >= MEMSIZE) die("address outside memory", NULL);
    mem[addr] = (unsigned char)byte;
    valid[addr] = 1;
}

/* read a whole object file: one record per line */
static int read_records(const char *file, char rec[][LINELEN], int max)
{
    FILE *f = fopen(file, "r");
    if (!f) { perror(file); exit(1); }
    int n = 0;
    char line[LINELEN];
    while (n < max && fgets(line, sizeof line, f)) {
        line[strcspn(line, "\r\n")] = '\0';
        if (line[0]) strcpy(rec[n++], line);
    }
    fclose(f);
    return n;
}

/* load one T record; delta is added to its start address */
static void load_T(const char *r, int delta)
{
    int start = hexn(r + 1, 6) + delta;
    int len = hexn(r + 7, 2);
    /* TODO 1 (Lab 5.1): copy the len bytes of the record into memory.
     *   The bytes start at column 9 of the record (r + 9), two hex characters per byte.
     *   Byte i goes to address start + i.  Use store(address, value) and hexn(text, 2).   */

    if (verbose)
        printf("  %-12s %d bytes at %06X\n", "T record:", len, start);
}

/*
 * Add delta to the field of `half` half-bytes at address addr.
 * Odd number of half-bytes (05 for format 4): the field starts in the middle of the first byte,
 * so the left half of that byte (the x b p e flags) must not change.
 */
static void patch(int addr, int half, int delta)
{
    /* TODO 2 (Lab 5.1):
     *   1. nbytes = (half + 1) / 2  (05 half-bytes -> 3 bytes, 04 -> 2, 06 -> 3)
     *   2. read those bytes from mem[addr] ... into one number v (big-endian: first byte is highest)
     *   3. mask = (1L << (4 * half)) - 1         the bits that belong to the field
     *   4. new field = (v + delta) & mask;  keep the other bits:  v = (v & ~mask) | field
     *   5. write v back, lowest byte at addr + nbytes - 1, with store()
     *   Check by hand: half = 5, bytes 10 00 00, delta 4011  ->  10 40 11                         */
    (void)addr; (void)half; (void)delta;
}

static void show_field(int addr, int half)
{
    for (int i = 0; i < (half + 1) / 2; i++)
        printf("%02X", mem[addr + i]);
}

/* ---------------- memory dump: 16 bytes per line, 4 groups of 4 ---------------- */
static void dump(int start, int end)
{
    for (int a = start - start % 16; a < end; a += 16) {
        printf("%06X ", a);
        for (int k = 0; k < 16; k++) {
            if (k % 4 == 0) printf(" ");
            int b = a + k;
            if (b >= start && b < end && valid[b]) printf("%02X", mem[b]);
            else printf("xx");
        }
        printf("\n");
    }
}

/* ======================= 1. absolute and relocating loader ======================= */
/* progaddr < 0: absolute load.  mode 'm': use M records.  mode 'b': bit-mask T records. */
static void load_one(const char *file, int progaddr, char mode, int *first, int *last, int *entry)
{
    static char rec[2000][LINELEN];
    int n = read_records(file, rec, 2000);
    if (n == 0 || rec[0][0] != 'H') die("no H record in ", file);

    char name[8];
    name6(rec[0] + 1, name);
    int start = hexn(rec[0] + 7, 6), length = hexn(rec[0] + 13, 6);
    int delta = progaddr < 0 ? 0 : progaddr - start;
    printf("Program %s: assembled at %06X, length %06X, loaded at %06X\n", name, start, length, start + delta);

    for (int i = 1; i < n; i++) {
        const char *r = rec[i];
        if (r[0] == 'T' && mode == 'b') {
            int a = hexn(r + 1, 6) + delta, len = hexn(r + 7, 2), mask = hexn(r + 9, 3);
            /* TODO 6 (extra): load the bytes (they start at column 12, after the 3-character mask),
             *   then for every 3-byte word w = 0, 1, ...: if bit (11 - w) of mask is 1,
             *   add delta to that whole word: patch(a + 3 * w, 6, delta).                          */
            if (verbose) {
                printf("  %-12s %d bytes at %06X, mask ", "T record:", len, a);
                for (int bit = 11; bit >= 0; bit--) putchar(mask & (1 << bit) ? '1' : '0');
                printf("\n");
            }
        } else if (r[0] == 'T') {
            load_T(r, delta);
        } else if (r[0] == 'M' && mode == 'm' && progaddr >= 0) {
            int a = hexn(r + 1, 6) + delta, half = hexn(r + 7, 2);
            if (verbose) { printf("  M record:    at %06X  ", a); show_field(a, half); printf(" -> "); }
            /* TODO 3 (Lab 5.1): one line. Add delta (load address - assembled address) to the field. */

            if (verbose) { show_field(a, half); printf("\n"); }
        } else if (r[0] == 'E') {
            *entry = strlen(r) > 1 ? hexn(r + 1, 6) + delta : start + delta;
        }
    }
    *first = start + delta;
    *last = start + delta + length;
}

/* ======================= 2. linking loader ======================= */
static void link_load(int nfiles, char *files[], int progaddr, int *first, int *last, int *entry)
{
    static char rec[MAXSEC][2000][LINELEN];
    int nrec[MAXSEC];
    if (nfiles > MAXSEC) die("too many object files", NULL);
    for (int f = 0; f < nfiles; f++)
        nrec[f] = read_records(files[f], rec[f], 2000);

    /* ---------- Pass 1: give every control section an address; build ESTAB ---------- */
    int csaddr = progaddr;
    int cslth = 0;
    for (int f = 0; f < nfiles; f++) {
        for (int i = 0; i < nrec[f]; i++) {
            const char *r = rec[f][i];
            char name[8];
            if (r[0] == 'H') {
                /* TODO 4a (Lab 5.2): a new control section.
                 *   csaddr += cslth;  (it starts right after the previous one)
                 *   read its name (name6(r + 1, name)) and length (hexn(r + 13, 6)) into cslth;
                 *   if the name is already in ESTAB: die("duplicate external symbol ", name);
                 *   add it to ESTAB with addr = csaddr, length = cslth, is_section = 1.         */
                (void)name;
            } else if (r[0] == 'D') {
                /* TODO 4b (Lab 5.2): every 12 characters after the 'D' hold one symbol:
                 *   6 for the name, 6 for its address inside the section (hex).
                 *   Add each one to ESTAB with addr = csaddr + that address, is_section = 0.
                 *   Check for duplicates in the same way.                                      */
            }
        }
    }
    int total = csaddr + cslth - progaddr;

    printf("Load map (ESTAB)\n");
    printf("%-9s %-8s %-8s %s\n", "Section", "Symbol", "Address", "Length");
    for (int i = 0; i < nsym; i++) {
        if (ESTAB[i].is_section)
            printf("%-9s %-8s %06X   %06X\n", ESTAB[i].name, "", ESTAB[i].addr, ESTAB[i].length);
        else
            printf("%-9s %-8s %06X\n", "", ESTAB[i].name, ESTAB[i].addr);
    }

    /* ---------- Pass 2: load T records, apply M records with ESTAB ---------- */
    *entry = progaddr;
    csaddr = progaddr;
    for (int f = 0; f < nfiles; f++) {
        for (int i = 0; i < nrec[f]; i++) {
            const char *r = rec[f][i];
            char name[8];
            if (r[0] == 'H') {
                name6(r + 1, name);
                int s = estab_find(name);
                if (s < 0) die("control section not in ESTAB (is Pass 1 done?): ", name);
                csaddr = ESTAB[s].addr;
                if (verbose) printf("Section %s at %06X\n", name, csaddr);
            } else if (r[0] == 'T') {
                load_T(r, csaddr);
            } else if (r[0] == 'M') {
                int a = csaddr + hexn(r + 1, 6), half = hexn(r + 7, 2);
                int value = csaddr;                     /* no symbol: relative to this section */
                /* TODO 5 (Lab 5.2): if the record has a symbol (strlen(r) > 9):
                 *   r[9] is '+' or '-', the name starts at r + 10.
                 *   Look it up in ESTAB; if it is missing: die("undefined external symbol ", name);
                 *   value = + or - its address.                                                */
                if (verbose) { printf("  M record:    at %06X  ", a); show_field(a, half); printf(" -> "); }
                patch(a, half, value);
                if (verbose) { show_field(a, half); printf("  (%s)\n", strlen(r) > 9 ? r + 9 : "section address"); }
            } else if (r[0] == 'E' && strlen(r) > 1) {
                *entry = csaddr + hexn(r + 1, 6);       /* the main program gives the entry point */
            }
        }
    }
    *first = progaddr;
    *last = progaddr + total;
}

/* ======================= 3. a small SIC simulator for -x ======================= */
static int word(int a) { return (mem[a] << 16) | (mem[a + 1] << 8) | mem[a + 2]; }
static void setword(int a, int v) { store(a, (v >> 16) & 0xFF); store(a + 1, (v >> 8) & 0xFF); store(a + 2, v & 0xFF); }
static int sgn(int v) { v &= 0xFFFFFF; return v & 0x800000 ? v - 0x1000000 : v; }

static void run_sic(int entry)
{
    int A = 0, X = 0, L = 0, PC = entry, cc = 0, steps = 0;
    for (;;) {
        if (++steps > 1000000) die("program did not stop", NULL);
        int w = word(PC), op = w >> 16, x = (w >> 15) & 1, ta = (w & 0x7FFF) + (x ? X : 0);
        int pc = PC;
        PC += 3;
        switch (op) {
        case 0x00: A = word(ta); break;                                  /* LDA  */
        case 0x04: X = word(ta); break;                                  /* LDX  */
        case 0x08: L = word(ta); break;                                  /* LDL  */
        case 0x0C: setword(ta, A); break;                                /* STA  */
        case 0x10: setword(ta, X); break;                                /* STX  */
        case 0x14: setword(ta, L); break;                                /* STL  */
        case 0x18: A = (A + word(ta)) & 0xFFFFFF; break;                 /* ADD  */
        case 0x1C: A = (A - word(ta)) & 0xFFFFFF; break;                 /* SUB  */
        case 0x20: A = (sgn(A) * sgn(word(ta))) & 0xFFFFFF; break;       /* MUL  */
        case 0x24: A = (sgn(A) / sgn(word(ta))) & 0xFFFFFF; break;       /* DIV  */
        case 0x28: cc = sgn(A) < sgn(word(ta)) ? -1 : sgn(A) > sgn(word(ta)); break;   /* COMP */
        case 0x2C: X = (X + 1) & 0xFFFFFF;                               /* TIX  */
                   cc = sgn(X) < sgn(word(ta)) ? -1 : sgn(X) > sgn(word(ta)); break;
        case 0x30: if (cc == 0) PC = ta; break;                          /* JEQ  */
        case 0x34: if (cc > 0) PC = ta; break;                           /* JGT  */
        case 0x38: if (cc < 0) PC = ta; break;                           /* JLT  */
        case 0x3C: if (ta == pc) {                                       /* J to itself: the program is done */
                       printf("Ran %d instructions, stopped at %06X: A=%06X X=%06X L=%06X\n", steps, pc, A, X, L);
                       return;
                   }
                   PC = ta; break;
        case 0x48: L = PC; PC = ta; break;                               /* JSUB */
        case 0x4C: PC = L; break;                                        /* RSUB */
        case 0x50: A = (A & 0xFFFF00) | mem[ta]; break;                  /* LDCH */
        case 0x54: store(ta, A & 0xFF); break;                           /* STCH */
        default:
            fprintf(stderr, "error: opcode %02X at %06X is not a SIC instruction this simulator knows\n", op, pc);
            exit(1);
        }
    }
}

int main(int argc, char *argv[])
{
    int progaddr = -1, run = 0, i = 1;
    char mode = 'a';
    while (i < argc && argv[i][0] == '-') {
        if (strcmp(argv[i], "-v") == 0) verbose = 1;
        else if (strcmp(argv[i], "-x") == 0) run = 1;
        else if ((strcmp(argv[i], "-r") == 0 || strcmp(argv[i], "-l") == 0 || strcmp(argv[i], "-b") == 0) && i + 1 < argc) {
            mode = argv[i][1] == 'r' ? 'm' : argv[i][1];
            progaddr = (int)strtol(argv[++i], NULL, 16);
        } else break;
        i++;
    }
    if (i >= argc) {
        fprintf(stderr, "usage: %s [-v] [-x] [-r ADDR | -b ADDR] file.obj\n"
                        "       %s [-v] -l ADDR file1.obj file2.obj ...\n", argv[0], argv[0]);
        return 1;
    }

    int first, last, entry = -1;
    if (mode == 'l') {
        link_load(argc - i, argv + i, progaddr, &first, &last, &entry);
    } else {
        if (argc - i != 1) die("give one object file (use -l to link several)", NULL);
        load_one(argv[i], progaddr, mode, &first, &last, &entry);
    }
    if (entry < 0) entry = first;
    printf("Entry point %06X\n", entry);
    printf("Memory after loading:\n");
    dump(first, last);
    if (run) {
        run_sic(entry);
        printf("Memory after running:\n");
        dump(first, last);
    }
    return 0;
}
