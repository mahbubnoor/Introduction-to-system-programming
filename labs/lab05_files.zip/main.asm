. main.asm: calls COUNTA and stores the result in TOTAL, which lives in another file
. C:  extern int total; int counta(void);   total = counta();
MAIN     START   0
         EXTREF  COUNTA,TOTAL,TEXT
FIRST    +JSUB   COUNTA        . call a routine in another control section
         +STA    TOTAL         . total = A
HALT     J       HALT
PTR      WORD    TEXT          . like  char *ptr = text;
DIST     WORD    TOTAL-TEXT    . distance between two external symbols
         END     FIRST
