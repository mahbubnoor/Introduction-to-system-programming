CSE 4105 System Programming - Lab 5 (Lectures 5.1 and 5.2): Loaders and linking
==============================================================================
Works offline on the lab PCs (Linux). Needs: gcc, binutils (nm, readelf, objdump, ar),
gdb, strace, nasm. Check with:  which gcc gdb strace nasm

PART 1  The loader in C   (sicload_starter.c)
  gcc -Wall -o sicload sicload_starter.c
  Lab 5.1: TODO 1 (load a T record), TODO 2 (patch a field), TODO 3 (apply M records)
     ./sicload count.obj                     | diff - expected_abs.txt
     ./sicload -v -x -r 5000 count0.obj      | diff - expected_reloc5000.txt
     (-x runs a plain SIC program after loading; TOTAL must become 000003)
  Lab 5.2: TODO 4 (Pass 1: ESTAB), TODO 5 (Pass 2: M records with +/- symbols)
     ./sicload -v -l 4000 main.obj counta.obj data.obj | diff - expected_link4000.txt
     ./sicload -l 4000 main.obj counta.obj            -> error: undefined external symbol TOTAL
     ./sicload -l 4000 main.obj counta.obj data.obj data.obj -> error: duplicate external symbol DATA
  Extra: TODO 6 (bit-mask records)
     ./sicload -v -x -b 5000 count0_mask.obj | diff - expected_mask5000.txt

Object files:  count.obj (START 2000, absolute), count0.obj (START 0, M records),
               count0_mask.obj (bit masks), main/counta/data.obj (SIC/XE control sections),
               boot.obj (the bootstrap loader), countboot.obj (START 80, booted by boot.asm).
               The .asm sources are included. hw51.asm is for homework 5.1.

PART 2  Linux demos   (folder demo/)
  cd demo && ./run_all.sh > my_output.txt 2>&1
  Compare with run_all_output.txt (our run on Ubuntu 24.04, gcc 13.3, glibc 2.39).
  Addresses starting with 0x55... or 0x7f... change on every run (ASLR); that is expected.
  got.gdb reads the GOT slot at 0x404000; if your gcc lays the file out differently,
  find the slot with:  readelf -r lazy   (the R_X86_64_JUMP_SLOT line for counta)
  and change the address in got.gdb.
  boot.s builds a real 512-byte x86 boot sector (ends in 55 aa); we only inspect it.
