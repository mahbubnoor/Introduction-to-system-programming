. counta.asm: count the letters 'A' in TEXT (length LEN); return the count in A
. C:  extern char text[]; extern int len;   int counta(void) { ... }
COUNTA   START   0
         EXTREF  TEXT,LEN
         CLEAR   X             . X = index
         CLEAR   S             . S = count
         +LDT    LEN           . T = length (LEN is in another file)
LOOP     CLEAR   A
         +LDCH   TEXT,X        . A = text[X]
         COMP    #65           . 'A' ?
         JEQ     HIT
NEXT     TIXR    T             . X = X + 1, compare X with T
         JLT     LOOP
         RMO     S,A           . return value in A
         RSUB
HIT      RMO     S,A
         ADD     #1
         RMO     A,S           . count = count + 1
         J       NEXT
         END
