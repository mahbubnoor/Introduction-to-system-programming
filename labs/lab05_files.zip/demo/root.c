/* root.c - needs the math library: link with -lm */
#include <stdio.h>
#include <math.h>
int main(int argc, char *argv[])
{
    double x = argc + 1.0;          /* a value the compiler cannot know in advance */
    printf("sqrt(%.0f) = %f\n", x, sqrt(x));
    return 0;
}
