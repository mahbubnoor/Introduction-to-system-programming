/* where.c - where did the loader put things? Run it twice. */
#include <stdio.h>
#include <stdlib.h>
int global = 7;                       /* .data  */
int main(void)
{
    int local = 1;                    /* stack  */
    int *heap = malloc(sizeof *heap); /* heap   */
    printf("main   %p\nglobal %p\nprintf %p\nlocal  %p\nheap   %p\n",
           (void *) main, (void *) &global, (void *) printf, (void *) &local, (void *) heap);
    free(heap);
    return 0;
}
