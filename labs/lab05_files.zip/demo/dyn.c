/* dyn.c - load a library while the program is running: dlopen / dlsym / dlclose */
#include <stdio.h>
#include <dlfcn.h>
int main(int argc, char *argv[])
{
    const char *lib = argc > 1 ? argv[1] : "./libcount.so";
    void *h = dlopen(lib, RTLD_NOW);            /* load the file, link it now */
    if (!h) { printf("dlopen failed: %s\n", dlerror()); return 1; }
    int (*f)(void) = (int (*)(void)) dlsym(h, "counta");   /* look up a name */
    int *t = (int *) dlsym(h, "total");
    if (!f || !t) { printf("dlsym failed: %s\n", dlerror()); return 1; }
    printf("counta is at %p, total is at %p\n", (void *) f, (void *) t);
    *t = f();
    printf("total = %d\n", *t);
    dlclose(h);
    return 0;
}
