/* data.c - only global variables (like EXTDEF TEXT,LEN,TOTAL) */
char text[] = "BANANA";
int len = 6;
int total;                 /* no initial value: goes to .bss */
