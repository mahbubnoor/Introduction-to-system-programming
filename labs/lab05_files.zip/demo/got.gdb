set pagination off
set disable-randomization on
break 6
break 7
break 8
run
printf "before 1st call: GOT[counta] at 0x404000 = %#lx\n", *(long*)0x404000
info symbol *(long*)0x404000
continue
printf "after 1st call : GOT[counta] at 0x404000 = %#lx\n", *(long*)0x404000
info symbol *(long*)0x404000
p &counta
continue
printf "after 2nd call : GOT[counta] at 0x404000 = %#lx\n", *(long*)0x404000
info sharedlibrary
continue
