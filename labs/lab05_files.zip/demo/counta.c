/* counta.c - count the letters 'A' in text */
extern char text[];        /* like EXTREF TEXT,LEN */
extern int len;

int counta(void)
{
    int count = 0;
    for (int i = 0; i < len; i++)
        if (text[i] == 'A')
            count++;
    return count;
}
