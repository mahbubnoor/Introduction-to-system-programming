#!/bin/bash
# Lecture 5 demos: run in this folder on the lab PC (gcc, binutils, gdb, nasm, strace). No internet needed.
set -x
gcc -c main.c counta.c data.c
nm main.o; nm counta.o; nm data.o                       # U = needs (EXTREF), T/D/B = defines (EXTDEF)
readelf -rW main.o                                      # relocations = M records
objdump -d main.o | sed -n '/<main>/,/^$/p'              # call e8 00 00 00 00: address still unknown
gcc -no-pie -o count main.o counta.o data.o && ./count
objdump -d count | sed -n '/<main>:/,/ret/p' | head -6   # now the call has a real address
gcc -no-pie -o count_map main.o counta.o data.o -Wl,-Map=count.map   # the load map
gcc -no-pie -o x main.o counta.o                        # error: undefined reference
ar rcs libcount.a counta.o data.o && ar t libcount.a
gcc -no-pie -o count_lib main.o -L. -lcount && ./count_lib
gcc -no-pie -o x -L. -lcount main.o                      # error: order matters for .a
gcc -fPIC -c counta.c -o counta_pic.o && gcc -fPIC -c data.c -o data_pic.o
gcc -shared -o libcount.so counta_pic.o data_pic.o
gcc -o count_so main.o -L. -lcount
./count_so                                               # error: cannot open shared object file
LD_LIBRARY_PATH=. ./count_so
LD_LIBRARY_PATH=. ldd ./count_so
LD_DEBUG=libs LD_LIBRARY_PATH=. ./count_so
LD_DEBUG=bindings LD_LIBRARY_PATH=. ./count_so
gcc -o count_rp main.o -L. -lcount -Wl,-rpath,'$ORIGIN' && ./count_rp
gcc -no-pie -static -o count_static main.c counta.c data.c
gcc -no-pie -o count_dyn main.c counta.c data.c
ls -l count_static count_dyn; size count_static count_dyn
readelf -lW count_dyn                                   # LOAD segments, INTERP, entry point
gcc -o root root.c                                       # error: undefined reference to sqrt
gcc -o root root.c -lm && ./root
gcc -o dyn dyn.c && ./dyn
gcc -o where where.c && ./where && ./where               # PIE + ASLR: only the base changes
gcc -g -O0 -no-pie -fno-pie -Wl,-z,lazy -o lazy lazy.c -L. -lcount -Wl,-rpath,'$ORIGIN'
gdb -q -batch -x got.gdb ./lazy                          # GOT before and after the first call
nasm -f bin boot.s -o boot.bin && od -A x -t x1z boot.bin | tail -3
