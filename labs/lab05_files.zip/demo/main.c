/* main.c - the same program as main.asm / counta.asm / data.asm, in C */
#include <stdio.h>
extern int total;          /* defined in data.c   (like EXTREF TOTAL) */
int counta(void);          /* defined in counta.c (like EXTREF COUNTA) */

int main(void)
{
    total = counta();
    printf("total = %d\n", total);
    return 0;
}
