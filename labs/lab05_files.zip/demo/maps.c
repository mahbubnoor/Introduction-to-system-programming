#include <stdio.h>
int main(void) { FILE *f = fopen("/proc/self/maps", "r"); char s[512]; while (fgets(s, sizeof s, f)) fputs(s, stdout); return 0; }
