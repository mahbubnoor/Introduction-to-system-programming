/* lazy.c - call a shared-library function twice and watch its GOT entry change */
#include <stdio.h>
int counta(void);
int main(void)
{
    int a = counta();      /* first call: goes through the dynamic linker */
    int b = counta();      /* second call: goes straight to counta */
    printf("%d %d\n", a, b);
    return 0;
}
