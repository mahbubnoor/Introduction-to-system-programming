; boot.s - a 512-byte x86 boot sector: BIOS loads it at 0x7C00 and jumps to it
        org  0x7C00
        bits 16
start:  mov  si, msg
.next:  lodsb               ; al = next character
        or   al, al
        jz   .halt
        mov  ah, 0x0E       ; BIOS: print character
        int  0x10
        jmp  .next
.halt:  hlt
        jmp  .halt
msg:    db   "Hello from the boot sector", 0
        times 510-($-$$) db 0
        dw   0xAA55         ; the boot signature: bytes 55 AA at offset 510
