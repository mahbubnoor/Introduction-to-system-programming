HW       START   0
FIRST    LDA     ZERO
         STA     TOTAL
         RSUB
ZERO     WORD    0
TOTAL    WORD    0
PTR      WORD    TOTAL
         END     FIRST
