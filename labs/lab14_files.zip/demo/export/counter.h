/* counter.h - the interface of counter.ko, shared with the modules that use it (like any C header) */
#ifndef SYSPROG_COUNTER_H
#define SYSPROG_COUNTER_H
int sysprog_next(void);
#endif
