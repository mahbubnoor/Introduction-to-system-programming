// SPDX-License-Identifier: GPL-2.0
/* user.c - a module that USES a symbol exported by counter.ko */
#include <linux/module.h>
#include "counter.h"

/* sysprog_next() is declared in counter.h and defined in counter.ko */

static int __init user_init(void)
{
    pr_info("user: sysprog_next() = %d, %d, %d\n", sysprog_next(), sysprog_next(), sysprog_next());
    return 0;
}
static void __exit user_exit(void) { pr_info("user: bye\n"); }
module_init(user_init);
module_exit(user_exit);
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Lecture 14.1: uses counter.ko");
