// SPDX-License-Identifier: GPL-2.0
/* counter.c - a module that EXPORTS a function for other modules */
#include <linux/atomic.h>
#include <linux/module.h>
#include "counter.h"

static atomic_t value = ATOMIC_INIT(0);

int sysprog_next(void)
{
    return atomic_inc_return(&value);
}
EXPORT_SYMBOL_GPL(sysprog_next);           /* now other GPL modules can call it */

static int __init counter_init(void) { pr_info("counter: ready\n"); return 0; }
static void __exit counter_exit(void) { pr_info("counter: gone after %d calls\n", atomic_read(&value)); }
module_init(counter_init);
module_exit(counter_exit);
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Lecture 14.1: an exported symbol");
