// SPDX-License-Identifier: GPL-2.0
/* hello.c - the smallest useful kernel module: a message when it is loaded and when it is removed */
#include <linux/init.h>
#include <linux/module.h>
#include <linux/printk.h>

static int __init hello_init(void)
{
    pr_info("hello: loaded into the kernel, HZ = %d\n", HZ);
    return 0;                          /* 0 = success; a negative errno makes insmod fail */
}

static void __exit hello_exit(void)
{
    pr_info("hello: removed\n");
}

module_init(hello_init);
module_exit(hello_exit);
MODULE_LICENSE("GPL");
MODULE_AUTHOR("CSE 4105, University of Barishal");
MODULE_DESCRIPTION("Lecture 14.1: hello, kernel");
