// SPDX-License-Identifier: GPL-2.0
/* hello_param.c - module parameters: values given at insmod time, visible in /sys/module/NAME/parameters */
#include <linux/module.h>
#include <linux/moduleparam.h>

static char *who = "world";
static int times = 1;
module_param(who, charp, 0644);            /* 0644: root may change it later through sysfs */
MODULE_PARM_DESC(who, "whom to greet");
module_param(times, int, 0444);            /* 0444: read-only in sysfs */
MODULE_PARM_DESC(times, "how many greetings");

static int __init hp_init(void)
{
    int i;
    if (times < 1 || times > 5) {
        pr_err("hello_param: times must be 1..5, got %d\n", times);
        return -EINVAL;                    /* insmod fails with "Invalid argument" */
    }
    for (i = 0; i < times; i++)
        pr_info("hello_param: hello, %s (%d of %d)\n", who, i + 1, times);
    return 0;
}
static void __exit hp_exit(void)
{
    pr_info("hello_param: goodbye, %s\n", who);
}
module_init(hp_init);
module_exit(hp_exit);
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Lecture 14.1: module parameters");
