// SPDX-License-Identifier: GPL-2.0
/* oops.c - a bug in kernel code: dereference NULL. RUN THIS ONLY IN THE VIRTUAL MACHINE. */
#include <linux/module.h>

struct thing { int a, b; };
static struct thing *find_thing(void) { return NULL; }   /* "forgot" to check the result */

static int __init oops_init(void)
{
    struct thing *t = find_thing();
    pr_info("oops: about to read t->b\n");
    pr_info("oops: t->b = %d\n", t->b);                   /* NULL + 4: page fault in kernel mode */
    return 0;
}
module_init(oops_init);
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Lecture 14.1: a kernel oops on purpose");
