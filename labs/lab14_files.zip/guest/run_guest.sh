#!/bin/sh
# run_guest.sh - boot the lab PC's own kernel in QEMU with busybox and your .ko files, and give you a root shell.
#   ./run_guest.sh DIR...      every *.ko found in the DIRs is copied to /mod in the guest
# KERNEL: a readable copy of this PC's kernel (once, by the instructor or with sudo):
#   sudo cp /boot/vmlinuz-$(uname -r) guest/vmlinuz && sudo chmod a+r guest/vmlinuz   (next to this script)
# Leave the guest with:  poweroff -f      (or Ctrl-A then X)
set -e
HERE=$(cd "$(dirname "$0")" && pwd)
KERNEL=${KERNEL:-$HERE/vmlinuz}
BB=${BUSYBOX:-$HERE/busybox}
[ -r "$KERNEL" ] || { echo "no readable kernel at $KERNEL (see the comment at the top)"; exit 1; }
R=$(mktemp -d)
chmod 755 $R; mkdir -p $R/bin $R/proc $R/sys $R/dev $R/tmp $R/mod
cp "$BB" $R/bin/busybox
for a in $($R/bin/busybox --list); do [ "$a" = busybox ] || ln -sf busybox $R/bin/$a; done
for d in "$@"; do find "$d" -name '*.ko' -exec cp {} $R/mod/ \; ; done
cat > $R/init <<'EOI'
#!/bin/sh
mount -t proc proc /proc
mount -t sysfs sysfs /sys
mount -t devtmpfs devtmpfs /dev
export PATH=/bin
cd /mod
echo; echo "guest $(uname -r): your modules are in /mod:"; ls /mod; echo "(poweroff -f to leave)"
exec setsid cttyhack sh
EOI
chmod +x $R/init
(cd $R && find . | cpio -o -H newc 2>/dev/null | gzip > "$HERE/guest.cpio.gz")
rm -rf $R
exec qemu-system-x86_64 -m 512 -nographic -no-reboot -kernel "$KERNEL" -initrd "$HERE/guest.cpio.gz" \
     -append "console=ttyS0 quiet panic=-1"
