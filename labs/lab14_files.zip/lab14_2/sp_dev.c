// SPDX-License-Identifier: GPL-2.0
/* sp_dev.c - register a DEVICE called "sysprog" on the platform bus (no driver yet) */
#include <linux/module.h>
#include <linux/platform_device.h>

static struct platform_device *pdev;

static int __init sp_dev_init(void)
{
    pdev = platform_device_register_simple("sysprog", 0, NULL, 0);   /* name "sysprog", id 0: sysprog.0 */
    if (IS_ERR(pdev))
        return PTR_ERR(pdev);
    pr_info("sp_dev: device %s registered\n", dev_name(&pdev->dev));
    return 0;
}
static void __exit sp_dev_exit(void)
{
    platform_device_unregister(pdev);
    pr_info("sp_dev: device unregistered\n");
}
module_init(sp_dev_init);
module_exit(sp_dev_exit);
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Lecture 14.2: a platform device");
