// SPDX-License-Identifier: GPL-2.0
/*
 * sp_drv.c - a platform DRIVER for devices named "sysprog", with a sysfs file "value"
 * CSE 4105 System Programming, Lab 14.2   (STARTER: fill in the parts marked TODO)
 *
 * In the QEMU guest:  insmod sp_drv.ko ; insmod sp_dev.ko      (either order: the bus matches them)
 *                     cat /sys/devices/platform/sysprog.0/value ; echo 42 > /sys/devices/platform/sysprog.0/value
 */
#include <linux/device.h>
#include <linux/module.h>
#include <linux/mutex.h>
#include <linux/platform_device.h>
#include <linux/version.h>

struct sysprog_state {                         /* one per bound device */
    struct mutex lock;
    int value;
    int writes;
};

/* sysfs: cat .../value  ->  value_show */
static ssize_t value_show(struct device *dev, struct device_attribute *attr, char *buf)
{
    /* TODO 1: get our state with dev_get_drvdata(dev), read st->value under st->lock,
     *         and return sysfs_emit(buf, "%d\n", value).                                   */
    return sysfs_emit(buf, "TODO 1\n");
}

/* sysfs: echo 42 > .../value  ->  value_store */
static ssize_t value_store(struct device *dev, struct device_attribute *attr, const char *buf, size_t count)
{
    /* TODO 2: convert buf to an int with kstrtoint(buf, 10, &v); on error return that error.
     *         Then, under st->lock, set st->value = v and st->writes++. Print it with dev_info.
     *         Return count: "all bytes used".                                                 */
    return -EINVAL;
}
static DEVICE_ATTR_RW(value);                  /* makes dev_attr_value with value_show / value_store */

static struct attribute *sysprog_attrs[] = { &dev_attr_value.attr, NULL };
ATTRIBUTE_GROUPS(sysprog);                     /* makes sysprog_groups */

static int sysprog_probe(struct platform_device *pdev)
{
    /* TODO 3: allocate our state with devm_kzalloc(&pdev->dev, sizeof(*st), GFP_KERNEL) (NULL: return -ENOMEM),
     *         mutex_init(&st->lock), st->value = 7, and platform_set_drvdata(pdev, st).
     *         Without set_drvdata, value_show gets NULL from dev_get_drvdata: an oops (Lecture 14.1). */
    dev_info(&pdev->dev, "probe: called, but nothing is set up yet: TODO 3\n");
    return 0;
}

static void sysprog_remove(struct platform_device *pdev)
{
    struct sysprog_state *st = platform_get_drvdata(pdev);
    if (st)                                    /* NULL until TODO 3 is done */
        dev_info(&pdev->dev, "remove: last value %d after %d writes\n", st->value, st->writes);
}

static struct platform_driver sysprog_driver = {
    .probe = sysprog_probe,
#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 11, 0)
    .remove = sysprog_remove,                  /* 6.11 and newer: remove returns void */
#else
    .remove_new = sysprog_remove,              /* 6.8 (Ubuntu 24.04): the void version is called remove_new */
#endif
    .driver = {
        .name = "sysprog-TODO",                /* TODO 4: the bus matches drivers and devices by NAME:
                                                  use the device's name "sysprog" (see sp_dev.c) */
        .dev_groups = sysprog_groups,          /* sysfs files created at bind time */
    },
};
module_platform_driver(sysprog_driver);        /* module_init/exit that (un)register the driver */

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Lecture 14.2 lab: a platform driver with a sysfs attribute");
