CSE 4105 System Programming - Lab 14 (Lectures 14.1 and 14.2): kernel modules and the device driver model
=========================================================================================================
Works offline. Needs: gcc, make, the kernel headers of this PC (/lib/modules/$(uname -r)/build must exist;
Ubuntu installs them with the kernel: package linux-headers-$(uname -r)), and qemu-system-x86_64.

RULE: build on the PC, LOAD ONLY IN THE VIRTUAL MACHINE. A bug in a module is a bug in the kernel.

ONCE PER PC (needs sudo, or the instructor does it): a readable copy of this PC's kernel for the VM
  sudo cp /boot/vmlinuz-$(uname -r) guest/vmlinuz && sudo chmod a+r guest/vmlinuz

HOW TO TEST ANY MODULE
  cd demo/hello && make                      (makes hello.ko; a "compiler differs" warning is harmless)
  ../../guest/run_guest.sh .                 boots the VM with every .ko of this folder in /mod, root shell
  in the VM:  insmod hello.ko ; dmesg | tail ; lsmod ; rmmod hello ; poweroff -f
  (guest/busybox is a static busybox 1.36.1 from Ubuntu; run_guest.sh puts it in the VM)

LAB 14.1  /proc/sysprog                    cd lab14_1 && make && ../guest/run_guest.sh .
  (gcc warns that owner and sysprog_show are unused until TODO 1-3: expected)
  TODO 1 module_param(owner, charp, 0444)   TODO 2 four seq_printf lines
  TODO 3 proc_create_single in init         TODO 4 remove_proc_entry in exit
  Test: insmod sysprog_proc_starter.ko owner=YourName ; cat /proc/sysprog (twice) ; rmmod sysprog_proc_starter ; cat /proc/sysprog

LAB 14.2  a platform driver with a sysfs file      cd lab14_2 && make && ../guest/run_guest.sh .
  insmod sp_dev.ko ; insmod sp_drv_starter.ko : no probe yet. Find out why (ls /sys/bus/platform/drivers).
  TODO 4 the driver's name   TODO 3 probe: state + drvdata   TODO 1 value_show   TODO 2 value_store
  Test: cat /sys/devices/platform/sysprog.0/value ; echo 42 > …/value ; echo abc > …/value
        echo sysprog.0 > /sys/bus/platform/drivers/sysprog/unbind ; … /bind ; rmmod in both orders
  Kernel 6.11 or newer: the driver uses .remove instead of .remove_new (the reference handles both with #if).

DEMOS (demo/): hello, param (who=... times=...), export (counter.ko + user.ko; insmod user.ko first: it fails),
  oops (crashes the VM's kernel on purpose: only in the VM!)
