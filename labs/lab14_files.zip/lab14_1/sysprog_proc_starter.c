// SPDX-License-Identifier: GPL-2.0
/*
 * sysprog_proc.c - a kernel module that adds the file /proc/sysprog
 * CSE 4105 System Programming, Lab 14.1   (STARTER: fill in the parts marked TODO)
 *
 * Build:  make            (needs the kernel headers: linux-headers-$(uname -r))
 * Run:    in the QEMU guest (or as root):  insmod sysprog_proc.ko owner=Mahbub ; cat /proc/sysprog ; rmmod sysprog_proc
 */
#include <linux/atomic.h>
#include <linux/jiffies.h>
#include <linux/module.h>
#include <linux/proc_fs.h>
#include <linux/sched.h>
#include <linux/seq_file.h>

static char *owner = "nobody";
/* TODO 1: make owner a module parameter: module_param(owner, charp, 0444); and a MODULE_PARM_DESC.
 *         Then  insmod sysprog_proc.ko owner=YourName  sets it, and /sys/module/sysprog_proc/parameters/owner shows it. */

static atomic_t reads = ATOMIC_INIT(0);
static unsigned long loaded_at;                      /* jiffies when the module was loaded */

/* called every time someone reads /proc/sysprog: print into the seq_file, not into a user pointer */
static int sysprog_show(struct seq_file *m, void *v)
{
    /* TODO 2: print four lines with seq_printf(m, ...), like printf into the file:
     *   owner:      <owner>
     *   reads:      <atomic_inc_return(&reads)>
     *   loaded for: <jiffies - loaded_at> jiffies = <jiffies_to_msecs(...)> ms (HZ = <HZ>)
     *   reader:     <current->comm> (pid <current->pid>)                                   */
    seq_puts(m, "nothing here yet: TODO 2\n");
    return 0;
}

static int __init sysprog_init(void)
{
    loaded_at = jiffies;
    /* TODO 3: create the file: proc_create_single("sysprog", 0444, NULL, sysprog_show).
     *         It returns NULL on failure: then return -ENOMEM (insmod will fail).             */
    pr_info("sysprog: loaded, but /proc/sysprog is not created yet: TODO 3\n");
    return 0;
}

static void __exit sysprog_exit(void)
{
    /* TODO 4: remove_proc_entry("sysprog", NULL); -- forget this and the next cat of /proc/sysprog
     *         after rmmod calls code that is no longer there: the kernel oopses.             */
    pr_info("sysprog: /proc/sysprog removed after %d reads\n", atomic_read(&reads));
}

module_init(sysprog_init);
module_exit(sysprog_exit);
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Lecture 14.1 lab: /proc/sysprog");
