TWICE    START   2000
.        CNTCH: count the character &CH in &TXT (length in word &LEN), result in &RES
.FIRST   CNTCH   TEXT,LENGTH,LETTERA,TOTALA
FIRST    LDX     ZERO
$AALOOP  LDA     ZERO
         LDCH    TEXT,X
         COMP    LETTERA
         JEQ     $AAHIT
$AANEXT  TIX     LENGTH
         JLT     $AALOOP
         J       $AADONE
$AAHIT   LDA     TOTALA
         ADD     ONE
         STA     TOTALA
         J       $AANEXT
$AADONE  LDA     TOTALA
.        CNTCH   TEXT,LENGTH,LETTERN,TOTALN
         LDX     ZERO
$ABLOOP  LDA     ZERO
         LDCH    TEXT,X
         COMP    LETTERN
         JEQ     $ABHIT
$ABNEXT  TIX     LENGTH
         JLT     $ABLOOP
         J       $ABDONE
$ABHIT   LDA     TOTALN
         ADD     ONE
         STA     TOTALN
         J       $ABNEXT
$ABDONE  LDA     TOTALN
HALT     J       HALT
TEXT     BYTE    C'BANANA'
LENGTH   WORD    6
LETTERA  WORD    65
LETTERN  WORD    78
ZERO     WORD    0
ONE      WORD    1
TOTALA   WORD    0
TOTALN   WORD    0
         END     FIRST
