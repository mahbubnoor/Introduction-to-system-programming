MACCNT   START   2000
.        macro 1: is text[i] equal to the character &CH?  if so, jump to &HIT
.        macro 2: add one to the word &VAR
FIRST    LDX     ZERO
.LOOP    CHKCH   LETTERA,FOUND
LOOP     LDA     ZERO
         LDCH    TEXT,X
         COMP    LETTERA
         JEQ     FOUND
NEXT     TIX     LENGTH
         JLT     LOOP
DONE     J       DONE
.FOUND   INCR    TOTAL
FOUND    LDA     TOTAL
         ADD     ONE
         STA     TOTAL
         J       NEXT
TEXT     BYTE    C'BANANA'
LENGTH   WORD    6
LETTERA  WORD    65
ZERO     WORD    0
TOTAL    WORD    0
ONE      WORD    1
         END     FIRST
