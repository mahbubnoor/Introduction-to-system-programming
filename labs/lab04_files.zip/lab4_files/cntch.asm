; cntch.asm - a nasm macro with a local label, used twice
        global  _start

%macro  CNTCH 2                 ; %1 = character, %2 = register for the count
        xor     ecx, ecx        ; index i = 0
        xor     %2, %2          ; count = 0
%%loop: cmp     byte [text + ecx], %1
        jne     %%next
        inc     %2
%%next: inc     ecx
        cmp     ecx, 6
        jl      %%loop
%endmacro

        section .data
text:   db      "BANANA"

        section .text
_start:
        CNTCH   'A', ebx        ; ebx = number of A's
        CNTCH   'N', edx        ; edx = number of N's
        imul    ebx, 10
        add     ebx, edx        ; exit status = 10*A + N
        mov     edi, ebx
        mov     eax, 60
        syscall
