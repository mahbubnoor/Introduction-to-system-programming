#include <stdio.h>

int main(void)
{
#ifdef DEBUG
    printf("debug: starting\n");
#endif
    printf("hello\n");
    return 0;
}
