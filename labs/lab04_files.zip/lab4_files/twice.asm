TWICE    START   2000
.        CNTCH: count the character &CH in &TXT (length in word &LEN), result in &RES
CNTCH    MACRO   &TXT,&LEN,&CH,&RES
         LDX     ZERO
$LOOP    LDA     ZERO
         LDCH    &TXT,X
         COMP    &CH
         JEQ     $HIT
$NEXT    TIX     &LEN
         JLT     $LOOP
         J       $DONE
$HIT     LDA     &RES
         ADD     ONE
         STA     &RES
         J       $NEXT
$DONE    LDA     &RES
         MEND
FIRST    CNTCH   TEXT,LENGTH,LETTERA,TOTALA
         CNTCH   TEXT,LENGTH,LETTERN,TOTALN
HALT     J       HALT
TEXT     BYTE    C'BANANA'
LENGTH   WORD    6
LETTERA  WORD    65
LETTERN  WORD    78
ZERO     WORD    0
ONE      WORD    1
TOTALA   WORD    0
TOTALN   WORD    0
         END     FIRST
