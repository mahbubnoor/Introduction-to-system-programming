CSE 4105 System Programming - Lab 4 files (macro processors)
Md Mahbub E Noor, University of Barishal

YOUR MACRO PROCESSOR
  macro_starter.c       fill in TODO 1-5
  maccnt.asm            two macros (CHKCH, INCR) used by the COUNT program
  maccnt_expected.asm   what your processor must print for maccnt.asm
  twice.asm             a macro with a loop, called twice (needs TODO 5: $ labels)
  twice_expected.asm    what your processor must print for twice.asm
  nodollar.asm          twice.asm without $: gives "duplicate symbol LOOP" in the assembler
  twodef.asm            a macro defined twice: must give an error

    gcc -Wall -o macro macro_starter.c
    ./macro maccnt.asm > out.asm
    diff out.asm maccnt_expected.asm        (prints nothing when you are right)
    ./sicasm out.asm                        (your Lab 3 assembler)

FROM THE LECTURE
  mac2.asm, sub2.asm    the same job with macros and with subroutines (slide 8)
  macfeat.asm           concatenation, $ labels, IF/ELSE, SET/WHILE, keyword parameters
  nested.asm            a macro that calls a macro (slide 23)

C PREPROCESSOR, NASM AND M4 DEMOS
  sqrun.c               SQUARE and MAX traps:    gcc sqrun.c -o sqrun && ./sqrun ;  gcc -E -P sqrun.c
  swap.c                the SWAP(t, x) name clash
  cat.c                 ## and #:                gcc -E -P cat.c
  dbg.c                 #ifdef:                  gcc dbg.c && ./a.out ;  gcc -DDEBUG dbg.c && ./a.out
  rec.c                 self-reference:          gcc -E -P rec.c
  sumrun.c              macro vs function:       gcc -O0 -S sumrun.c ; look at main in sumrun.s
  cntch.asm             nasm macro with %% labels: nasm -E cntch.asm ; nasm -f elf64 cntch.asm && ld cntch.o -o cntch && ./cntch ; echo $?
  count.m4              m4 count.m4
