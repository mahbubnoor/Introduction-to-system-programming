#include <stdio.h>
#define SWAP(a, b)  { int t = a; a = b; b = t; }

int main(void)
{
    int x = 1, y = 2, t = 9;
    SWAP(x, y);
    printf("x=%d y=%d\n", x, y);
    SWAP(t, x);
    printf("t=%d x=%d\n", t, x);
    return 0;
}
