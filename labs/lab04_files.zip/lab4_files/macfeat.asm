MACFT    START   0
.        CNTCH: count how often the character &CH appears in &TXT (length &LEN).
.        The count is left in S; with RES= it is also stored in that word.
CNTCH    MACRO   &TXT,&LEN,&CH,&RES=
         CLEAR   X
         CLEAR   S
         LDT     #&LEN
$LOOP    CLEAR   A
         LDCH    &TXT,X
         COMP    #&CH
         JEQ     $HIT
$NEXT    TIXR    T
         JLT     $LOOP
         J       $DONE
$HIT     LDA     #1
         ADDR    A,S
         J       $NEXT
         IF      (&RES NE '')
$DONE    STS     &RES
         ELSE
$DONE    RMO     S,A
         ENDIF
         MEND
.        FILL: put the value &VAL into &N words starting at &TAB (unrolled loop)
FILL     MACRO   &TAB,&N,&VAL=0
&OFF     SET     0
&I       SET     0
         LDA     #&VAL
         WHILE   (&I LT &N)
         STA     &TAB+&OFF
&OFF     SET     &OFF+3
&I       SET     &I+1
         ENDW
         MEND
.        SHOW: copy count &ID into the result table (concatenation)
SHOW     MACRO   &ID,&K
         LDA     CNT&ID
         STA     RES&K
         MEND
FIRST    STL     RETADR
         FILL    RES1,3,VAL=7
         CNTCH   TEXT,6,65,RES=CNTA
         CNTCH   TEXT,6,78,RES=CNTN
         CNTCH   TEXT,6,66
         SHOW    A,1
         SHOW    N,2
         J       @RETADR
RETADR   RESW    1
TEXT     BYTE    C'BANANA'
CNTA     WORD    99
CNTN     WORD    99
RES1     RESW    1
RES2     RESW    1
RES3     RESW    1
         END     FIRST
