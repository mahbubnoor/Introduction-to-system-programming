/*
 * macro.c - a one-pass macro processor for SIC/XE source (Beck, System Software, Section 4.1)
 * CSE 4105 System Programming, Lab 4   (STUDENT STARTER: fill in TODO 1-5)
 *
 * Build:   gcc -Wall -o macro macro.c
 * Run:     ./macro maccnt.asm > maccnt_expanded.asm
 *
 * Supports:  NAME MACRO &P1,&P2,...  /  body  /  MEND
 *            positional parameters, the invocation label on the first generated line,
 *            and unique labels: a label written $NAME becomes $AANAME, $ABNAME, ... (one pair per call)
 * Not supported here: macros inside macros, IF/WHILE, keyword parameters (see the lecture).
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAXDEF   500         /* lines in DEFTAB */
#define MAXMAC   50          /* macros in NAMTAB */
#define MAXARG   10          /* parameters per macro */
#define LINELEN  200

/* ---------------- the three tables ---------------- */
struct mac { char name[16]; int start, end; };    /* NAMTAB entry: where the macro is in DEFTAB */
static struct mac NAMTAB[MAXMAC];
static int nmacros = 0;

static char DEFTAB[MAXDEF][LINELEN];              /* definition lines, parameters written as ?1 ?2 ... */
static int ndef = 0;

static char ARGTAB[MAXARG][64];                    /* the arguments of the call being expanded */
static int nargs = 0;

static int uniq = 0;                               /* for $ labels: AA, AB, AC ... */

/* ---------------- small helpers ---------------- */
static int find_macro(const char *name)
{
    for (int i = 0; i < nmacros; i++)
        if (strcmp(NAMTAB[i].name, name) == 0)
            return i;
    return -1;
}

/* replace every "from" in s by "to" (s must have room) */
static void replace_all(char *s, const char *from, const char *to)
{
    char buf[LINELEN * 2] = "";
    char *p = s, *hit;
    size_t lf = strlen(from);
    while ((hit = strstr(p, from)) != NULL) {
        strncat(buf, p, (size_t)(hit - p));
        strcat(buf, to);
        p = hit + lf;
    }
    strcat(buf, p);
    strcpy(s, buf);
}

/* split a line into label, opcode, operand; return 0 for a blank or comment line */
static int split(const char *line, char *label, char *op, char *operand)
{
    char tmp[LINELEN];
    label[0] = op[0] = operand[0] = '\0';
    if (line[strspn(line, " \t\r\n")] == '\0' || line[strspn(line, " \t")] == '.')
        return 0;
    strcpy(tmp, line);
    int has_label = !isspace((unsigned char)tmp[0]);
    char *t = strtok(tmp, " \t\r\n");
    if (has_label) { strcpy(label, t); t = strtok(NULL, " \t\r\n"); }
    if (t) { strcpy(op, t); t = strtok(NULL, " \t\r\n"); }
    if (t) strcpy(operand, t);
    return 1;
}

/* write one line in fixed columns: label (9), opcode (8), operand */
static void put(const char *label, const char *op, const char *operand)
{
    char out[LINELEN];
    snprintf(out, sizeof out, "%-9s%-8s%s", label, op, operand);
    for (int n = (int)strlen(out); n > 0 && out[n - 1] == ' '; n--)   /* no blanks at the end */
        out[n - 1] = '\0';
    puts(out);
}

/* ---------------- DEFINE: store a macro in DEFTAB, its name in NAMTAB ---------------- */
static void define(FILE *in, const char *name, const char *protoargs)
{
    char line[LINELEN], label[64], op[64], operand[64];
    char params[MAXARG][64];
    int np = 0;

    /* the parameter names from the prototype, e.g. "&CH,&HIT" */
    char tmp[LINELEN];
    strcpy(tmp, protoargs);
    for (char *p = strtok(tmp, ","); p && np < MAXARG; p = strtok(NULL, ","))
        strcpy(params[np++], p);

    strcpy(NAMTAB[nmacros].name, name);
    NAMTAB[nmacros].start = ndef;
    snprintf(DEFTAB[ndef++], LINELEN, "%-9s%-8s%s", name, "MACRO", protoargs);   /* the prototype */

    while (fgets(line, sizeof line, in)) {
        if (!split(line, label, op, operand)) continue;       /* comments are not stored */
        if (strcmp(op, "MEND") == 0) break;
        char text[LINELEN];
        snprintf(text, sizeof text, "%-9s%-8s%s", label, op, operand);
        /* TODO 1: replace each parameter name params[k] in text by its position "?k+1",
         *         e.g. "COMP &CH" -> "COMP ?1". Use replace_all().
         *         Careful: replace longer names first (&LEN before &L).            */
        strcpy(DEFTAB[ndef++], text);
    }
    strcpy(DEFTAB[ndef++], "         MEND");
    NAMTAB[nmacros].end = ndef - 1;
    nmacros++;
}

/* ---------------- EXPAND: copy the body, putting the arguments in ---------------- */
static void expand(int m, const char *label, const char *operand)
{
    char tmp[LINELEN];
    nargs = 0;
    strcpy(tmp, operand);
    /* TODO 2: split tmp at the commas and copy each argument into ARGTAB[nargs++] */

    char id[3] = { (char)('A' + uniq / 26), (char)('A' + uniq % 26), '\0' };
    uniq++;

    printf(".%-8s%-8s%s\n", label, NAMTAB[m].name, operand);       /* the call, as a comment */

    int first = 1;
    for (int i = NAMTAB[m].start + 1; i < NAMTAB[m].end; i++) {
        char text[LINELEN], lab[64], op[64], opd[64];
        strcpy(text, DEFTAB[i]);
        /* TODO 3: replace "?k" in text by ARGTAB[k-1], for k = nargs down to 1 (?10 before ?1) */
        split(text, lab, op, opd);

        /* TODO 5 (after TODO 4 works): unique labels.
         *   a label "$LOOP" becomes "$" + id + "LOOP", e.g. "$AALOOP";
         *   an operand containing "$NEXT" gets the same treatment.                  */
        (void)id;

        /* TODO 4: if this is the first generated line, the call had a label,
         *         and this line has no label of its own: give it the call's label  */
        first = 0;
        put(lab, op, opd);
    }
}

int main(int argc, char *argv[])
{
    char line[LINELEN], label[64], op[64], operand[64];
    if (argc < 2) { fprintf(stderr, "usage: %s file.asm\n", argv[0]); return 1; }
    FILE *in = fopen(argv[1], "r");
    if (!in) { perror(argv[1]); return 1; }

    while (fgets(line, sizeof line, in)) {
        if (!split(line, label, op, operand)) {       /* comment or blank: copy it */
            line[strcspn(line, "\r\n")] = '\0';
            for (int n = (int)strlen(line); n > 0 && line[n - 1] == ' '; n--) line[n - 1] = '\0';
            puts(line);
            continue;
        }
        if (strcmp(op, "MACRO") == 0) {
            if (find_macro(label) >= 0) {
                fprintf(stderr, "error: macro %s defined twice\n", label);
                return 1;
            }
            define(in, label, operand);
            continue;
        }
        int m = find_macro(op);
        if (m >= 0)
            expand(m, label, operand);
        else
            put(label, op, operand);
    }
    fclose(in);
    return 0;
}
