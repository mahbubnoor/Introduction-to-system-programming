#define foo   foo + 1
#define A     B + 1
#define B     A * 2
int x = foo;
int y = A;
