MAC2     START   2000
.        macro 1: is text[i] equal to the character &CH?  if so, jump to &HIT
CHKCH    MACRO   &CH,&HIT
         LDA     ZERO
         LDCH    TEXT,X
         COMP    &CH
         JEQ     &HIT
         MEND
.        macro 2: add one to the word &VAR
INCR     MACRO   &VAR
         LDA     &VAR
         ADD     ONE
         STA     &VAR
         MEND
FIRST    LDX     ZERO
LOOP     CHKCH   LETTERA,FOUNDA
TESTN    CHKCH   LETTERN,FOUNDN
NEXT     TIX     LENGTH
         JLT     LOOP
DONE     J       DONE
FOUNDA   INCR    TOTALA
         J       TESTN
FOUNDN   INCR    TOTALN
         J       NEXT
TEXT     BYTE    C'BANANA'
LENGTH   WORD    6
LETTERA  WORD    65
LETTERN  WORD    78
ZERO     WORD    0
TOTALA   WORD    0
TOTALN   WORD    0
ONE      WORD    1
         END     FIRST
