#define COUNTER(id)  cnt_ ## id
#define SHOW(x)      printf(#x " = %d\n", x)

int COUNTER(a) = 3, COUNTER(n) = 2;

void report(void)
{
    SHOW(COUNTER(a));
}
