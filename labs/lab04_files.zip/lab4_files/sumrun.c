#include <stdio.h>
#define SQUARE(x) ((x) * (x))

int square(int x) { return x * x; }

int main(void)
{
    printf("%d %d\n", SQUARE(7), square(7));
    return 0;
}
