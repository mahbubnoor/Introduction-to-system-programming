#include <stdio.h>
#define SQUARE(x)   x * x
#define SQUARE2(x)  ((x) * (x))
#define MAX(a, b)   ((a) > (b) ? (a) : (b))

int main(void)
{
    int a = 3;
    printf("SQUARE(a + 1)  = %d\n", SQUARE(a + 1));
    printf("SQUARE2(a + 1) = %d\n", SQUARE2(a + 1));
    int i = 5, j = 2;
    int m = MAX(i++, j);
    printf("MAX(i++, j) = %d, and now i = %d\n", m, i);
    return 0;
}
