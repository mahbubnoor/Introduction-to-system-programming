SUB2     START   2000
FIRST    LDX     ZERO
LOOP     LDA     LETTERA
         JSUB    CHKCH
         JEQ     FOUNDA
TESTN    LDA     LETTERN
         JSUB    CHKCH
         JEQ     FOUNDN
NEXT     TIX     LENGTH
         JLT     LOOP
DONE     J       DONE
FOUNDA   LDA     TOTALA
         JSUB    INC
         STA     TOTALA
         J       TESTN
FOUNDN   LDA     TOTALN
         JSUB    INC
         STA     TOTALN
         J       NEXT
CHKCH    STA     CH
         LDA     ZERO
         LDCH    TEXT,X
         COMP    CH
         RSUB
INC      ADD     ONE
         RSUB
CH       RESW    1
TEXT     BYTE    C'BANANA'
LENGTH   WORD    6
LETTERA  WORD    65
LETTERN  WORD    78
ZERO     WORD    0
TOTALA   WORD    0
TOTALN   WORD    0
ONE      WORD    1
         END     FIRST
