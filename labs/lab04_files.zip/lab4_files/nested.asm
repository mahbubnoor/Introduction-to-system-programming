NESTED   START   2000
INCR     MACRO   &VAR
         LDA     &VAR
         ADD     ONE
         STA     &VAR
         MEND
ADD2     MACRO   &A,&B
         INCR    &B
         INCR    &A
         MEND
FIRST    ADD2    TOTALA,TOTALN
DONE     J       DONE
TOTALA   WORD    0
TOTALN   WORD    0
ONE      WORD    1
         END     FIRST
