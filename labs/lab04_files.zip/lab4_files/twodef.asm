T START 0
M1       MACRO   &A
         LDA     &A
         MEND
M1       MACRO   &B
         STA     &B
         MEND
         END     T
