define(`GREET', `Hello, $1! You are in $2.')dnl
define(`TWICE', `$1 $1')dnl
GREET(`students', `CSE 4105')
TWICE(`macro')
