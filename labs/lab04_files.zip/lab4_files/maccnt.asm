MACCNT   START   2000
.        macro 1: is text[i] equal to the character &CH?  if so, jump to &HIT
CHKCH    MACRO   &CH,&HIT
         LDA     ZERO
         LDCH    TEXT,X
         COMP    &CH
         JEQ     &HIT
         MEND
.        macro 2: add one to the word &VAR
INCR     MACRO   &VAR
         LDA     &VAR
         ADD     ONE
         STA     &VAR
         MEND
FIRST    LDX     ZERO
LOOP     CHKCH   LETTERA,FOUND
NEXT     TIX     LENGTH
         JLT     LOOP
DONE     J       DONE
FOUND    INCR    TOTAL
         J       NEXT
TEXT     BYTE    C'BANANA'
LENGTH   WORD    6
LETTERA  WORD    65
ZERO     WORD    0
TOTAL    WORD    0
ONE      WORD    1
         END     FIRST
