#!/bin/sh
# boot.sh - boot a Linux kernel in QEMU with our initramfs. The output appears in this terminal.
# KERNEL: a copy of the lab PC's own kernel:  sudo cp /boot/vmlinuz-$(uname -r) vmlinuz && sudo chmod a+r vmlinuz
KERNEL=${KERNEL:-./vmlinuz}
exec qemu-system-x86_64 -m 512 -nographic -no-reboot \
     -kernel "$KERNEL" -initrd initramfs.cpio.gz \
     -append "console=ttyS0 quiet panic=-1 ${EXTRA}"
