CSE 4105 System Programming - Lab 7 (Lectures 7.1 and 7.2): the Linux kernel and booting
=========================================================================================
Works offline. Needs: gcc (with static libc: libc6-dev), cpio, gzip, qemu-system-x86 (install before the lab).

LAB 7.1  kinfo.c: ask the running kernel about itself through /proc
  gcc -Wall -o kinfo kinfo_starter.c && ./kinfo
  TODO 1 first_line   TODO 2 field_kb   TODO 3 read_stat   TODO 4 classify (PF_KTHREAD)
  Compare your process counts with:  ps -ef | wc -l    and    ps -ef | grep -c '\['
  Explore: uname -r; ls /boot; lsmod | wc -l; modinfo ext4; modinfo btrfs; sudo dmesg | head; ulimit -s; ls /sys/firmware

LAB 7.2  myinit.c: your own PID 1, booted in QEMU
  1. A kernel:   sudo cp /boot/vmlinuz-$(uname -r) vmlinuz && sudo chmod a+r vmlinuz
                 (or use the vmlinuz your teacher put in the shared folder)
  2. Build:      gcc -Wall -static -o init myinit_starter.c
                 gcc -Wall -static -o kinfo_static kinfo_starter.c   (your finished kinfo from Lab 7.1)
  3. Pack:       ./mkinitramfs.sh
  4. Boot:       ./boot.sh                  (quit QEMU with Ctrl-A then X)
     First boot the starter as it is: read the kernel panic. Then do TODO 1-3.
  5. Experiments: EXTRA=rdinit=/bin/kinfo ./boot.sh      EXTRA=nokaslr ./boot.sh
  Optional: ./make_iso.sh puts GRUB in front (needs grub-pc-bin and xorriso).

boot1.log is one full boot of Ubuntu's 6.8 kernel in QEMU (all messages): homework 7.2 task 1.
