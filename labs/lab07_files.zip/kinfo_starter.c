/*
 * kinfo.c - ask the running kernel about itself, through the /proc file system
 * CSE 4105 System Programming, Lab 7.1   (STARTER: fill in the parts marked TODO)
 *
 * Build:  gcc -Wall -o kinfo kinfo.c          (add -static to run it inside the QEMU guest of Lab 7.2)
 * Run:    ./kinfo
 *
 * Nothing here is a special API: the kernel shows its data as text files under /proc,
 * and we read them with fopen, fgets and sscanf, as in any C program.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <dirent.h>

#define PF_KTHREAD 0x00200000   /* "I am a kernel thread" (include/linux/sched.h) */

/* read the first line of a file into buf; return 0 on success */
static int first_line(const char *path, char *buf, int size)
{
    /* TODO 1: open the file, read ONE line into buf with fgets, close it,
     *         remove the '\n' at the end (strcspn), return 0.  Return -1 if anything fails.
     *         Test: Kernel: and Command line: should appear in the output.                 */
    (void)path; (void)buf; (void)size;
    return -1;
}

/* find "Key:   123 kB" in a file like /proc/meminfo and return 123 */
static long field_kb(const char *path, const char *key)
{
    FILE *f = fopen(path, "r");
    char line[256];
    long v = -1;
    if (!f) return -1;
    /* TODO 2: read the file line by line; when a line starts with key (strncmp),
     *         read the number after the key with sscanf(line + strlen(key), " %ld", &v).   */
    (void)line; (void)key;
    fclose(f);
    return v;
}

/* one process: name, parent and flags, from /proc/<pid>/stat */
struct proc { int pid, ppid; char comm[64]; char state; unsigned long flags; };

static int read_stat(int pid, struct proc *p)
{
    char path[64], line[1024];
    snprintf(path, sizeof path, "/proc/%d/stat", pid);
    if (first_line(path, line, sizeof line) != 0) return -1;
    /* format: pid (comm) state ppid pgrp session tty_nr tpgid flags ...
       comm may contain spaces and ')', so take the LAST ')' */
    char *open = strchr(line, '('), *close = strrchr(line, ')');
    if (!open || !close) return -1;
    int n = close - open - 1;
    if (n > 63) n = 63;
    memcpy(p->comm, open + 1, n);
    p->comm[n] = '\0';
    p->pid = pid;
    int pgrp, session, tty, tpgid;
    /* TODO 3: after ") " come: state ppid pgrp session tty_nr tpgid flags  (man 5 proc).
     *         One sscanf on close + 2 fills p->state, p->ppid and p->flags (return -1 unless 7 items). */
    (void)pgrp; (void)session; (void)tty; (void)tpgid;
    p->state = '?'; p->ppid = 0; p->flags = 0;
    return 0;
}

int main(void)
{
    char buf[512];

    /* ---- 1. who is the kernel? ---- */
    if (first_line("/proc/version", buf, sizeof buf) == 0) printf("Kernel:        %s\n", buf);
    if (first_line("/proc/cmdline", buf, sizeof buf) == 0) printf("Command line:  %s\n", buf);
    if (first_line("/proc/uptime", buf, sizeof buf) == 0) {
        double up;
        sscanf(buf, "%lf", &up);
        printf("Up for:        %.1f seconds\n", up);
    }

    /* ---- 2. memory and CPUs ---- */
    printf("Memory:        %ld kB total, %ld kB free\n", field_kb("/proc/meminfo", "MemTotal:"), field_kb("/proc/meminfo", "MemFree:"));
    FILE *f = fopen("/proc/cpuinfo", "r");
    int cpus = 0;
    char model[256] = "?";
    while (f && fgets(buf, sizeof buf, f)) {
        if (strncmp(buf, "processor", 9) == 0) cpus++;
        if (strncmp(buf, "model name", 10) == 0 && model[0] == '?') {
            char *c = strchr(buf, ':');
            if (c) { strncpy(model, c + 2, sizeof model - 1); model[strcspn(model, "\n")] = '\0'; }
        }
    }
    if (f) fclose(f);
    printf("CPUs:          %d x %s\n", cpus, model);

    /* ---- 3. every process: user program or kernel thread? ---- */
    DIR *d = opendir("/proc");
    if (!d) { perror("/proc"); return 1; }
    struct dirent *e;
    int users = 0, kthreads = 0, kchildren = 0;
    struct proc first[8];
    int nfirst = 0;
    while ((e = readdir(d)) != NULL) {
        if (!isdigit((unsigned char)e->d_name[0])) continue;      /* only the numbered folders are processes */
        struct proc p;
        if (read_stat(atoi(e->d_name), &p) != 0) continue;        /* it may have exited meanwhile */
        /* TODO 4: a kernel thread has the PF_KTHREAD bit set in p.flags.
         *         Count kernel threads (and those whose parent is PID 2) and user processes. */
        users++;
        if (nfirst < 8 && p.pid <= 8) first[nfirst++] = p;
    }
    closedir(d);
    printf("Processes:     %d user processes, %d kernel threads (%d of them children of PID 2)\n", users, kthreads, kchildren);
    for (int i = 0; i < nfirst; i++)                               /* readdir order is not sorted */
        for (int j = i + 1; j < nfirst; j++)
            if (first[j].pid < first[i].pid) { struct proc t = first[i]; first[i] = first[j]; first[j] = t; }
    printf("\n  PID  PPID  S  kind    name\n");
    for (int i = 0; i < nfirst; i++)
        printf("%5d %5d  %c  %-6s  %s\n", first[i].pid, first[i].ppid, first[i].state,
               first[i].flags & PF_KTHREAD ? "kernel" : "user", first[i].comm);
    return 0;
}
