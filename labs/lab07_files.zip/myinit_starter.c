/*
 * myinit.c - our own PID 1, the first user program the Linux kernel starts
 * CSE 4105 System Programming, Lab 7.2   (STARTER: fill in the parts marked TODO)
 *
 * Build:  gcc -Wall -static -o init myinit.c       (static: the initramfs has no C library to load)
 * Pack:   ./mkinitramfs.sh                          (puts init, and kinfo if present, into initramfs.cpio.gz)
 * Boot:   ./boot.sh                                 (QEMU with the Ubuntu kernel; output on this terminal)
 */
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/mount.h>
#include <sys/reboot.h>
#include <sys/wait.h>

static void show(const char *label, const char *path)
{
    char line[512];
    FILE *f = fopen(path, "r");
    if (f && fgets(line, sizeof line, f)) printf("%-14s %s", label, line);
    if (f) fclose(f);
}

int main(int argc, char *argv[])
{
    (void)argc;
    printf("\n*** myinit: I am PID %d, started by the kernel as %s ***\n", getpid(), argv[0]);

    /* 1. Nothing is mounted yet: /proc and /sys are empty folders until we mount them */
    /* TODO 1: mount the proc file system on /proc and sysfs on /sys:
     *         mount("proc", "/proc", "proc", 0, NULL)   -- check the return value, perror on error.
     *         Without it, the next lines print nothing: /proc is just an empty folder.            */

    /* 2. Ask the kernel about this boot */
    show("kernel:", "/proc/sys/kernel/osrelease");
    show("command line:", "/proc/cmdline");
    show("uptime (s):", "/proc/uptime");

    /* 3. Start another program, the way every process after PID 1 is born: fork, then exec */
    /* TODO 2: if /bin/kinfo exists (access(..., X_OK) == 0):
     *         fork(); in the child execv("/bin/kinfo", args) and _exit(127) if execv returns;
     *         in the parent waitpid() for the child and print its exit status (WEXITSTATUS).
     *         (Lecture 8 explains fork and exec properly; here you just use them.)                 */

    /* 4. PID 1 must never return: the kernel would panic ("Attempted to kill init!") */
    printf("myinit: all done.\n");
    /* TODO 3: first boot the starter as it is and read the kernel panic message.
     *         Then: sync(); reboot(RB_POWER_OFF);  so PID 1 never returns.                      */
    return 0;
}
