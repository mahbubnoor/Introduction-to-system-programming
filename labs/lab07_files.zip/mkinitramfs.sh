#!/bin/sh
# mkinitramfs.sh - pack ./init (and ./kinfo, if built with -static) into initramfs.cpio.gz
set -e
rm -rf rootfs && mkdir -p rootfs/proc rootfs/sys rootfs/dev rootfs/bin
cp init rootfs/init
[ -x kinfo_static ] && cp kinfo_static rootfs/bin/kinfo
cd rootfs && find . | cpio -o -H newc 2>/dev/null | gzip > ../initramfs.cpio.gz
cd .. && ls -l initramfs.cpio.gz
