#!/bin/sh
# make_iso.sh - optional: put vmlinuz + initramfs.cpio.gz behind GRUB on a bootable CD image
# needs grub-pc-bin and xorriso (apt), then: qemu-system-x86_64 -m 512 -nographic -no-reboot -cdrom cse4105.iso
set -e
rm -rf iso && mkdir -p iso/boot/grub
cp vmlinuz iso/boot/vmlinuz && cp initramfs.cpio.gz iso/boot/initramfs.cpio.gz
cat > iso/boot/grub/grub.cfg <<'CFG'
serial --unit=0 --speed=115200
terminal_input serial
terminal_output serial
set timeout=3
menuentry "CSE 4105: Ubuntu kernel + our own init" {
    echo "GRUB: loading the kernel..."
    linux  /boot/vmlinuz console=ttyS0 quiet panic=-1
    echo "GRUB: loading the initramfs..."
    initrd /boot/initramfs.cpio.gz
}
CFG
grub-mkrescue -o cse4105.iso iso
